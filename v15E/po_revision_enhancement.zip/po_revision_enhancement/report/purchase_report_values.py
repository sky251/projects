from odoo import api, fields, models


class FooterData(models.AbstractModel):
    _name = "report.purchase.report_footer"
    _description = "Footer Data"

    @api.model
    def _get_report_values(self, docids, data=None):
        print("\n\n\n report")
        # report_name = 'account_batch_payment.print_batch_payment'
        # report = self.env['ir.actions.report']._get_report_from_name(report_name)
        return {
            'doc_ids': docids,
            'doc_model': report.model,
            'docs': self.env[report.model].browse(docids),
            'pages': self.get_pages,
        }
