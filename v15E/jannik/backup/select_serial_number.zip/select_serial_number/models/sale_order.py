# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class SaleOrder(models.Model):
    _inherit = "sale.order"

    def action_confirm(self):
        res = super(SaleOrder, self).action_confirm()
        if self.picking_ids:
            for picking in self.picking_ids:
                for move in picking.move_ids_without_package:
                    order_line_id = self.env['sale.order.line'].search(
                        [('order_id', '=', self.id), ('product_id', '=', move.product_id.id)])
                    if order_line_id and order_line_id.stock_lot_id:
                        if order_line_id.product_tracking == 'lot' or order_line_id.product_tracking == 'serial':
                            move.write(
                                {'lot_id': order_line_id.stock_lot_id.id})
                            # move.write({'lot_id': order_line_id.stock_lot_id.id, 'tax_code': [(6, 0, order_line_id.tax_id.ids)]})
        return res


class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    stock_lot_id = fields.Many2one(
        'stock.production.lot', string="Lot", copy=False)
    lot_id = fields.Char(string="Lot/Serial", copy=False)
    product_tracking = fields.Selection(related="product_id.tracking")

    @api.onchange('product_id', 'lot_id', 'product_uom_qty')
    def onchange_lot_number(self):
        if self.product_id:
            if self.product_tracking == 'lot' or self.product_tracking == 'serial':
                if self.lot_id:
                    check_lot_ids = self.env['stock.production.lot'].search(
                        [('name', '=', self.lot_id)])
                    if check_lot_ids:
                        if any(lot.product_id.id == self.product_id.id for lot in check_lot_ids):
                            for lot in check_lot_ids.filtered(lambda lot: lot.product_id.id == self.product_id.id):
                                if lot.product_id.id == self.product_id.id:
                                    if self.product_uom_qty > lot.product_qty:
                                        raise ValidationError(
                                            _('This product is not in stock.'))
                                    else:
                                        if lot and lot.tax_ids:
                                            self.tax_id = [
                                                (6, 0, lot.tax_ids.ids)]
                                            self.stock_lot_id = lot.id
                                else:
                                    raise ValidationError(
                                        _('This product does not exist in the given Lot Number.'))
                        else:
                            raise ValidationError(
                                _('This product does not exist in the given Lot Number.'))
                    else:
                        raise ValidationError(
                            _('Please enter a valid Serial Number.'))
        else:
            self.lot_id = False
            self.stock_lot_id = False
