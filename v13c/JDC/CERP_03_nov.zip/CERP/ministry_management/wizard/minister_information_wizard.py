# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import ValidationError

class MinisterInformationWizard(models.TransientModel):
    _name = "minister.information.wizard"
    _description = "Minister Information"

    ministry_ids = fields.Many2many('ministry.ministry', 'ministry_minister_information_rel', string='Ministries', copy=False)
    member_id = fields.Many2one('res.partner', 'Member', copy=False)
    family_id = fields.Many2one('res.partner', 'Family', copy=False, default=False)
    group_ids = fields.Many2many('schedulling.by.group', 'schedulling_by_group_minister_information_rel', string="Schedulled Groups", copy=False)
    action = fields.Selection([('add', 'Add'), ('remove', 'Remove')], string='Action', default=False)
    perform_on = fields.Selection([('group', 'Group'), ('ministry', 'Ministry')], string="Perform On", default=False)
    unlink_group_id = fields.Many2one('schedulling.by.group', copy=False, string="Schedulled Group", default=False)
    unlink_ministry_id = fields.Many2one('ministry.ministry', copy=False, string="Ministry", default=False)
    link_group_id = fields.Many2one('schedulling.by.group', copy=False, string="Schedulled Groups", default=False)
    link_ministry_id = fields.Many2one('ministry.ministry', copy=False, string="Ministry", default=False)
    unlink_group_ids = fields.Many2many('schedulling.by.group', 'minister_info_schedulling_group_unlink_rel', copy=False, string="Schedulled Group", default=False)
    unlink_group_ministry_id = fields.Many2one('ministry.ministry', copy=False,string="Ministry", default=False)
    link_group_ids = fields.Many2many('schedulling.by.group', 'minister_info_schedulling_group_link_rel', copy=False, string="Schedulled Group", default=False)
    link_group_ministry_id = fields.Many2one('ministry.ministry',copy=False, string="Ministry", default=False)

    @api.onchange('action')
    def onchange_action(self):
        if self.action:
            self.perform_on = False

    @api.onchange('unlink_group_id')
    def onchange_unlink_group_id(self):
        ministries = []
        if self.group_ids:
            if self.unlink_group_id:
                if self.unlink_group_ministry_id:
                    self.unlink_group_ministry_id = False               
                minister_detail_ids = self.env['minister.details'].search([('member_id', '=', self.member_id.id), 
                                                                           ('by_group_id', '=', self.unlink_group_id.id)])
                for detail in minister_detail_ids:
                    ministries.append(detail.group_ministry_id.id)
                return {'domain': {'unlink_group_ministry_id': [('id', 'in', ministries)]}}
            return {'domain': {'unlink_group_id': [('id', 'in', self.group_ids.ids)]}}

    @api.onchange('link_group_id')
    def onchange_link_group_id(self):
        if self.link_group_id:
            self.link_ministry_ids = False
            return {'domain': {'link_group_ministry_id': [('id', 'in', self.link_group_id.ministry_ids.ids)]}}

    @api.onchange('unlink_ministry_id')
    def onchange_unlink_ministry_id(self):
        groups = []
        if self.ministry_ids:
            if self.unlink_ministry_id:
                minister_detail_ids = self.env['minister.details'].search([('member_id', '=', self.member_id.id), 
                                                                           ('group_ministry_id', '=', self.unlink_ministry_id.id)])
                for detail in minister_detail_ids:
                    groups.append(detail.by_group_id.id)
                return {'domain': {'unlink_group_ids': [('id', 'in', groups)]}}
            return {'domain': {'unlink_ministry_id': [('id', 'in', self.ministry_ids.ids)]}}


    @api.onchange('link_group_ministry_id', 'unlink_ministry_id')
    def onchange_link_group_ministry(self):
        requirement = []
        domain = []
        if self.link_group_ministry_id or self.unlink_ministry_id:
            ministry = self.link_group_ministry_id or self.unlink_ministry_id
            if ministry.background_check:
                requirement.append('background_checks')
            if ministry.virtus_frequency:
                requirement.append('virtus_certification')
            if ministry.monthly:
                requirement.append('monthly')
            if 'monthly' in requirement and 'virtus_certification' not in requirement and 'background_checks' not in requirement:
                domain = [('monthly','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' in requirement and 'background_checks' not in requirement:
                domain = [('virtus_certification','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' not in requirement and 'background_checks' in requirement:
                domain = [('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' in requirement and 'background_checks' not in requirement:
                domain = ['|', ('virtus_certification','=', True), ('monthly','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' in requirement and 'background_checks' in requirement:
                domain = ['|', ('virtus_certification','=', True), ('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' not in requirement and 'background_checks' in requirement:
                domain = ['|', ('monthly','=', True), ('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' in requirement and 'background_checks' in requirement:
                domain = ['|', ('monthly','=', True), '|', ('background_checks','=', True), ('virtus_certification','=', True)]
            member_ids = self.env['res.partner'].search(domain)
            if member_ids:
                if self.member_id not in member_ids:
                    raise ValidationError(_('Member is not available for this ministry.'))
            if not member_ids:
                raise ValidationError(_('Member is not available for this ministry.'))


    @api.onchange('link_ministry_id')
    def onchange_link_ministry(self):
        requirement = []
        domain = []
        if self.link_ministry_id:
            self.link_group_ids = False
            ministry = self.link_ministry_id
            if ministry.background_check:
                requirement.append('background_checks')
            if ministry.virtus_frequency:
                requirement.append('virtus_certification')
            if ministry.monthly:
                requirement.append('monthly')
            if 'monthly' in requirement and 'virtus_certification' not in requirement and 'background_checks' not in requirement:
                domain = [('monthly','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' in requirement and 'background_checks' not in requirement:
                domain = [('virtus_certification','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' not in requirement and 'background_checks' in requirement:
                domain = [('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' in requirement and 'background_checks' not in requirement:
                domain = ['|', ('virtus_certification','=', True), ('monthly','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' in requirement and 'background_checks' in requirement:
                domain = ['|', ('virtus_certification','=', True), ('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' not in requirement and 'background_checks' in requirement:
                domain = ['|', ('monthly','=', True), ('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' in requirement and 'background_checks' in requirement:
                domain = ['|', ('monthly','=', True), '|', ('background_checks','=', True), ('virtus_certification','=', True)]
            member_ids = self.env['res.partner'].search(domain)
            if not member_ids or member_ids:
                if self.member_id not in member_ids:
                    raise ValidationError(_('Member is not available for this ministry.'))
            group_ids = self.env['schedulling.by.group'].search([('ministry_ids', 'in', self.link_ministry_id.id)])
            return {'domain': {'link_group_ids': [('id', 'in', group_ids.ids)]}}
          


    def link_unlink_minister(self):
        if self._context and self._context.get('active_id'):
            active_id= self.env['minister.minister'].browse(self._context.get('active_id'))
        if active_id:
            if self.unlink_group_id and self.unlink_group_ministry_id:
                minister_detail_ids = self.env['minister.details'].search([('member_id', '=', self.member_id.id), 
                                                                           ('by_group_id', '=', self.unlink_group_id.id),
                                                                           ('group_ministry_id', '=', self.unlink_group_ministry_id.id)])
                if minister_detail_ids:
                    minister_detail_ids.unlink()
                if active_id:
                    ministries = [i for i in active_id.ministry_ids.ids if i != self.unlink_group_ministry_id.id]
                    ministry = active_id.ministry_ids.ids
                    active_id.write({'ministry_ids': [(6,0,ministries)]})
                minister_details_ids = self.env['minister.details'].search([('member_id', '=', self.member_id.id),
                                                                            ('by_group_id', '=', self.unlink_group_id.id),
                                                                            ('group_ministry_id', 'in', self.ministry_ids.ids)]) 
                if not minister_details_ids:
                    schedulled_groups = [i for i in active_id.schedulled_group_ids.ids if i not in [self.unlink_group_id.id]]
                    active_id.write({'schedulled_group_ids': [(6,0,schedulled_groups)]})

                # active_id.write({'calendar_event_ids': [(6, 0, set(events))]})
            if self.link_group_id and self.link_group_ministry_id:
                ministries = active_id.ministry_ids.ids or []
                groups = active_id.schedulled_group_ids.ids or []
                minister_detail_id = self.env['minister.details'].search([('member_id', '=', self.member_id.id), 
                                                                          ('by_group_id', '=', self.link_group_id.id),
                                                                          ('group_ministry_id', '=',self.link_group_ministry_id.id)])
                if not minister_detail_id:
                    self.env['minister.details'].create({'member_id':self.member_id.id,
                                                         'by_group_id': self.link_group_id.id,
                                                         'family_id':self.member_id.parent_id and self.member_id.parent_id.id,
                                                         'assigned': True,
                                                         'group_ministry_id': self.link_group_ministry_id.id,
                                                         'virtus_certification': self.member_id.virtus_certification,
                                                         'background_check': self.member_id.background_checks
                                                        })
                    ministries.append(self.link_group_ministry_id.id)
                groups.append(self.link_group_id.id)
                active_id.write({'ministry_ids': [(6, 0, set(ministries))], 'schedulled_group_ids':[(6,0,set(groups))]})
            if self.unlink_ministry_id and self.unlink_group_ids:
                ministries = active_id.ministry_ids.ids or []
                group_ministries = []
                groups = active_id.schedulled_group_ids.ids or []
                for group in self.unlink_group_ids:
                    minister_detail_id = self.env['minister.details'].search([('member_id', '=', self.member_id.id), 
                                                                              ('by_group_id', '=', group.id),
                                                                              ('group_ministry_id', '=',self.unlink_ministry_id.id)])
                    if minister_detail_id:
                        ministries = [i for i in active_id.ministry_ids.ids if i != self.unlink_ministry_id.id]
                        minister_detail_id.unlink()
                    ministry_groups = [i for i in active_id.ministry_ids.ids if i not in group.ministry_ids.ids]
                active_id.write({'ministry_ids': [(6, 0, set(ministries))], 'schedulled_group_ids':[(6,0,set(groups))]})
                if active_id.schedulled_group_ids:
                    for group in active_id.schedulled_group_ids:
                        group_ministry = [x for x in group.ministry_ids.ids if x in active_id.ministry_ids.ids]
                        if not group_ministry:
                            active_id.write({'schedulled_group_ids': [(3, group.id)]})
            if self.link_ministry_id and self.link_group_ids:
                ministries = active_id.ministry_ids.ids or []
                groups = active_id.schedulled_group_ids.ids or []
                for group in self.link_group_ids:
                    minister_detail_id = self.env['minister.details'].search([('member_id', '=', self.member_id.id), 
                                                                              ('by_group_id', '=', group.id),
                                                                              ('group_ministry_id', '=',self.link_ministry_id.id)])
                    if not minister_detail_id:
                        self.env['minister.details'].create({'member_id':self.member_id.id,
                                                             'by_group_id': group.id,
                                                             'family_id':self.member_id.parent_id and self.member_id.parent_id.id,
                                                             'assigned': True,
                                                             'group_ministry_id': self.link_ministry_id.id,
                                                             'virtus_certification': self.member_id.virtus_certification,
                                                             'background_check': self.member_id.background_checks
                                                            })
                        groups.append(group.id)
                ministries.append(self.link_ministry_id.id)
                active_id.write({'ministry_ids': [(6, 0, set(ministries))], 'schedulled_group_ids':[(6,0,set(groups))]})
            for member_ministry in active_id.member_id.ministry_ids:
                member_ministry_id = self.env['minister.minister'].search([('ministry_ids', '=', member_ministry.ministry_id.id),
                    ('member_id', '=', active_id.member_id.id)])
                if not member_ministry_id:
                    member_ministry.unlink()
            # events = []
            # for group in active_id.schedulled_group_ids:
            #     events.append(group.event_id.id)
            # active_id.write({'calendar_event_ids': [(6, 0, set(events))]})

