# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class ByMinistryTypeWizard(models.TransientModel):
    _name = "by.ministry.type.wizard"
    _description = "By Ministry Type Report"

    ministry_type_id = fields.Many2one(
        'ministry.type', 'Ministry Type', copy=False)

    def print_ministry_detail(self):
        ministry_details = []
        data = {
            'form': self.read()[0]
        }
        ministry_detail_ids = self.env['minister.details'].search([
            ('by_ministry_id.allotment_ministry_id.ministry_type_id', '=', self.ministry_type_id.id)])
        if ministry_detail_ids:
            for detail in ministry_detail_ids:
                # for records in detail.minister_details_ids:
                vals = {}
                if detail.member_id:
                    vals.update({'member_id': detail.member_id.name})
                else:
                    vals.update({'member_id': ''})
                if detail.family_id:
                    vals.update({'family_id': detail.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if detail.virtus_certification:
                    vals.update(
                        {'virtus_certification': detail.virtus_certification})
                else:
                    vals.update({'virtus_certification': 'False'})
                if detail.by_ministry_id:
                    vals.update({'ministry_type_id': detail.by_ministry_id.allotment_ministry_id.ministry_type_id.name})
                else:
                    vals.update({'ministry_type_id': ''})
                # vals.update(
                #     {'ministry_type_id': detail.by_ministry_id.allotment_ministry_id.ministry_type_id.name})
                if detail.background_check:
                    vals.update({'background_check': detail.background_check})
                else:
                    vals.update({'background_check': 'False'})
                if detail.by_ministry_id:
                    vals.update({'ministry': detail.by_ministry_id.allotment_ministry_id.name})
                else:
                    vals.update({'ministry': ''})
                # vals.update(
                #     {'ministry': detail.by_ministry_id.allotment_ministry_id.name})
                if detail.schedulled_group_ids:
                    for group in detail.schedulled_group_ids:
                        group_name = "%s, " % (group.name)
                    vals.update({'schedulled_group_ids': group_name})
                else:
                    vals.update({'schedulled_group_ids': ''})
                # if detail.event_ids:
                #     vals.update({'event_ids': detail.event_ids.name})
                # else:
                #     vals.update({'event_ids': ''})
                if vals:
                    ministry_details.append(vals)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

        ministry_details_ids = self.env['minister.details'].search(
            [('group_ministry_id.ministry_type_id', '=', self.ministry_type_id.id)])
        if ministry_detail_ids:
            for detail in ministry_details_ids:
                # for records in detail.minister_details_ids:
                vals = {}
                if detail.member_id:
                    vals.update({'member_id': detail.member_id.name})
                else:
                    vals.update({'member_id': ''})
                if detail.family_id:
                    vals.update({'family_id': detail.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if detail.virtus_certification:
                    vals.update(
                        {'virtus_certification': detail.virtus_certification})
                else:
                    vals.update({'virtus_certification': 'False'})
                if detail.background_check:
                    vals.update({'background_check': detail.background_check})
                else:
                    vals.update({'background_check': 'False'})
                if detail.group_ministry_id:
                    vals.update({'ministry': detail.group_ministry_id.name})
                else:
                    vals.update({'ministry': ''})
                # vals.update({'ministry': detail.group_ministry_id.name})
                # if detail.schedulled_group_ids:
                #     vals.update({'schedulled_group_ids': detail.schedulled_group_ids.name})
                # else:
                #     vals.update({'schedulled_group_ids': ''})
                # if detail.event_ids:
                #     vals.update({'event_ids': detail.event_ids.name})
                # else:
                #     vals.update({'event_ids': ''})
                if vals:
                    ministry_details.append(vals)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))
        if ministry_details:
            data['ministry'] = ministry_details
            return self.env.ref('ministry_management.action_report_by_ministry_type').with_context(landscape=True).report_action(self, data=data)

 
    def get_report_xls(self):
        ministry_details = []
        data = {}
        ministry_detail_ids = self.env['minister.details'].search([
            ('by_ministry_id.allotment_ministry_id.ministry_type_id', '=', self.ministry_type_id.id)])
        if ministry_detail_ids:
            for detail in ministry_detail_ids:
                # for records in detail.minister_details_ids:
                vals = {}
                if detail.member_id:
                    vals.update({'member_id': detail.member_id.name})
                else:
                    vals.update({'member_id': ''})
                if detail.family_id:
                    vals.update({'family_id': detail.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if detail.virtus_certification:
                    vals.update(
                        {'virtus_certification': detail.virtus_certification})
                else:
                    vals.update({'virtus_certification': 'False'})
                if detail.by_ministry_id:
                    vals.update({'ministry_type_id': detail.by_ministry_id.allotment_ministry_id.ministry_type_id.name})
                else:
                    vals.update({'ministry_type_id': ''})
                # vals.update(
                #     {'ministry_type_id': detail.by_ministry_id.allotment_ministry_id.ministry_type_id.name})
                if detail.background_check:
                    vals.update({'background_check': detail.background_check})
                else:
                    vals.update({'background_check': 'False'})
                if detail.by_ministry_id:
                    vals.update({'ministry': detail.by_ministry_id.allotment_ministry_id.name})
                else:
                    vals.update({'ministry': ''})
                # vals.update(
                #     {'ministry': detail.by_ministry_id.allotment_ministry_id.name})
                if detail.schedulled_group_ids:
                    for group in detail.schedulled_group_ids:
                        group_name = "%s, " % (group.name)
                    vals.update({'schedulled_group_ids': group_name})
                else:
                    vals.update({'schedulled_group_ids': ''})
                # if detail.event_ids:
                #     vals.update({'event_ids': detail.event_ids.name})
                # else:
                #     vals.update({'event_ids': ''})
                if vals:
                    ministry_details.append(vals)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

        ministry_details_ids = self.env['minister.details'].search(
            [('group_ministry_id.ministry_type_id', '=', self.ministry_type_id.id)])
        if ministry_detail_ids:
            for detail in ministry_details_ids:
                # for records in detail.minister_details_ids:
                vals = {}
                if detail.member_id:
                    vals.update({'member_id': detail.member_id.name})
                else:
                    vals.update({'member_id': ''})
                if detail.family_id:
                    vals.update({'family_id': detail.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if detail.virtus_certification:
                    vals.update(
                        {'virtus_certification': detail.virtus_certification})
                else:
                    vals.update({'virtus_certification': 'False'})
                if detail.background_check:
                    vals.update({'background_check': detail.background_check})
                else:
                    vals.update({'background_check': 'False'})
                if detail.group_ministry_id:
                    vals.update({'ministry': detail.group_ministry_id.name})
                else:
                    vals.update({'ministry': ''})
                # vals.update({'ministry': detail.group_ministry_id.name})
                # if detail.schedulled_group_ids:
                #     vals.update({'schedulled_group_ids': detail.schedulled_group_ids.name})
                # else:
                #     vals.update({'schedulled_group_ids': ''})
                # if detail.event_ids:
                #     vals.update({'event_ids': detail.event_ids.name})
                # else:
                #     vals.update({'event_ids': ''})
                if vals:
                    ministry_details.append(vals)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))
        if ministry_details:
            data['ministry'] = ministry_details
            return self.env.ref('ministry_management.action_report_by_ministry_type_xls').with_context(landscape=True).report_action(self, data=data)

 