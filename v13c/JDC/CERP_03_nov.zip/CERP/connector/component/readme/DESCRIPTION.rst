This module implements a component system and is a base block for the Connector
Framework. It can be used without using the full Connector though.

Documentation: http://odoo-connector.com/
