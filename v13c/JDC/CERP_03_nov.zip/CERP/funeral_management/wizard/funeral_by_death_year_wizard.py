# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import UserError
import datetime


class FuneralByDeathYearWizard(models.TransientModel):
    _name = 'funeral.by.death.year.wizard'
    _description = "Funeral by Death Year Wizard"

    from_dod = fields.Date('From', copy=False)
    to_dod = fields.Date('To', copy=False)

    def action_get_death_year(self):
        tree_view_id = self.env.ref(
            'funeral_management.funeral_by_family_tree').id
        self.ensure_one()
        return {
            'name': 'By Death Year Tree View',
            'type': 'ir.actions.act_window',
            'res_model': 'funeral.by.family',
            'view_type': 'form',
            'view_mode': 'tree,form',
            'views': [(tree_view_id, 'tree'), (False, 'form')],
            'target': 'current',
            'domain': [('date_of_death', '>=', [self.from_dod]), ('date_of_death', '<=', [self.to_dod])],
        }


class ByDeathYearWizard(models.TransientModel):
    _name = "by.death.year.wizard"
    _description = "By Death Year Wizard"

    year = fields.Integer(string='Year', copy=False, default=2020)

    def get_by_death_year(self):
        death_year_list = []
        data = {
            'form': self.read()[0]
        }
        death_year_ids = self.env['funeral.by.family'].search(
            [('year', '=', self.year)])
        if death_year_ids:
            for records in death_year_ids:
                vals = {
                    'family_id': records.family_id.name,
                    'family_code': records.family_code,
                    'registration_member_id': records.registration_member_id.name,
                    'date_of_birth': records.date_of_birth,
                    'date_of_death': records.date_of_death,
                    'next_kin': records.registration_funeral_id.next_kin,
                    'ministries': records.registration_funeral_id.ministries.name,
                    'officiant': records.registration_funeral_id.officiant.name,
                    'funeral_date': records.registration_funeral_id.funeral_date,
                }
                if vals:
                    death_year_list.append(vals)
            data['death_year'] = death_year_list
            return self.env.ref('funeral_management.by_death_year_report').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        death_year_list = []
        data = {}
        death_year_ids = self.env['funeral.by.family'].search(
            [('year', '=', self.year)])
        if death_year_ids:
            for records in death_year_ids:
                vals = {
                    'family_id': records.family_id.name,
                    'family_code': records.family_code,
                    'registration_member_id': records.registration_member_id.name,
                    'date_of_birth': records.date_of_birth,
                    'date_of_death': records.date_of_death,
                    'next_kin': records.registration_funeral_id.next_kin,
                    'ministries': records.registration_funeral_id.ministries.name,
                    'officiant': records.registration_funeral_id.officiant.name,
                    'funeral_date': records.registration_funeral_id.funeral_date,
                }
                if vals:
                    death_year_list.append(vals)
            data['death_year'] = death_year_list
            return self.env.ref('funeral_management.by_death_year_report_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))
