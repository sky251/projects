# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class Partner(models.Model):
    _inherit = 'res.partner'

    enable_partner = fields.Boolean(string='Partner')
    
    
    @api.model_create_multi
    def create(self, vals_list):
        res = super(Partner, self).create(vals_list)
        if 'created_by_funeral' in self.env.context:
            res.enable_partner = True
        return res