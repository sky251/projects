# -*- coding: utf-8 -*-
from odoo import fields, models

class RelationType(models.Model):
    _name = 'relation.type'
    # _rec_name = 'code'

    name = fields.Char('Name',default=False, copy=False )
    code = fields.Char('Code',default=False, copy=False)


    # def get_code(self):
    # 	for rec in self:
    # 		if rec.name:
    # 			code = rec.name.lower()
    # 			rec.code = code