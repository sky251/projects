# -*- coding: utf-8 -*-
from odoo import fields, models


class Sacrament(models.Model):
    _name = 'sacrament.sacrament'
    _description = 'Sacraments'

    name = fields.Char('Sacrament')
    sacrament_type = fields.Selection([('initiation', 'Initiation'),
    									('healing', 'Healing'),
    									('service', 'Service')], 'Sacrament Type')
    sacrament_certificate = fields.Binary('Sacrament Certification')
    partner_id = fields.Many2one('res.partner', 'Partner')
    registration_id = fields.Many2one('member.registration', 'Member registration')
    prep_year = fields.Char('Prep Year')
    parish = fields.Many2one('res.partner', 'Parish')
    celebrant = fields.Many2one('hr.employee', 'Celebrant')
