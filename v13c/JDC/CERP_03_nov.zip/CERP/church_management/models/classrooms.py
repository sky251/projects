# -*- coding: utf-8 -*-
from odoo import fields, models


class Rooms(models.Model):
    _name = 'room.room'
    _description = "Rooms"

    name = fields.Char('Name')
    room_no = fields.Char('Room No.')
    is_unavailable = fields.Boolean('Unavailable')
    max_capacity = fields.Integer('Room Capacity')

    _sql_constraints = [('name_uniq', 'unique (name)', "Name already exists !")]

