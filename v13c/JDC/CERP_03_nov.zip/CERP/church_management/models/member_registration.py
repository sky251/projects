# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
import datetime
from odoo.exceptions import ValidationError


class MemberRegistration(models.Model):
    _name = 'member.registration'
    _description = "Member Registration"

    def _get_current_term(self):
        today = datetime.datetime.today()
        term_ids = self.env['term.term'].search([])
        term_id = term_ids.filtered(lambda x: x.start_date.year == datetime.datetime.today().year)
        if term_id:
            return term_id.id
        else:
            return False

    @api.constrains('member_detail_ids', 'partner_id')
    def member_details_constarains(self):
        if len(self.member_detail_ids) == 0:
            raise ValidationError(_('Please add child details.'))

    @api.onchange('term_id')
    def onchange_term_id(self):
        if self.term_id:
            for child in self.member_detail_ids:
                if child.level_id and child.level_id.term_id != self.term_id:
                    child.level_id = False
                    child.session_choice_1 = False
                    child.session_choice_2 = False

    name = fields.Char('Name', copy=False)
    partner_id = fields.Many2one('res.partner', 'Family', copy=False)
    family_ref = fields.Char('Family#', copy=False)
    new_registration = fields.Boolean('New Registration', copy=False)
    registration_date = fields.Date('Registration Date', default=datetime.datetime.today(), copy=False)
    term_id = fields.Many2one('term.term', 'Terms', default=_get_current_term, copy=False)
    member_detail_ids = fields.One2many('member.details', 'registration_id', string='Family Members', copy=False)
    first_parent_id = fields.Many2one('res.partner', 'Father', copy=False)
    second_parent_id = fields.Many2one('res.partner', 'Mother', copy=False)
    first_parent_street = fields.Char(copy=False)
    first_parent_street2 = fields.Char(copy=False)
    first_parent_zip = fields.Char(change_default=True, copy=False)
    first_parent_city = fields.Char(copy=False)
    first_parent_state_id = fields.Many2one("res.country.state", string='State', ondelete='restrict', domain="[('country_id', '=?', first_parent_country_id)]", copy=False)
    first_parent_country_id = fields.Many2one('res.country', string='Country', ondelete='restrict', copy=False)
    first_parent_email = fields.Char('email', copy=False)
    first_parent_phone = fields.Char('Phone', copy=False)
    second_parent_street = fields.Char(copy=False)
    second_parent_street2 = fields.Char(copy=False)
    second_parent_zip = fields.Char(change_default=True)
    second_parent_city = fields.Char(copy=False)
    second_parent_state_id = fields.Many2one("res.country.state", string='State', ondelete='restrict', domain="[('country_id', '=?', second_parent_country_id)]", copy=False)
    second_parent_country_id = fields.Many2one('res.country', string='Country', ondelete='restrict', copy=False)
    second_parent_email = fields.Char('email', copy=False)
    second_parent_phone = fields.Char('Phone', copy=False)
    preferred_phone = fields.Char('Class Phone', copy=False)
    other_phone = fields.Char('Emergency Contact', copy=False)
    communication_mode = fields.Selection([('text', 'Text'), ('email', 'E-mail'), ('regular', 'Regular')], copy=False)
    media_release = fields.Boolean('Media Release', copy=False)
    paid_in_full = fields.Boolean('Paid Full', copy=False)
    status = fields.Selection([('draft', 'Draft'), ('validate', 'Validated')],tracking=True, default='draft', copy=False)
    phone = fields.Char('Cellphone', copy=False)
    email = fields.Char('Email', copy=False)
    invoice_count = fields.Integer(compute='_total_invoices', string="Invoices", copy=False)
    is_sacramental_fee = fields.Boolean('Sacramental Fee', copy=False)
    allotment_ids = fields.One2many('allotment.allotment','allotment_family_id', 'Allotments', copy=False)
    
    def action_view_invoice(self):
        if self.partner_id:
            invoices = self.env['account.move'].search([('partner_id', '=', self.partner_id.id), ('invoice_origin', '=', self.name)])
            action = self.env.ref('account.action_move_out_invoice_type').read()[0]
            if len(invoices) > 1:
                action['domain'] = [('id', 'in', invoices.ids)]
            elif len(invoices) == 1:
                form_view = [(self.env.ref('account.view_move_form').id, 'form')]
                if 'views' in action:
                    action['views'] = form_view + [(state,view) for state,view in action['views'] if view != 'form']
                else:
                    action['views'] = form_view
                action['res_id'] = invoices.id
            else:
                action = {'type': 'ir.actions.act_window_close'}

            context = {
                'default_type': 'out_invoice',
            }
            if len(self) == 1:
                context.update({
                    'default_partner_id': self.partner_id.id,
                    'default_invoice_origin': self.mapped('name'),
                })
            action['context'] = context
            return action

    def _total_invoices(self):
        invoice_ids = self.env['account.move'].search([('partner_id', '=' ,self.partner_id.id), ('invoice_origin', '=', self.name)])
        self.invoice_count = len(invoice_ids)
        if not invoice_ids:
            self.invoice_count = 0.0

    def action_validate(self):
        self.status = 'validate'
        if self.env.ref('church_management.product_product_registration_fees'):
            line_vals = []
            if self.member_detail_ids:
                line_vals.append((0,0, {'product_id': self.env.ref('church_management.product_product_registration_fees'), 'quantity': len(self.member_detail_ids)}))
                if self.is_sacramental_fee and self.env.ref('church_management.product_product_sacramental_fees'):
                    line_vals.append((0,0, {'product_id': self.env.ref('church_management.product_product_sacramental_fees')}))
                move_id = self.env['account.move'].create({'partner_id':self.partner_id.id,
                                                       'invoice_date': datetime.datetime.today(),
                                                       'type': 'out_invoice', 
                                                       'invoice_origin': self.name,
                                                       'invoice_line_ids': line_vals})
    
    @api.onchange('member_detail_ids')
    def _onchange_member_details_ids(self):
        if self.new_registration:
            self.new_registration = True

    @api.onchange('first_parent_id')
    def _onchange_first_parent_id(self):
        if self.first_parent_id:
            father_id = self.first_parent_id
            self.first_parent_street2 = father_id.street
            self.first_parent_street2 = father_id.street2
            self.first_parent_zip = father_id.zip
            self.first_parent_city = father_id.city
            self.first_parent_state_id = father_id.state_id and father_id.state_id.id
            self.first_parent_country_id = father_id.country_id and father_id.country_id.id
            self.first_parent_email = father_id.email
            self.first_parent_phone = father_id.phone

    @api.onchange('second_parent_id')
    def _onchange_second_parent_id(self):
        if self.second_parent_id:
            mother_id = self.second_parent_id
            self.second_parent_street2 = mother_id.street
            self.second_parent_street2 = mother_id.street2
            self.second_parent_zip = mother_id.zip
            self.second_parent_city = mother_id.city
            self.second_parent_state_id = mother_id.state_id and mother_id.state_id.id
            self.second_parent_country_id = mother_id.country_id and mother_id.country_id.id
            self.second_parent_email = mother_id.email
            self.second_parent_phone = mother_id.phone

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        """Get Childs """
        childs = []
        parents_info = []
        father_id = False
        mother_id = False
        self.member_detail_ids = False
        if self.partner_id:
            self.media_release = self.partner_id.media_release
            self.communication_mode = self.partner_id.communication_mode
            if self. partner_id.communication_mode == 'text':
                self.phone = self.partner_id.mobile
            if self.communication_mode == 'email':
                self.email = self.partner_id.email
            if self.partner_id.ref:
                self.family_ref = self.partner_id.ref
            for partner in self.partner_id.mapped('family_members'):
                if partner.relationship_type_id.code == 'father':
                    father_id = partner
                if partner.relationship_type_id.code == 'mother':
                    mother_id = partner
                if not partner.faith_formation and partner.relationship_type_id.code == 'child':
                    if partner.date_of_birth:
                        if self.term_id:
                            level_id = self.env['level.level'].search([
                                ('term_id', '=', self.term_id.id),
                                ('start_dob', '<=', partner.date_of_birth),
                                ('end_dob', '>=', partner.date_of_birth)])
                        else:
                            level_id = self.env['level.level'].search([
                                ('start_dob', '<=', partner.date_of_birth),
                                ('end_dob', '>=', partner.date_of_birth)])
                    else:
                        level_id = False
                    childs.append((0,0, {'registration_partner_id':partner.id, 'level_id': level_id, 'new_registration':False}))
            print("father id:;;;;;;;;;;;;;;;;;;;;;;;;::;;;;",father_id)
            if father_id:
                self.first_parent_id = father_id.id
                self.first_parent_street2 = father_id.street
                self.first_parent_street2 = father_id.street2
                self.first_parent_zip = father_id.zip
                self.first_parent_city = father_id.city
                self.first_parent_state_id = father_id.state_id and father_id.state_id.id
                self.first_parent_country_id = father_id.country_id and father_id.country_id.id
                self.first_parent_email = father_id.email
                self.first_parent_phone = father_id.phone
            if mother_id:
                self.second_parent_id = mother_id.id
                self.second_parent_street = mother_id.street
                self.second_parent_street2 = mother_id.street2
                self.second_parent_zip = mother_id.zip
                self.second_parent_city = mother_id.city
                self.second_parent_state_id = mother_id.state_id and mother_id.state_id.id
                self.second_parent_country_id = mother_id.country_id and mother_id.country_id.id
                self.second_parent_email = mother_id.email
                self.second_parent_phone = mother_id.phone
            self.member_detail_ids = childs
            if not childs:
                self.member_detail_ids = False
        else:
            self.family_ref = False
            self.member_detail_ids = False

    @api.onchange('family_ref')
    def _onchange_family_ref(self):
        if self.family_ref:
            partner_id = self.env['res.partner'].search([('envelope_ref', '=', self.family_ref), ('is_company', '=', True)])
            if partner_id:
                self.partner_id = partner_id.id
            else:
                self.partner_id = False

    @api.model_create_multi
    def create(self, vals_list):
        values = {}
        parent_vals = {}
        faith_formation_vals = {}
        family_vals = {}
        allotment_details = []
        for vals in vals_list:
            vals['name'] = self.env['ir.sequence'].next_by_code('member.registration') or ('New')
            if 'first_parent_id' in vals and vals['first_parent_id']:
                if 'first_parent_street' in vals and vals['first_parent_street']:
                    values['street'] = vals['first_parent_street']
                if 'first_parent_street2' in vals and vals['first_parent_street2']:
                    values['street2'] = vals['first_parent_street2']
                if 'first_parent_city' in vals and vals['first_parent_city']:
                    values['city'] = vals['first_parent_city']
                if 'first_parent_state_id' in vals and vals['first_parent_state_id']:
                    values['state_id'] = vals['first_parent_state_id']
                if 'first_parent_zip' in vals and vals['first_parent_zip']:
                    values['zip'] = vals['first_parent_zip']
                if 'first_parent_country_id' in vals and vals['first_parent_country_id']:
                    values['country_id'] = vals['first_parent_country_id']
                if 'first_parent_email' in vals and vals['first_parent_email']:
                    values['email'] = vals['first_parent_email']
                if 'first_parent_phone' in vals and vals['first_parent_phone']:
                    values['phone'] = vals['first_parent_phone']
                self.env['res.partner'].browse(vals['first_parent_id']).write(values)
            if 'second_parent_id' in vals and vals['second_parent_id']:
                if 'second_parent_street' in vals and vals['second_parent_street']:
                    parent_vals['street'] = vals['second_parent_street']
                if 'second_parent_street2' in vals and vals['second_parent_street2']:
                    parent_vals['street2'] = vals['second_parent_street2']
                if 'second_parent_city' in vals and vals['second_parent_city']:
                    parent_vals['city'] = vals['second_parent_city']
                if 'second_parent_state_id' in vals and vals['second_parent_state_id']:
                    parent_vals['state_id'] = vals['second_parent_state_id']
                if 'second_parent_zip' in vals and vals['second_parent_zip']:
                    parent_vals['zip'] = vals['second_parent_zip']
                if 'second_parent_country_id' in vals and vals['second_parent_country_id']:
                    parent_vals['country_id'] = vals['second_parent_country_id']
                if 'second_parent_email' in vals and vals['second_parent_email']:
                    parent_vals['email'] = vals['second_parent_email']
                if 'second_parent_phone' in vals and vals['second_parent_phone']:
                    parent_vals['phone'] = vals['second_parent_phone']
                self.env['res.partner'].browse(vals['second_parent_id']).write(parent_vals)
            if 'media_release' in vals and vals['media_release']:
                family_vals['media_release'] = vals['media_release']
            if 'communication_mode' in vals and vals['communication_mode']:
                family_vals['communication_mode'] = vals['communication_mode']
            if 'phone' in vals and vals['phone']:
                family_vals['mobile'] = vals['phone']
            if 'email' in vals and vals['email']:
                family_vals['email'] = vals['email']
            if family_vals and 'partner_id' in vals and vals['partner_id']:
                self.env['res.partner'].browse(vals['partner_id']).write(family_vals)
            if 'member_detail_ids' in vals and vals['member_detail_ids']:
                for child in vals['member_detail_ids']:
                    if child[2]['registration_partner_id']:
                        if child[2]['new_registration']:
                            vals['new_registration'] = True
                        if 'preferred_phone' in vals and vals['preferred_phone']:
                            self.env['res.partner'].browse(child[2]['registration_partner_id']).write({'preferred_phone': vals['preferred_phone']})
                        if 'other_phone' in vals and vals['other_phone']:
                            self.env['res.partner'].browse(child[2]['registration_partner_id']).write({'other_phone': vals['other_phone']})
            res = super(MemberRegistration, self).create(vals_list)
            if res:
                if res.paid_in_full:
                    for detail in res.member_detail_ids:
                        allotment_details.append((0,0, {'level_id': detail.level_id and detail.level_id.id, 'session_id': detail.session_choice_1 and detail.session_choice_1.id, 
                                                        'family_id': res.partner_id and res.partner_id.id, 'term_id': res.term_id and res.term_id.id,
                                                        'child_id': detail.registration_partner_id and detail.registration_partner_id.id, 
                                                        'date_of_birth': detail.registration_partner_id.date_of_birth,
                                                        'member_detail_id': detail.id,
                                                        'registration_id': res.id}))
                        detail.registration_partner_id.write(
                            {'faith_formation_ids':[(0,0, {'term_id': res.term_id and res.term_id.id,
                                                           'level_id': detail.level_id and detail.level_id.id,
                                                           'session_id': detail.session_choice_1 and detail.session_choice_1.id,
                                                           'member_detail_id': detail.id,
                                                           'registration_id': res.id
                                                           })]})
                    allotment_by_family_id = self.env['allotment.by.family'].search([('allotment_family_id', '=', res.partner_id.id), ('term_id', '=', res.term_id.id)])
                    if allotment_by_family_id:
                        allotment_by_family_id.write({'allotment_ids': allotment_details})
                    else:
                        self.env['allotment.by.family'].create({
                            'allotment_family_id': res.partner_id.id,
                            'term_id': res.term_id and res.term_id.id,
                            'allotment_ids': allotment_details})
                    for detail in res.member_detail_ids:
                        allotment_by_level_id = self.env['allotment.by.level'].search([('allotment_level_id', '=', detail.level_id.id), ('term_id', '=', res.term_id.id)])
                        allotment_ids = self.env['allotment.allotment'].search([('level_id', '=', detail.level_id.id), ('term_id', '=', res.term_id.id)])
                        if allotment_ids:
                            if allotment_by_level_id:
                                allotment_by_level_id.write({'allotment_ids':[(6,0, allotment_ids.ids)]})
                            else:
                                allotment_by_level_id = self.env['allotment.by.level'].create({'allotment_level_id': detail.level_id.id,
                                                                                               'term_id': res.term_id and res.term_id.id,
                                                                                               'allotment_ids': [(6,0, allotment_ids.ids)]})
        return res

    def write(self, vals):
        values = {}
        parent_vals = {}
        faith_formation_vals = {}
        allotment_details = []
        for rec in self:
            if vals:
                name = 'name' in vals and vals['name'] or rec.name
                if not name:
                    vals['name'] = self.env['ir.sequence'].next_by_code('member.registration') or ('New')
                if 'first_parent_id' in vals and vals['first_parent_id']:
                    if 'first_parent_street' in vals and vals['first_parent_street']:
                        values['street'] = vals['first_parent_street']
                    if 'first_parent_street2' in vals and vals['first_parent_street2']:
                        values['street2'] = vals['first_parent_street2']
                    if 'first_parent_city' in vals and vals['first_parent_city']:
                        values['city'] = vals['first_parent_city']
                    if 'first_parent_state_id' in vals and vals['first_parent_state_id']:
                        values['state_id'] = vals['first_parent_state_id']
                    if 'first_parent_zip' in vals and vals['first_parent_zip']:
                        values['zip'] = vals['first_parent_zip']
                    if 'first_parent_country_id' in vals and vals['first_parent_country_id']:
                        values['country_id'] = vals['first_parent_country_id']
                    if 'first_parent_email' in vals and vals['first_parent_email']:
                        values['email'] = vals['first_parent_email']
                    if 'first_parent_phone' in vals and vals['first_parent_phone']:
                        values['phone'] = vals['first_parent_phone']
                    self.env['res.partner'].browse(vals['first_parent_id']).write(values)
                if 'second_parent_id' in vals and vals['second_parent_id']:
                    if 'second_parent_street' in vals and vals['second_parent_street']:
                        parent_vals['street'] = vals['second_parent_street']
                    if 'second_parent_street2' in vals and vals['second_parent_street2']:
                        parent_vals['street2'] = vals['second_parent_street2']
                    if 'second_parent_city' in vals and vals['second_parent_city']:
                        parent_vals['city'] = vals['second_parent_city']
                    if 'second_parent_state_id' in vals and vals['second_parent_state_id']:
                        parent_vals['state_id'] = vals['second_parent_state_id']
                    if 'second_parent_zip' in vals and vals['second_parent_zip']:
                        parent_vals['zip'] = vals['second_parent_zip']
                    if 'second_parent_country_id' in vals and vals['second_parent_country_id']:
                        parent_vals['country_id'] = vals['second_parent_country_id']
                    if 'second_parent_email' in vals and vals['second_parent_email']:
                        parent_vals['email'] = vals['second_parent_email']
                    if 'second_parent_phone' in vals and vals['second_parent_phone']:
                        parent_vals['phone'] = vals['second_parent_phone']
                    self.env['res.partner'].browse(vals['second_parent_id']).write(parent_vals)
                partner_id = 'partner_id' in vals and vals['partner_id'] or self.partner_id.id
                if 'media_release' in vals and vals['media_release'] and partner_id:
                    self.env['res.partner'].browse(partner_id).write({'media_release':vals['media_release']})
                if 'communication_mode' in vals and vals['communication_mode'] and partner_id:
                    self.env['res.partner'].browse(partner_id).write({'communication_mode':vals['communication_mode']})
                if 'phone' in vals and vals['phone'] and partner_id:
                    self.env['res.partner'].browse(partner_id).write({'mobile':vals['phone']})
                if 'email' in vals and vals['email'] and partner_id:
                    self.env['res.partner'].browse(partner_id).write({'email':vals['email']})
                if 'member_detail_ids' in vals and vals['member_detail_ids']:
                    for child in vals['member_detail_ids']:
                        if isinstance(child[2], dict):
                            if 'registration_partner_id' in child[2] and child[2]['registration_partner_id']:
                                if 'new_registration' in child[2] and child[2]['new_registration']:
                                    vals['new_registration'] = True
                res = super(MemberRegistration, self).write(vals)
                if 'preferred_phone' in vals and vals['preferred_phone'] or 'other_phone' in vals and vals['other_phone']:
                    for child in self.member_detail_ids:
                        if child.registration_partner_id:
                            if 'preferred_phone' in vals and vals['preferred_phone']:
                                child.registration_partner_id.write({'preferred_phone': vals['preferred_phone']})
                            if 'other_phone' in vals and vals['other_phone']:
                                child.registration_partner_id.write({'other_phone': vals['other_phone']})
                if rec.paid_in_full:
                    for child in rec.member_detail_ids:
                        allotment_id = self.env['allotment.allotment'].search([('child_id', '=', child.registration_partner_id.id), ('term_id', '=', rec.term_id.id)])
                        faith_formation_id = self.env['faith.formation'].search([('member_detail_id', '=', child.id), 
                                                                                 ('registration_id', '=', rec.id),
                                                                                 ('term_id', '=', rec.term_id.id)])
                        if not faith_formation_id:
                            child.registration_partner_id.write(
                                {'faith_formation_ids':[(0,0, {'term_id': rec.term_id and rec.term_id.id,
                                                               'level_id': child.level_id and child.level_id.id,
                                                               'session_id': child.session_choice_1 and child.session_choice_1.id,
                                                               'member_detail_id': child.id,
                                                               'registration_id': rec.id
                                                               })]})
                        else:
                            faith_formation_id.write({'level_id': child.level_id and child.level_id.id,
                                                      'session_id': child.session_choice_1 and child.session_choice_1.id,
                                                      })
                        if allotment_id:
                            allotment_id.write({'level_id': child.level_id and child.level_id.id,
                                                'session_id': child.session_choice_1.id,
                                                'member_detail_id': child.id,
                                                'registration_id': child.registration_id and child.registration_id.id
                                                })
                        else:
                            allotment_details.append((0,0, {'level_id': child.level_id and child.level_id.id, 
                                                            'session_id': child.session_choice_1 and child.session_choice_1.id, 
                                                            'family_id': child.registration_id.partner_id and child.registration_id.partner_id.id, 
                                                            'term_id': child.registration_id.term_id and child.registration_id.term_id.id,
                                                            'child_id': child.registration_partner_id and child.registration_partner_id.id, 
                                                            'date_of_birth': child.registration_partner_id.date_of_birth,
                                                            'member_detail_id': child.id,
                                                            'registration_id': child.registration_id and child.registration_id.id}))

                    allotment_by_family_id = self.env['allotment.by.family'].search([('allotment_family_id', '=', rec.partner_id.id), 
                                                                                     ('term_id', '=', rec.term_id.id)])
                    if allotment_by_family_id:
                        allotment_by_family_id.write({'allotment_ids': allotment_details})
                    else:
                        self.env['allotment.by.family'].create({
                            'allotment_family_id': rec.partner_id.id,
                            'term_id': rec.term_id and rec.term_id.id,
                            'allotment_ids': allotment_details})
                    for child in rec.member_detail_ids:
                        allotment_by_level_id = self.env['allotment.by.level'].search([('allotment_level_id', '=', child.level_id.id), ('term_id', '=', rec.term_id.id)])
                        allotment_ids = self.env['allotment.allotment'].search([('level_id', '=', child.level_id.id), ('term_id', '=', rec.term_id.id)])
                        if allotment_ids:
                            if allotment_by_level_id:
                                allotment_by_level_id.write({'allotment_ids':[(6,0, allotment_ids.ids)]})
                            else:
                                allotment_by_level_id = self.env['allotment.by.level'].create({'allotment_level_id': child.level_id.id,
                                                                                               'term_id': rec.term_id and rec.term_id.id,
                                                                                               'allotment_ids': [(6,0, allotment_ids.ids)]})
        return res

class MemberDetails(models.Model):
    _name = 'member.details'
    _description = 'Member Details'

    level_id = fields.Many2one('level.level', 'Levels', copy=False)
    session_choice_1 = fields.Many2one('session.session', 'Session Choice 1', copy=False)
    session_choice_2 = fields.Many2one('session.session', 'Session Choice 2', copy=False)
    registration_partner_id = fields.Many2one('res.partner', 'Child Name', copy=False)
    registration_id = fields.Many2one('member.registration', 'Member registration', copy=False, ondelete="cascade")
    family_id = fields.Many2one('res.partner', related="registration_id.partner_id", copy=False)
    new_registration = fields.Boolean('New Registration', default=True, copy=False)
    term_id = fields.Many2one('term.term', related="registration_id.term_id", copy=False, default=False)

    @api.onchange('registration_id')
    def _onchange_registration_id(self):
        if self.registration_partner_id:
            self.level_id = False

    @api.constrains('level_id')
    def constrain_level_id(self):
        for rec in self:
            if not rec.level_id:
                raise ValidationError(_('Please add level details.'))

    @api.onchange('level_id')
    def _onchange_level(self):
        if self.level_id:
            self.session_choice_1 = False
            self.session_choice_2 = False

  
    def unlink(self):
        allotment_id = self.env['allotment.allotment'].search([('member_detail_id', '=', self.id)])
        faith_formation_id = self.env['faith.formation'].search([('member_detail_id', '=', self.id)])
        if allotment_id:
            allotment_id.unlink()
        if faith_formation_id:
            faith_formation_id.unlink()
        return super(MemberDetails, self).unlink()