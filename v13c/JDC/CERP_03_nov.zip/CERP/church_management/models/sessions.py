# -*- coding: utf-8 -*-
from odoo import fields, models
import datetime

class Sessions(models.Model):
    _name = 'session.session'
    _description = "Sessions"

    TIME_SELECTION = [('08:00', '08:00'),
    ('08:00', '08:00'),
    ('08:15', '08:15'),
    ('08:30', '08:30'),
    ('08:45', '08:45'),
    ('09:00', '09:00'),
    ('09:15', '09:15'),
    ('09:30', '09:30'),
    ('09:45', '09:45'),
    ('10:00', '10:00'),
    ('10:15', '10:15'),
    ('10:30', '10:30'),
    ('10:45', '10:45'),
    ('11:00', '11:00'),
    ('11:15', '11:15'),
    ('11:30', '11:30'),
    ('11:45', '11:45'),
    ('12:00', '12:00'),
    ('12:15', '12:15'),
    ('12:30', '12:30'),
    ('12:45', '12:45'),
    ('13:00', '13:00'),
    ('13:15', '13:15'),
    ('13:30', '13:30'),
    ('13:45', '13:45'),
    ('14:00', '14:00'),
    ('14:15', '14:15'),
    ('14:30', '14:30'),
    ('14:45', '14:45'),
    ('15:00', '15:00'),
    ('15:15', '15:15'),
    ('15:30', '15:30'),
    ('15:45', '15:45'),
    ('16:00', '16:00'),
    ('16:15', '16:15'),
    ('16:30', '16:30'),
    ('16:45', '16:45'),
    ('17:00', '17:00'),
    ('17:15', '17:15'),
    ('17:30', '17:30'),
    ('17:45', '17:45'),
    ('18:00', '18:00'),
    ('18:15', '18:15'),
    ('18:30', '18:30'),
    ('18:45', '18:45'),
    ('19:00', '19:00'),
    ('19:15', '19:15'),
    ('19:30', '19:30'),
    ('19:45', '19:45'),
    ('20:00', '20:00')]

    name = fields.Char('Session', copy=False)
    day_of_week = fields.Selection([('monday', 'Monday'),
    								('tuesday', 'Tuesday'),
    								('wednesday', 'Wednesday'),
    								('thursday', 'Tursday'),
    								('friday', 'Friday'),
    								('saturday', 'Saturday'),
    								('sunday', 'Sunday')],
    								'Day of week', copy=False)
    start_time = fields.Selection(TIME_SELECTION, 'Start Time', copy=False)
    number_of_class = fields.Integer('No. of classes', copy=False)
    level_id = fields.Many2one('level.level', 'Levels', copy=False)
    end_time = fields.Selection(TIME_SELECTION,'End Time', copy=False)
    is_unavailable = fields.Boolean('Unavailable', copy=False)

    _sql_constraints = [('name_uniq', 'unique (name)', "Name already exists !")]