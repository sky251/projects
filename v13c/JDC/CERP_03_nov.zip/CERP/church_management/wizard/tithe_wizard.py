# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.


from odoo import api, fields, models

class TitheWizard(models.TransientModel):
    _name = "tithe.wizard"

    year_1 = fields.Integer('Year 1')
    year_2 = fields.Integer('Year 2')
    mode = fields.Selection([('list', 'List'), ('comparison', 'Comparison')])

    def show_mode(self):
        if self._context.get('active_id'):
            partner_id = self.env['res.partner'].search([('id', '=', self._context.get('active_id'))])
            if self.mode == 'list':
                if partner_id.donation_count > 0:
                    action = self.env.ref('church_management.action_donation_view_list').read()[0]
                    action['domain'] = [('family_id', '=', partner_id.id), ('batch_id.state', '=', 'validate')]
                    return action
            if self.mode == 'comparison':
                current_year = self.year_1
                prev_year = self.year_2
                action = self.env.ref('church_management.tithe_comparison_action').read()[0]
                current_amount = 0
                prev_amount = 0
                first_amount = 0
                second_amount = 0
                third_amount = 0
                fourth_amount = 0
                fifth_amount = 0
                sixth_amount = 0
                seventh_amount = 0
                eight_amount = 0
                nine_amount = 0
                ten_amount = 0
                eleven_amount = 0
                twelve_amount = 0
                first_prev_amount = 0
                second_prev_amount = 0
                third_prev_amount = 0
                fourth_prev_amount = 0
                fifth_prev_amount = 0
                sixth_prev_amount = 0
                seventh_prev_amount = 0
                eight_prev_amount = 0
                nine_prev_amount = 0
                ten_prev_amount = 0
                eleven_prev_amount = 0
                twelve_prev_amount = 0
                donation_dates = []
                self.env['tithe.comparison'].search([]).unlink()
                current_donation_ids = self.env['donation.donation'].search([('family_id', '=', partner_id.id)])
                for donation in current_donation_ids:
                    donation_dates.append(donation.donation_date)
                end_month = max(donation_dates).month
                for donation in current_donation_ids:
                    if donation.donation_date.year == current_year:
                        if donation.donation_date.month == 1:
                            first_amount += donation.amount
                        if donation.donation_date.month == 2:
                            second_amount += donation.amount
                        if donation.donation_date.month == 3:
                            third_amount += donation.amount
                        if donation.donation_date.month == 4:
                            fourth_amount += donation.amount
                        if donation.donation_date.month == 5:
                            fifth_amount += donation.amount
                        if donation.donation_date.month == 6:
                            sixth_amount += donation.amount
                        if donation.donation_date.month == 7:
                            seventh_amount += donation.amount
                        if donation.donation_date.month == 8:
                            eight_amount += donation.amount
                        if donation.donation_date.month == 9:
                            nine_amount += donation.amount
                        if donation.donation_date.month == 10:
                            ten_amount += donation.amount
                        if donation.donation_date.month == 11:
                            eleven_amount += donation.amount
                        if donation.donation_date.month == 12:
                            twelve_amount += donation.amount
                    if donation.donation_date.year == prev_year:
                        if donation.donation_date.month == 1:
                            first_prev_amount += donation.amount
                        if donation.donation_date.month == 2:
                            second_prev_amount += donation.amount
                        if donation.donation_date.month == 3:
                            third_prev_amount += donation.amount
                        if donation.donation_date.month == 4:
                            fourth_prev_amount += donation.amount
                        if donation.donation_date.month == 5:
                            fifth_prev_amount += donation.amount
                        if donation.donation_date.month == 6:
                            sixth_prev_amount += donation.amount
                        if donation.donation_date.month == 7:
                            seventh_prev_amount += donation.amount
                        if donation.donation_date.month == 8:
                            eight_prev_amount += donation.amount
                        if donation.donation_date.month == 9:
                            nine_prev_amount += donation.amount
                        if donation.donation_date.month == 10:
                            ten_prev_amount += donation.amount
                        if donation.donation_date.month == 11:
                            eleven_prev_amount += donation.amount
                        if donation.donation_date.month == 12:
                            twelve_prev_amount += donation.amount
                if end_month >= 1:
                    self.env['tithe.comparison'].create({'month':'january', 'prev_year': first_prev_amount, 'current_year': first_amount, 'family_id': self.id})
                if end_month >= 2:
                    self.env['tithe.comparison'].create({'month':'february', 'prev_year': second_prev_amount, 'current_year': second_amount, 'family_id': self.id})
                if end_month >= 3:
                    self.env['tithe.comparison'].create({'month':'march', 'prev_year': third_prev_amount, 'current_year': third_amount, 'family_id': self.id})
                if end_month >= 4:
                    self.env['tithe.comparison'].create({'month':'april', 'prev_year': fourth_prev_amount, 'current_year': fourth_amount, 'family_id': self.id})
                if end_month  >= 5:
                    self.env['tithe.comparison'].create({'month':'may', 'prev_year': fifth_prev_amount, 'current_year': fifth_amount, 'family_id': self.id})
                if end_month  >= 6:
                    self.env['tithe.comparison'].create({'month':'june', 'prev_year': sixth_prev_amount, 'current_year': sixth_amount, 'family_id': self.id})
                if end_month >= 7:
                    self.env['tithe.comparison'].create({'month':'july', 'prev_year': seventh_prev_amount, 'current_year': seventh_amount, 'family_id': self.id})
                if end_month  >= 8:
                    self.env['tithe.comparison'].create({'month':'august', 'prev_year': eight_prev_amount, 'current_year': eight_amount, 'family_id': self.id})
                if end_month  >= 9:
                    self.env['tithe.comparison'].create({'month':'september', 'prev_year': nine_amount, 'current_year': nine_amount, 'family_id': self.id})
                if end_month  >= 10:
                    self.env['tithe.comparison'].create({'month':'october', 'prev_year': ten_prev_amount, 'current_year': ten_amount, 'family_id': self.id})
                if end_month  >= 11:
                    self.env['tithe.comparison'].create({'month':'november', 'prev_year': eleven_prev_amount, 'current_year': eleven_amount, 'family_id': self.id})
                if end_month  >= 12:
                    self.env['tithe.comparison'].create({'month':'december', 'prev_year': twelve_prev_amount, 'current_year': twelve_amount, 'family_id': self.id})
                return action



