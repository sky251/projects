# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class NewRegisteredMemberWizard(models.TransientModel):
    _name = "active.member.wizard"
    _description = "Active Member Details"

    date_from = fields.Date('From Date')
    date_to = fields.Date('To Date')

    def print_active_members(self):
        records = []
        data = {}
        member_ids = self.env['res.partner'].search([('create_date', '>=', self.date_from), (
            'create_date', '<=', self.date_to), ('active', '=', True), ('inactive', '=', False), ('is_company', '=', False), ('company_type', '=', 'person')])
        if member_ids:
            data['members'] = member_ids.ids
            return self.env.ref('church_management.action_report_active_member').with_context(landscape=True).report_action(records, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence,this report cannot be printed.'))

    def get_report_xls(self):
        member_list = []
        data = {}
        member_data_ids = self.env['res.partner'].search([('create_date', '>=', self.date_from), (
            'create_date', '<=', self.date_to), ('active', '=', True), ('inactive', '=', False), ('is_company', '=', False), ('company_type', '=', 'person')])
        if member_data_ids:
            for records in member_data_ids:
                vals = {
                    'create_date': records.create_date,
                    'display_name': records.display_name,
                    'ref': records.ref,
                    }
                if vals:
                    member_list.append(vals)
            data['member'] = member_list
            return self.env.ref('church_management.action_report_active_member_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence,this report cannot be printed.'))