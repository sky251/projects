# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
import xlrd
import base64
import csv
import os
from datetime import datetime, timedelta
import json
import time
import tempfile
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
from odoo.addons.queue_job.job import job
import json
import logging
_logger = logging.getLogger(__name__)
# import openpyxl


class ImportFileWizard(models.TransientModel):
    _name = "import.file.wizard"
    _description = "Import File"

    file = fields.Binary('Xlsx')
    filename = fields.Char('Filename')
    file_type = fields.Selection([('family', 'Family'),
                                  ('member', 'Member'),
                                  ('ministry', 'Ministry'),
                                  ('death_data', 'Funeral'),
                                  ('sacrament', 'Sacrament'),
                                  ('salutation', 'Salutation')], 'File Type')

    @job(default_channel='root.import_member_datas')
    def import_family_datas(self, path):
        print("path of file:::::::::::::::::::::::::::::;",path)
        book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
        sh = book.sheet_by_index(0)
        counter = 0
        with open(path, 'r') as file:
            reader = csv.reader(file)
            active_status = False
            for row in reader:
                print("row:::::::::::::::::::::::::::::::::::::::::",counter)
                counter += 1
                if counter > 1:
                    family_id = self.env['res.partner'].sudo().search([('ref', '=', row[0])], limit=1)
                    if family_id:
                        print("row zero:::::::::::::::::::::::::",row[0])
                        if row[1] == '1.0':
                            active_status = True
                        else:
                            active_status = False
                        partner_ids = self.env['res.partner'].search([('parent_id', '=', family_id.id)])
                        if partner_ids:
                            for partner in partner_ids:
                                partner.write({'active': active_status})
                        if family_id:
                            family_id.write({'active':active_status})

    @job(default_channel='root.import_member_datas')
    def import_salutation_datas(self, path):
        book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
        sh = book.sheet_by_index(0)
        counter = 0
        with open(path, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                print("row:::::::::::::::::::::::::::::::::::::::::",counter)
                counter += 1
                if counter > 1:
                    partner_id = self.env['res.partner'].sudo().search([('member_ref', '=', row[0])], limit=1)
                    if partner_id:
                        partner_id.write({'salutation':row[1]})

    @job(default_channel='root.import_member_datas')
    def import_member_datas(self, path):
        book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
        sh = book.sheet_by_index(0)
        counter = 0
        with open(path, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                print("row:::::::::::::::::::::::::::::::::::::::::",counter)
                counter += 1
                gender = False
                occupation_id = False
                religion_id = False
                state_id = False
                active_status = False
                nickname_preferred = False
                zip_code = False
                marriage_status = False
                city = False
                relationship_type_id = False
                if counter > 1:
                    partner_id = self.env['res.partner'].sudo().search([('member_ref', '=', row[0])])
                    family_id = self.env['res.partner'].sudo().search([('ref', '=', row[1])], limit=1)
                    if family_id:
                        active_status = family_id.active
                        family_id = family_id.id
                    else:
                        family_id = False
                        active_status = True
                    if row[10]:
                        if row[10] == '1':
                            gender = 'male'
                        else:
                            gender = 'female'
                    if row[17]:
                        relationship_type_id = self.env['relation.type'].sudo().search(
                            [('code', '=', str(row[17]).rstrip('0').rstrip('.'))])
                    if row[13]:
                        father_id = self.env['res.partner'].sudo().search(
                            [('name', '=', row[13])])
                    if row[28]:
                        occupation_id = self.env['occupation.occupation'].sudo().search(
                            [('code', '=', str(row[28]).rstrip('0').rstrip('.'))])
                    if row[29]:
                        religion_id = self.env['religion.religion'].sudo().search(
                            [('code', '=', str(row[29]).rstrip('0').rstrip('.'))])
                    if row[39]:
                        address = row[39].split(',')
                        if address:
                            city = address[0]
                            addr = address[1].split(' ')
                            print("addr::::::::::::::::::::::",addr)
                            if addr:
                                state = addr[0]
                                state_id = self.env['res.country.state'].sudo().search([('code', '=', addr[1])], limit=1)
                                zip_code = addr[2]
                    if row[19]:
                        marriage_status = str(row[19]).rstrip('0').rstrip('.')
                        if marriage_status != '0':
                            marriage_status = marriage_status
                        else:
                            marriage_status = False
                    else:
                        marriage_status = False
                    if row[21]:
                        phone = '+1(%s) %s-%s' % tuple(re.findall(r'\d{4}$|\d{3}', str(row[21])))
                    else:
                        phone = False
                    if row[24]:
                        mobile = '+1(%s) %s-%s' % tuple(re.findall(r'\d{4}$|\d{3}', str(row[24])))
                    else:
                        mobile = False
                    if row[8] != '0.0':
                        nickname_preferred = True
                    if not partner_id:
                        partner_id = self.env['res.partner'].sudo().create({
                            'member_ref': row[0],
                            'type': 'private',
                            'parent_id': family_id,
                            'active': active_status,
                            'company_type':'person',
                            'ref': row[1],
                            'name': row[5] + ' ' + row[3] + ' ' + row[4] + ' ' + row[2],
                            'nickname': row[7],
                            'nickname_preferred': nickname_preferred,
                            'maiden_name': row[9],
                            'gender': gender,
                            'relationship_type_id': relationship_type_id and relationship_type_id.id,
                            'marital_status': marriage_status,
                            'phone': phone,
                            'unlisted': str(row[22]).rstrip('0').rstrip('.'),
                            'mobile': mobile,
                            'email': row[25],
                            'occupation': occupation_id and occupation_id.id,
                            'religion_id': religion_id and religion_id.id,
                            'comment': row[32] + '\n' + row[33],
                            'street': row[38],
                            'city': city,
                            'state_id': state_id and state_id.id,
                            'zip': zip_code,
                            })
                        if row[12]:
                            death_date = row[12].split('.')
                            partner_id.sudo().write(
                                {'death_date': datetime(1899, 12, 30) + timedelta(days=int(death_date[0]))})
                        if row[11]:
                            birth_date = row[11].split('.')
                            partner_id.sudo().write(
                                {'date_of_birth': datetime(1899, 12, 30) + timedelta(days=int(birth_date[0]))})
                        if row[30]:
                            write_date = row[30].split('.')
                            partner_id.sudo().write(
                                {'write_date': datetime(1899, 12, 30) + timedelta(days=int(write_date[0]))})
                    else:
                        partner_id.sudo().write({
                            'nickname': row[7],
                            'nickname_preferred': row[8],
                            # 'parent_id': family_id,
                            'maiden_name': row[9],
                            'gender': gender,
                            'relationship_type_id': relationship_type_id and relationship_type_id.id,
                            'marital_status': marriage_status,
                            'phone': phone,
                            'unlisted': str(row[22]).rstrip('0').rstrip('.'),
                            'mobile': mobile,
                            'email': row[24],
                            'occupation': occupation_id and occupation_id.id,
                            'religion_id': religion_id and religion_id.id,
                            'comment': row[32] + '\n' + row[33],
                            'street': row[37],
                            'city': city,
                            'state_id': state_id and state_id.id,
                            'zip': zip_code,
                        })
                        if row[12]:
                            death_date = row[12].split('.')
                            partner_id.sudo().write(
                                {'death_date': datetime(1899, 12, 30) + timedelta(days=int(death_date[0]))})
                        if row[11]:
                            birth_date = row[11].split('.')
                            partner_id.sudo().write(
                                {'date_of_birth': datetime(1899, 12, 30) + timedelta(days=int(birth_date[0]))})
                        if row[30]:
                            write_date = row[30].split('.')
                            partner_id.sudo().write(
                                {'write_date': datetime(1899, 12, 30) + timedelta(days=int(write_date[0]))})
    @job(default_channel='root.import_sacrament_datas')
    def import_sacrament_datas(self, path):
        counter = 0
        with open(path, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                print("countrt::::::::::::::::::::::::::::::::::;;",row)
                counter += 1
                if counter > 1:
                    partner_id = self.env['res.partner'].sudo().search([('member_ref', '=', row[0])])
                    if partner_id:
                        baptism_date = False
                        baptism_place = False
                        baptism_officiant = False
                        witness = ''
                        baptism_sacrament_id = self.env.ref('sacrament_management.sacrament_1')
                        if baptism_sacrament_id:
                            member_sacrament_id = self.env['sacrament.member.details'].sudo().search([('member_id', '=', partner_id.id), ('sacrament_id', '=', baptism_sacrament_id.id)])
                            if row[1] != 0:
                                baptism_place_id = self.env['place.parish'].sudo().search([('code', '=', str(row[1]).rstrip('0').rstrip('.'))])
                                if baptism_place_id:
                                    baptism_place = baptism_place_id.id
                            if row[2]:
                                baptism_date = row[2].split('.')
                                baptism_date = datetime(1899, 12, 30) + timedelta(days=int(baptism_date[0]))
                            if row[3]:
                                spl_word = '. '
                                baptism_officiant_name = row[3].partition(spl_word)[2]
                                officiant_id = self.env['res.partner'].sudo().search([('name', '=', row[3])])
                                if officiant_id:
                                    officiant_id.sudo().write({'member_role': 'deacon', 'member_role': 'priest'})
                                    baptism_officiant = officiant_id.id
                                if not officiant_id:
                                    baptism_officiant_id = self.env['res.partner'].sudo().create(
                                        {'name': row[3], 'member_role': 'deacon', 'member_role': 'priest'})
                                    baptism_officiant = baptism_officiant_id.id
                            if row[4]:
                                witness_1 = row[4]
                                witness = witness_1
                            if row[5]:
                                if witness_1:
                                    witness = witness_1 + ', ' + row[5]
                                else:
                                    witness = row[5]
                            if not member_sacrament_id:
                                if baptism_date or baptism_place or baptism_officiant or witness:
                                    self.env['sacrament.member.details'].sudo().create({'member_id': partner_id.id, 
                                                                                 'sacrament_id': baptism_sacrament_id.id,
                                                                                 'scarament_type_id': baptism_sacrament_id.sacrament_type,
                                                                                 'date': baptism_date,
                                                                                 'location': baptism_place,
                                                                                 'officiant_id': baptism_officiant,
                                                                                 'witness': witness})
                            else:
                                member_sacrament_id.sudo().write({'date': baptism_date,
                                                           'location': baptism_place,
                                                           'officiant_id': baptism_officiant,
                                                           'witness': witness})
                        penance_date = False
                        penance_place = False
                        penance_officiant = False
                        if row[6] != 0:
                            penance_place_id = self.env['place.parish'].sudo().search([
                                ('code', '=', str(row[6]).rstrip('0').rstrip('.'))])
                            if penance_place_id:
                                penance_place = penance_place_id.id
                        if row[7]:
                            penance_date = row[7].split('.')
                            penance_date = datetime(1899, 12, 30) + timedelta(days=int(penance_date[0]))
                        penance_sacrament_id = self.env.ref('sacrament_management.sacrament_2')
                        if penance_sacrament_id:
                            member_penance_sacrament_id = self.env['sacrament.member.details'].sudo().search([('member_id', '=', partner_id.id), ('sacrament_id', '=', penance_sacrament_id.id)])
                            if not member_penance_sacrament_id:
                                if penance_date or penance_place:
                                    self.env['sacrament.member.details'].sudo().create({'member_id': partner_id.id, 
                                                                                 'sacrament_id': penance_sacrament_id.id,
                                                                                 'scarament_type_id': penance_sacrament_id.sacrament_type,
                                                                                 'location': penance_place,
                                                                                 'date': penance_date})
                            else:
                                member_penance_sacrament_id.sudo().write({'location': penance_place,
                                                                   'date': penance_date})
                        eucharist_date = False
                        eucharist_place = False
                        eucharist_officiant = False
                        if row[8] != 0:
                            eucharist_place_id = self.env['place.parish'].sudo().search([('code', '=', str(row[8]).rstrip('0').rstrip('.'))])
                            if eucharist_place_id:
                                eucharist_place = eucharist_place_id.id
                        if row[9]:
                            eucharist_date = row[9].split('.')
                            eucharist_date = datetime(1899, 12, 30) + timedelta(days=int(eucharist_date[0]))
                            # eucharist_date = datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[9], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                        eucharist_sacrament_id = self.env.ref('sacrament_management.sacrament_3')
                        if eucharist_sacrament_id:
                            member_eucharist_sacrament_id = self.env['sacrament.member.details'].sudo().search([('member_id', '=', partner_id.id), 
                                                                                               ('sacrament_id', '=', eucharist_sacrament_id.id)])
                            if not member_eucharist_sacrament_id:
                                if eucharist_date or eucharist_place:
                                    self.env['sacrament.member.details'].sudo().create({'member_id': partner_id.id, 
                                                                                 'sacrament_id': eucharist_sacrament_id.id,
                                                                                 'scarament_type_id': eucharist_sacrament_id.sacrament_type,
                                                                                 'location': eucharist_place,
                                                                                 'date': eucharist_date})
                            else:
                                member_eucharist_sacrament_id.sudo().write({'location': eucharist_place,
                                                                     'date': eucharist_date})
                        confirmation_date = False
                        confirmation_place = False
                        confirmation_officiant = False
                        confirmation_name = False
                        witness = ''
                        confirmation_sacrament_id = self.env.ref('sacrament_management.sacrament_4')
                        if confirmation_sacrament_id:
                            member_confirmation_sacrament_id = self.env['sacrament.member.details'].sudo().search([('member_id', '=', partner_id.id), 
                                                                                               ('sacrament_id', '=', confirmation_sacrament_id.id)])
                            if row[10] != 0:
                                    confirmation_place_id = self.env['place.parish'].sudo().search(
                                        [('code', '=', str(row[10]).rstrip('0').rstrip('.'))])
                                    if confirmation_place_id:
                                        confirmation_place = confirmation_place_id.id
                            if row[11]:
                                confirmation_date = row[11].split('.')
                                confirmation_date = datetime(1899, 12, 30) + timedelta(days=int(confirmation_date[0]))
                                # confirmation_date = datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[11], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                            if row[12]:
                                confirmation_name = row[12]
                            if row[13]:
                                spl_word = '. '
                                confirmation_officiant_name = row[13].partition(spl_word)[2]
                                confirmation_officiant_id = self.env['res.partner'].sudo().search([('name', '=', row[13])])
                                if confirmation_officiant_id:
                                    confirmation_officiant_id.sudo().write({'member_role': 'deacon', 'member_role': 'priest'})
                                    confirmation_officiant = confirmation_officiant_id.id
                                if not confirmation_officiant_id:
                                    confirmation_officiant_id = self.env['res.partner'].sudo().create(
                                        {'name': row[13], 'member_role': 'deacon', 'member_role': 'priest'})
                                    confirmation_officiant = confirmation_officiant_id.id
                            if row[14]:
                                    witness_1 = row[14]
                                    witness = witness_1
                            if row[15]:
                                if witness_1:
                                    witness = witness_1 + ', ' + row[15]
                                else:
                                    witness = row[15]
                            if not member_confirmation_sacrament_id:
                                if confirmation_place or witness or confirmation_date or confirmation_officiant:
                                    self.env['sacrament.member.details'].sudo().create({'member_id': partner_id.id, 
                                                                                 'sacrament_id': confirmation_sacrament_id.id,
                                                                                 'scarament_type_id': confirmation_sacrament_id.sacrament_type,
                                                                                 'date': confirmation_date,
                                                                                 'location': confirmation_place,
                                                                                 'officiant_id': confirmation_officiant,
                                                                                 'witness': witness,
                                                                                 'confirmation_name': confirmation_name})
                            else:
                                member_confirmation_sacrament_id.sudo().write({'date': confirmation_date,
                                                                       'location': confirmation_place,
                                                                       'officiant_id': confirmation_officiant,
                                                                       'witness': witness})
                        marriage_date = False
                        marriage_place = False
                        marriage_officiant = False
                        witness = ''
                        if row[16] != 0:
                            marriage_place_id = self.env['place.parish'].sudo().search([('code', '=', str(row[16]).rstrip('0').rstrip('.'))])
                            if marriage_place_id:
                                marriage_place = marriage_place_id.id
                        if row[17]:
                            marriage_date = row[17].split('.')
                            marriage_date = datetime(1899, 12, 30) + timedelta(days=int(marriage_date[0]))
                            # marriage_date = datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[17], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                        marriage_sacrament_id = self.env.ref('sacrament_management.sacrament_5')
                        if marriage_sacrament_id:
                            member_marriage_sacrament_id = self.env['sacrament.member.details'].sudo().search([('member_id', '=', partner_id.id), 
                                                                                                        ('sacrament_id', '=', marriage_sacrament_id.id)])
                            if row[19]:
                                spl_word = '. '
                                marriage_officiant_name = row[19].partition(spl_word)[2]
                                marriage_officiant_id = self.env['res.partner'].sudo().search([('name', '=', row[19])])
                                if marriage_officiant_id:
                                    marriage_officiant_id.sudo().write({'member_role': 'deacon', 'member_role': 'priest'})
                                    marriage_officiant = marriage_officiant_id.id
                                if not marriage_officiant_id:
                                    marriage_officiant_id = self.env['res.partner'].sudo().create(
                                        {'name': row[13], 'member_role': 'deacon', 'member_role': 'priest'})
                                    marriage_officiant = marriage_officiant_id.id
                            if row[20]:
                                witness_1 = row[20]
                                witness = witness_1
                            if row[21]:
                                if witness_1:
                                    witness = witness_1 + ', ' + row[21]
                                else:
                                    witness = row[21]
                            if not member_marriage_sacrament_id:
                                if marriage_place or witness or marriage_date or marriage_officiant:
                                    self.env['sacrament.member.details'].sudo().create({'member_id': partner_id.id, 
                                                                                 'sacrament_id': marriage_sacrament_id.id,
                                                                                 'scarament_type_id': marriage_sacrament_id.sacrament_type,
                                                                                 'date': marriage_date,
                                                                                 'officiant_id': marriage_officiant,
                                                                                 'location': marriage_place,
                                                                                 'witness': witness})
                            else:
                                member_marriage_sacrament_id.sudo().write({'date': marriage_date,
                                                                   'officiant_id': marriage_officiant,
                                                                   'location': marriage_place,
                                                                   'witness': witness})
                        ordination_date = False
                        ordination_place = False
                        ordination_officiant = False
                        if row[22] != 0:
                            ordination_place_id = self.env['place.parish'].sudo().search([('code', '=', str(row[22]).rstrip('0').rstrip('.'))])
                            if ordination_place_id:
                                oridination_place = ordination_place_id.id
                        if row[23]:
                            ordination_date = row[23].split('.')
                            ordination_date = datetime(1899, 12, 30) + timedelta(days=int(ordination_date[0]))
                            # ordination_date = datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row, book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                        ordination_sacrament_id = self.env.ref('sacrament_management.sacrament_6')
                        if ordination_sacrament_id:
                            member_sacrament_id = self.env['sacrament.member.details'].sudo().search([('member_id', '=', partner_id.id), 
                                                                                               ('sacrament_id', '=', ordination_sacrament_id.id)])
                            if not member_sacrament_id:
                                if row[24]:
                                    spl_word = '. '
                                    ordination_officiant_name = row[24].partition(spl_word)[2]
                                    ordination_officiant_id = self.env['res.partner'].sudo().search([('name', '=', row[24])])
                                    if ordination_officiant_id:
                                        ordination_officiant_id.sudo().write({'member_role': 'deacon', 'member_role': 'priest'})
                                        ordination_officiant = ordination_officiant_id.id
                                    if not ordination_officiant_id:
                                        ordination_officiant_id = self.env['res.partner'].sudo().create(
                                            {'name': row[24], 'member_role': 'deacon', 'member_role': 'priest'})
                                        ordination_officiant = ordination_officiant_id.id
                                if ordination_place or ordination_date or ordination_officiant:
                                    self.env['sacrament.member.details'].sudo().create({'member_id': partner_id.id, 
                                                                                 'sacrament_id': ordination_sacrament_id.id,
                                                                                 'scarament_type_id': ordination_sacrament_id.sacrament_type,
                                                                                 'location': ordination_place,
                                                                                 'date': ordination_date,
                                                                                 'officiant_id': ordination_officiant})
    def import_file(self):
        if self.file_type == 'family':
            try:
                counter = 0
                family_files = []
                member_dates = []
                book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                sh = book.sheet_by_index(0)
                tmpdir = tempfile.mkdtemp()
                filename = 'family.csv'
                path = os.path.join(tmpdir, filename)
                batchCount = 1
                csv_file = open(path, 'w')
                wr = csv.writer(csv_file)
                for rownum in range(sh.nrows):
                    wr.writerow(sh.row_values(rownum))
                csvfilename = open(path, 'r').readlines()
                header = csvfilename[0] 
                csvfilename.pop(0) 
                file = 1
                record_per_file = 2500
                for j in range(len(csvfilename)):
                    if j % record_per_file == 0:
                        write_file = csvfilename[j:j+record_per_file]
                        #adding header at the start of the write_file
                        write_file.insert(0, header)
                        #write in file
                        open(str(path)+ str(file) + '.csv', 'w+').writelines(write_file)
                        family_files.append(str(path)+ str(file) + '.csv')
                        file += 1
                for family_file in family_files:
                    self.with_delay().import_family_datas(family_file)
            except Exception as e:
                raise ValidationError(_(e))

        if self.file_type == 'member':
            try:
                counter = 0
                member_files = []
                member_dates = []
                book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                sh = book.sheet_by_index(0)
                tmpdir = tempfile.mkdtemp()
                filename = 'members.csv'
                path = os.path.join(tmpdir, filename)
                batchCount = 1
                csv_file = open(path, 'w')
                wr = csv.writer(csv_file)
                for rownum in range(sh.nrows):
                    wr.writerow(sh.row_values(rownum))
                csvfilename = open(path, 'r').readlines()
                header = csvfilename[0] 
                csvfilename.pop(0) 
                file = 1
                record_per_file = 2500
                for j in range(len(csvfilename)):
                    if j % record_per_file == 0:
                        write_file = csvfilename[j:j+record_per_file]
                        #adding header at the start of the write_file
                        write_file.insert(0, header)
                        #write in file
                        open(str(path)+ str(file) + '.csv', 'w+').writelines(write_file)
                        member_files.append(str(path)+ str(file) + '.csv')
                        file += 1
                for member_file in member_files:
                    self.with_delay().import_member_datas(member_file)
            except Exception as e:
                raise ValidationError(_(e))
        if self.file_type == 'ministry':
            try:
                counter = 0
                book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                sh = book.sheet_by_index(0)
                batchCount = 1
                status = ''
                for rownum in range(sh.nrows):
                    print("rownum--------------------------------------",rownum,sh.row_values(rownum)[2])
                    counter += 1
                    if counter > 1:
                        minister_id = ''
                        partner_id = self.env['res.partner'].search([('member_ref', '=', sh.row_values(rownum)[0])])
                        if partner_id:
                            ministry_id = self.env['ministry.ministry'].search([('code', '=', str(sh.row_values(rownum)[1]).rstrip('0').rstrip('.'))])
                            if ministry_id:
                                member_minister_id = self.env['minister.minister'].search([('member_id', '=', partner_id.id)])
                                if member_minister_id:
                                    if ministry_id.id not in member_minister_id.ministry_ids.ids:
                                        member_minister_id.write({'ministry_ids': [(4, ministry_id.id)]})
                                else:
                                    self.env['minister.minister'].create({'member_id':partner_id.id, 
                                                                          'ministry_ids':[(6, 0, [ministry_id.id])]})
                                minister_id = self.env['member.minister.details'].search([('ministry_id', '=', ministry_id.id),
                                                                                          ('member_id', '=', partner_id.id)])
                                if sh.row_values(rownum)[2] == 2.0:
                                    status = 'Retired'
                                if sh.row_values(rownum)[2] == 1.0:
                                    status = 'Active'
                                if sh.row_values(rownum)[2] == 8.0:
                                    status = 'Pending'
                                if not minister_id:
                                    minister_id = partner_id.ministry_ids.create({'member_id': partner_id.id,
                                                                                  'ministry_id': ministry_id.id,
                                                                                  'ministry_status': status,
                                                                                })
                                else:
                                    minister_id.write({'ministry_status': status})
                                if minister_id:
                                    if sh.row_values(rownum)[4]:
                                        minister_id.write(
                                            {'start_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[4], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                    if sh.row_values(rownum)[7]:
                                        minister_id.write(
                                            {'retired_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[7], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                    if sh.row_values(rownum)[5]:
                                        minister_id.write(
                                            {'renewal_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[5], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
            except Exception as e:
                raise ValidationError(_(e))                     
        if self.file_type == 'death_data':
            try:
                counter = 0
                book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                sh = book.sheet_by_index(0)
                family_id = False
                family_code = False
                for rownum in range(sh.nrows):
                    print("death datas::::::::::::::::::::::",rownum)
                    counter += 1
                    if counter > 1:
                        if sh.row_values(rownum)[0]:
                            partner_id = self.env['res.partner'].search([('member_ref', '=', sh.row_values(rownum)[0])])
                            if partner_id:
                                family_id = partner_id.parent_id
                                if family_id: 
                                    family_code = family_id.ref
                                    family_id = family_id.id
                            else:
                                family_id = False
                                family_code = False
                            if sh.row_values(rownum)[2]:
                                burial_place_id = self.env['burial.places'].search([('code', '=', str(sh.row_values(rownum)[2]).rstrip('0').rstrip('.'))])
                                if burial_place_id:
                                     burial_place = burial_place_id.id
                                else:
                                    burial_place = False
                            else: 
                                burial_place = False
                            if sh.row_values(rownum)[0]:
                                funeral_member_id = self.env['funeral.member.details'].search([('registration_member_id', '=', partner_id.id)])
                                if not funeral_member_id:
                                    if sh.row_values(rownum)[1]:
                                        death_date = datetime.strptime(sh.row_values(rownum)[1], '%m/%d/%Y')
                                    else:
                                        death_date = False
                                    funeral_reg_id = self.env['funeral.registration'].create(
                                        {'partner_id': family_id,
                                         'family_code': family_code,
                                        'member_detail_ids': [(0,0, {'registration_member_id': partner_id.id,
                                         'date_of_death': death_date,
                                         'funeral_date': death_date,
                                         'cemetery': burial_place,
                                         
                                         'mass_service': str(sh.row_values(rownum)[3]).rstrip('0').rstrip('.')
                                        })]})
            except Exception as e:
                raise ValidationError(_(e))
        if self.file_type == 'sacrament':
            try:
                counter = 0
                sacrament_files = []
                book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                sh = book.sheet_by_index(0)
                tmpdir = tempfile.mkdtemp()
                filename = 'sacrament.csv'
                path = os.path.join(tmpdir, filename)
                batchCount = 1
                csv_file = open(path, 'w')
                wr = csv.writer(csv_file, quoting=csv.QUOTE_ALL)
                for rownum in range(sh.nrows):
                    print("rownum:::::::::000000000000::::::::::::",rownum)
                    wr.writerow(sh.row_values(rownum))
                csvfilename = open(path, 'r').readlines()
                header = csvfilename[0] 
                csvfilename.pop(0) 
                file = 1
                record_per_file = 2500
                for j in range(len(csvfilename)):
                    if j % record_per_file == 0:
                        write_file = csvfilename[j:j+record_per_file]
                        #adding header at the start of the write_file
                        write_file.insert(0, header)
                        #write in file
                        open(str(path)+ str(file) + '.csv', 'w+').writelines(write_file)
                        sacrament_files.append(str(path)+ str(file) + '.csv')
                        file += 1
                for sacrament_file in sacrament_files:
                    self.with_delay().import_sacrament_datas(sacrament_file)
            except Exception as e:
                raise ValidationError(_(e))
        if self.file_type == 'salutation':
            try:
                counter = 0
                salutation_files = []
                book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                sh = book.sheet_by_index(0)
                tmpdir = tempfile.mkdtemp()
                filename = 'salutation.csv'
                path = os.path.join(tmpdir, filename)
                batchCount = 1
                csv_file = open(path, 'w')
                wr = csv.writer(csv_file, quoting=csv.QUOTE_ALL)
                for rownum in range(sh.nrows):
                    print("*******************************",rownum)
                    wr.writerow(sh.row_values(rownum))
                csvfilename = open(path, 'r').readlines()
                header = csvfilename[0] 
                csvfilename.pop(0) 
                file = 1
                record_per_file = 120
                for j in range(len(csvfilename)):
                    if j % record_per_file == 0:
                        write_file = csvfilename[j:j+record_per_file]
                        #adding header at the start of the write_file
                        write_file.insert(0, header)
                        #write in file
                        open(str(path)+ str(file) + '.csv', 'w+').writelines(write_file)
                        salutation_files.append(str(path)+ str(file) + '.csv')
                        file += 1
                for salutation_file in salutation_files:
                    self.with_delay().import_salutation_datas(salutation_file)
            except Exception as e:
                raise ValidationError(_(e))
