# -*- coding: utf-8 -*-
from odoo import fields, models, api


class BurialPlaces(models.Model):
    _name = 'burial.places'
    _description = 'Burial Places Details'

    name = fields.Char('Burial Place', copy=False)
    city = fields.Char('City', copy=False)
    state = fields.Many2one('res.country.state', 'State', copy=False)
    code = fields.Integer('Code', copy=False)

    # @api.model_create_multi
    # def create(self, vals_list):
    #     for vals in vals_list:
    #         vals['code'] = self.env['ir.sequence'].next_by_code('funeral.burial.place')
    #     res = super(BurialPlaces, self).create(vals_list)
    #     return res