This module implements an event system (`Observer pattern`_) and is a
base block for the Connector Framework. It can be used without
using the full Connector though. It is built upon the ``component`` module.

Documentation: http://odoo-connector.com/

.. _Observer pattern: https://en.wikipedia.org/wiki/Observer_pattern
