from odoo import models, fields, api
from odoo.exceptions import UserError, ValidationError, Warning

class ByEnvelopeLabelWizard(models.TransientModel):
    _name = "by.envelope.label.wizard"
    _description = "By Envelope Label Wizard"

    family_ids = fields.Many2many(
        'res.partner','partner_partner_rel', string='Family Name', copy=False)

    def get_report(self):
        return self.env.ref('church_management.action_report_by_envelope_label').report_action(self)
