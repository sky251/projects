# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError

class StudentReportWizard(models.TransientModel):
    _name = "student.report.wizard"
    _description = "Student Report"

    report_type = fields.Selection([('by_level', 'By Level'),
        ('by_class', 'By Class'),('by_session', 'By Session')], string="Report Type", default='by_level',copy=False)
    class_id = fields.Many2one('class.class', copy=False, default=False, string="Class")
    session_id = fields.Many2one('session.session', copy=False, default=False, string="Session")
    level_id = fields.Many2one('level.level', copy=False, default=False, string="Level")

    def print_student_detail(self):
        student_details = []
        data = {
            'form': self.read()[0]
        }
        if (self.report_type == 'by_level'):
            student_detail_ids = self.env['allotment.allotment'].search([('level_id','=', self.level_id.id)])
            if student_detail_ids:
                for detail in student_detail_ids:
                    vals = {}
                    vals.update({'child_id': detail.child_id.name})
                    vals.update({'level_id': detail.level_id.name})
                    if detail.child_id.parent_id:
                        vals.update({'family_id': detail.child_id.parent_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.child_id.date_of_birth:
                        vals.update({'dob': detail.child_id.date_of_birth})
                    else:
                        vals.update({'dob': ''})
                    if detail.session_id:
                        vals.update({'session_id': detail.session_id.name})
                    else:
                        vals.update({'session_id': ''})
                    if detail.class_id:
                        vals.update({'class_id': detail.class_id.name})
                    else:
                        vals.update({'class_id': ''})
                    if vals:
                        student_details.append(vals)
                data['student'] = student_details
                return self.env.ref('church_management.action_report_student_by_level').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.report_type == 'by_class'):
            student_detail_ids = self.env['allotment.allotment'].search([('class_id','=', self.class_id.id)])
            if student_detail_ids:
                for detail in student_detail_ids:
                    vals = {}
                    vals.update({'child_id': detail.child_id.name})
                    vals.update({'class_id': detail.class_id.name})
                    if detail.child_id.parent_id:
                        vals.update({'family_id': detail.child_id.parent_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.child_id.date_of_birth:
                        vals.update({'dob': detail.child_id.date_of_birth})
                    else:
                        vals.update({'dob': ''})
                    if detail.session_id:
                        vals.update({'session_id': detail.session_id.name})
                    else:
                        vals.update({'session_id': ''})
                    if detail.level_id:
                        vals.update({'level_id': detail.level_id.name})
                    else:
                        vals.update({'level_id': ''})
                    if vals:
                        student_details.append(vals)
                data['student'] = student_details
                return self.env.ref('church_management.action_report_student_by_class').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.report_type == 'by_session'):
            student_detail_ids = self.env['allotment.allotment'].search([('session_id','=', self.session_id.id)])
            if student_detail_ids:
                for detail in student_detail_ids:
                    vals = {}
                    vals.update({'child_id': detail.child_id.name})
                    vals.update({'session_id': detail.session_id.name})
                    if detail.child_id.parent_id:
                        vals.update({'family_id': detail.child_id.parent_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.child_id.date_of_birth:
                        vals.update({'dob': detail.child_id.date_of_birth})
                    else:
                        vals.update({'dob': ''})
                    if detail.level_id:
                        vals.update({'level_id': detail.level_id.name})
                    else:
                        vals.update({'level_id': ''})
                    if detail.class_id:
                        vals.update({'class_id': detail.class_id.name})
                    else:
                        vals.update({'class_id': ''})
                    if vals:
                        student_details.append(vals)
                data['student'] = student_details
                return self.env.ref('church_management.action_report_student_by_session').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

       
    def get_report_xls(self):
        student_details = []
        data = {}
        if (self.report_type == 'by_level'):
            student_detail_ids = self.env['allotment.allotment'].search([('level_id','=', self.level_id.id)])
            if student_detail_ids:
                for detail in student_detail_ids:
                    vals = {}
                    vals.update({'child_id': detail.child_id.name})
                    if detail.child_id.parent_id:
                        vals.update({'family_id': detail.child_id.parent_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.child_id.date_of_birth:
                        vals.update({'dob': detail.child_id.date_of_birth})
                    else:
                        vals.update({'dob': ''})
                    if detail.session_id:
                        vals.update({'session_id': detail.session_id.name})
                    else:
                        vals.update({'session_id': ''})
                    if detail.class_id:
                        vals.update({'class_id': detail.class_id.name})
                    else:
                        vals.update({'class_id': ''})
                    if vals:
                        student_details.append(vals)
                data['student'] = student_details
                return self.env.ref('church_management.action_report_student_by_level_xls').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.report_type == 'by_class'):
            student_detail_ids = self.env['allotment.allotment'].search([('class_id','=', self.class_id.id)])
            if student_detail_ids:
                for detail in student_detail_ids:
                    vals = {}
                    vals.update({'child_id': detail.child_id.name})
                    if detail.child_id.parent_id:
                        vals.update({'family_id': detail.child_id.parent_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.child_id.date_of_birth:
                        vals.update({'dob': detail.child_id.date_of_birth})
                    else:
                        vals.update({'dob': ''})
                    if detail.session_id:
                        vals.update({'session_id': detail.session_id.name})
                    else:
                        vals.update({'session_id': ''})
                    if detail.level_id:
                        vals.update({'level_id': detail.level_id.name})
                    else:
                        vals.update({'level_id': ''})
                    if vals:
                        student_details.append(vals)
                data['student'] = student_details
                return self.env.ref('church_management.action_report_student_by_class_xls').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.report_type == 'by_session'):
            student_detail_ids = self.env['allotment.allotment'].search([('session_id','=', self.session_id.id)])
            if student_detail_ids:
                for detail in student_detail_ids:
                    vals = {}
                    vals.update({'child_id': detail.child_id.name})
                    if detail.child_id.parent_id:
                        vals.update({'family_id': detail.child_id.parent_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.child_id.date_of_birth:
                        vals.update({'dob': detail.child_id.date_of_birth})
                    else:
                        vals.update({'dob': ''})
                    if detail.level_id:
                        vals.update({'level_id': detail.level_id.name})
                    else:
                        vals.update({'level_id': ''})
                    if detail.class_id:
                        vals.update({'class_id': detail.class_id.name})
                    else:
                        vals.update({'class_id': ''})
                    if vals:
                        student_details.append(vals)
                data['student'] = student_details
                return self.env.ref('church_management.action_report_student_by_session_xls').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
