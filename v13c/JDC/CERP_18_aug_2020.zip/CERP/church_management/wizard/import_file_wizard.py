# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
import xlrd
import base64
import csv
import os
from datetime import datetime
import json
import time
import tempfile
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
from odoo.addons.queue_job.job import job
# import openpyxl


class ImportFileWizard(models.TransientModel):
    _name = "import.file.wizard"
    _description = "Import File"

    file = fields.Binary('Xlsx')
    filename = fields.Char('Filename')
    file_type = fields.Selection([('member', 'Member'),
                                  ('ministry', 'Ministry'),
                                  ('death_data', 'Funeral'),
                                  ('sacrament', 'Sacrament')], 'File Type')


    @job(default_channel='root.import_datas')
    def import_datas(self, path, xls_file):
        print("path of file:::::::::::::::::::::::::::::;",path)
        counter = 0
        book = xlrd.open_workbook(file_contents = base64.b64decode(xls_file))
        with open(path, 'r') as file:
            reader = csv.reader(file)
            for row in reader:
                print("row:::::::::::::::::::::::::::::::::::::::::",row)
                counter += 1
                gender = False
                occupation_id = False
                religion_id = False
                state_id = False
                zip_code = False
                city = False
                relationship_type_id = False
                if counter > 1:
                    partner_id = self.env['res.partner'].sudo().search([('member_ref', '=', row[0])])
                    print("SSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS",partner_id)
                    print("row num:::::::::::::::::::::::::::",counter)
                    family_id = self.env['res.partner'].sudo().search([('ref', '=', row[1])], limit=1)
                    if family_id:
                        family_id = family_id.id
                    else:
                        family_id = False
                    if row[10]:
                        if row[10] == '1':
                            gender = 'male'
                        else:
                            gender = 'female'
                    if row[17]:
                        relationship_type_id = self.env['relation.type'].sudo().search(
                            [('code', '=', str(row[17]).rstrip('0').rstrip('.'))])
                    if row[13]:
                        father_id = self.env['res.partner'].sudo().search(
                            [('name', '=', row[13])])
                    if row[28]:
                        occupation_id = self.env['occupation.occupation'].sudo().search(
                            [('code', '=', str(row[28]).rstrip('0').rstrip('.'))])
                    if row[29]:
                        religion_id = self.env['religion.religion'].sudo().search(
                            [('code', '=', str(row[29]).rstrip('0').rstrip('.'))])
                    if row[39]:
                        address = row[39].split(',')
                        if address:
                            city = address[0]
                            addr = address[1].split(' ')
                            if addr:
                                state = addr[0]
                                state_id = self.env['res.country.state'].sudo().search([('code', '=', addr[0])])
                                zip_code = addr[1]
                    if not partner_id:
                        partner_id = self.env['res.partner'].sudo().create({
                            'member_ref': row[0],
                            'parent_id': family_id,
                            'company_type':'person',
                            'ref': row[1],
                            'name': row[2] + row[3] + row[4] + row[5],
                            'nickname': row[7],
                            'nickname_preferred': row[8],
                            'maiden_name': row[9],
                            'gender': gender,
                            'relationship_type_id': relationship_type_id and relationship_type_id.id,
                            'marital_status': str(row[19]).rstrip('0').rstrip('.'),
                            'phone': row[20],
                            'unlisted': str(row[22]).rstrip('0').rstrip('.'),
                            'mobile': row[23],
                            'email': row[24],
                            'occupation': occupation_id and occupation_id.id,
                            'religion_id': religion_id and religion_id.id,
                            'comment': row[32] + '\n' + row[33],
                            'street': row[37],
                            'city': city,
                            'state_id': state_id and state_id.id,
                            'zip': zip_code,
                            # 'death_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[12], book.datemode)), "%Y-%m-%d %H:%M:%S").date(),
                            # 'date_of_birth': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[11], book.datemode)), "%Y-%m-%d %H:%M:%S").date(),
                            # 'write_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[30], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                            })
                    else:
                        partner_id.write({
                            'nickname': row[7],
                            'nickname_preferred': row[8],
                            'parent_id': family_id,
                            'maiden_name': row[9],
                            'gender': gender,
                            'relationship_type_id': relationship_type_id and relationship_type_id.id,
                            'marital_status': str(row[19]).rstrip('0').rstrip('.'),
                            'phone': row[20],
                            'unlisted': str(row[22]).rstrip('0').rstrip('.'),
                            'mobile': row[23],
                            'email': row[24],
                            'occupation': occupation_id and occupation_id.id,
                            'religion_id': religion_id and religion_id.id,
                            'comment': row[32] + '\n' + row[33],
                            'street': row[37],
                            'city': city,
                            'state_id': state_id and state_id.id,
                            'zip': zip_code,
                            # 'death_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[12], book.datemode)), "%Y-%m-%d %H:%M:%S").date(),
                            # 'date_of_birth': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[11], book.datemode)), "%Y-%m-%d %H:%M:%S").date(),
                            # 'write_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[30], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                        })

    def import_file(self, start = False, end=False):
        startTime = time.time()
        timeout = startTime + 60*10
        if self.file_type == 'member':
            try:
                counter = 0
                member_files = []
                for wizard in self:
                    book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                    sh = book.sheet_by_index(0)
                    tmpdir = tempfile.mkdtemp()
                    filename = 'members.csv'
                    path = os.path.join(tmpdir, filename)
                    batchCount = 1
                    csv_file = open(path, 'w')
                    print("path::::::::::::::::::::::::::::::::::::::::::",path)
                    wr = csv.writer(csv_file, quoting=csv.QUOTE_ALL)
                    for rownum in range(sh.nrows):
                        wr.writerow(sh.row_values(rownum))
                    csvfilename = open(path, 'r').readlines()
                    header = csvfilename[0] 
                    csvfilename.pop(0) 
                    file = 1
                    record_per_file = 1000
                    for j in range(len(csvfilename)):
                        if j % record_per_file == 0:
                            write_file = csvfilename[j:j+record_per_file]
                            #adding header at the start of the write_file
                            write_file.insert(0, header)
                            #write in file
                            open(str(path)+ str(file) + '.csv', 'w+').writelines(write_file)
                            member_files.append(str(path)+ str(file) + '.csv')
                            file += 1
                    print("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",member_files)
                    for member_file in member_files:
                        self.with_delay().import_datas(member_file, self.file)
                        
                                        # if partner_id:
                                        #     if row[12]:
                                        #         partner_id.write(
                                        #             {'death_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[12], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                        #     if row[11]:
                                        #         partner_id.write(
                                        #             {'date_of_birth': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[11], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                        #     if row[30]:
                                        #         partner_id.write(
                                                    # {'write_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(row[30], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})

                    # try:
                    #     with open(path, "w") as tmp:
                    #         for rownum in range(sh.nrows):
                    #             tmp.write(sh.row_values(rownum))
                    #         # csv_file.close()
                    # except IOError as e:
                    #     print ('IOError', e)
                    # csv_file = open('sacrament.csv', 'w')
                    # wr = csv.writer(csv_file, quoting=csv.QUOTE_ALL)
                    # for rownum in range(sh.nrows):
                    #     wr.writerow(sh.row_values(rownum))
                    # csv_file.close()
                        # counter += 1
                        # if counter > 1:
                        #     partner_id = self.env['res.partner'].search([('member_ref', '=', sh.row_values(rownum)[0])])
                        #     family_id = self.env['res.partner'].search([('ref', '=', sh.row_values(rownum)[1])], limit=1)
                        #     if not partner_id and family_id:
                        #         if sh.row_values(rownum)[10]:
                        #             if sh.row_values(rownum)[10] == '1':
                        #                 gender = 'male'
                        #             else:
                        #                 gender = 'female'
                        #         if sh.row_values(rownum)[17]:
                        #             relationship_type_id = self.env['relation.type'].search(
                        #                 [('code', '=', str(sh.row_values(rownum)[17]).rstrip('0').rstrip('.'))])
                        #         if sh.row_values(rownum)[13]:
                        #             father_id = self.env['res.partner'].search(
                        #                 [('name', '=', sh.row_values(rownum)[13])])
                        #         if sh.row_values(rownum)[28]:
                        #             occupation_id = self.env['occupation.occupation'].search(
                        #                 [('code', '=', str(sh.row_values(rownum)[28]).rstrip('0').rstrip('.'))])
                        #         if sh.row_values(rownum)[29]:
                        #             religion_id = self.env['religion.religion'].search(
                        #                 [('code', '=', str(sh.row_values(rownum)[29]).rstrip('0').rstrip('.'))])
                        #         if sh.row_values(rownum)[39]:
                        #             address = sh.row_values(rownum)[39].split(',')
                        #             if address:
                        #                 city = address[0]
                        #                 addr = address[1].split(' ')
                        #                 if addr:
                        #                     state = addr[0]
                        #                     state_id = self.env['res.country.state'].search([('code', '=', addr[0])])
                        #                     zip_code = addr[1]
                        #         partner_id = self.env['res.partner'].create({
                        #             'member_ref': sh.row_values(rownum)[0],
                        #             'ref': sh.row_values(rownum)[1],
                        #             'name': 
                        #                 sh.row_values(rownum)[2] + sh.row_values(rownum)[3] + sh.row_values(rownum)[4] + sh.row_values(rownum)[5],
                        #             'nickname': sh.row_values(rownum)[7],
                        #             'nickname_preferred': sh.row_values(rownum)[8],
                        #             'maiden_name': sh.row_values(rownum)[9],
                        #             'gender': gender,
                        #             'relationship_type_id': relationship_type_id and relationship_type_id.id,
                        #             'marital_status': str(sh.row_values(rownum)[19]).rstrip('0').rstrip('.'),
                        #             'phone': sh.row_values(rownum)[20],
                        #             'unlisted': str(sh.row_values(rownum)[22]).rstrip('0').rstrip('.'),
                        #             'mobile': sh.row_values(rownum)[23],
                        #             'email': sh.row_values(rownum)[24],
                        #             'occupation': occupation_id and occupation_id.id,
                        #             'religion_id': religion_id and religion_id.id,
                        #             'comment': sh.row_values(rownum)[32] + '\n' + sh.row_values(rownum)[33],
                        #             'street': sh.row_values(rownum)[37],
                        #             'city': city,
                        #             'state_id': state_id and state_id.id,
                        #             'zip': zip_code
                        #         })
                        #         if partner_id:
                        #             if sh.row_values(rownum)[12]:
                        #                 partner_id.write(
                        #                     {'death_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[12], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                        #             if sh.row_values(rownum)[11]:
                        #                 partner_id.write(
                        #                     {'date_of_birth': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[11], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                        #             if sh.row_values(rownum)[30]:
                        #                 partner_id.write(
                        #                     {'write_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[30], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                        #         # stop
            except Exception as e:
                raise ValidationError(_(e))
        if self.file_type == 'ministry':
            try:
                counter = 0
                for wizard in self:
                    book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                    sh = book.sheet_by_index(0)
                    batchCount = 1
                    for rownum in range(sh.nrows):
                        counter += 1
                        if counter > 1:
                            minister_id = ''
                            partner_id = self.env['res.partner'].search([('member_ref', '=', sh.row_values(rownum)[0])])
                            if partner_id:
                                ministry_id = self.env['ministry.ministry'].search([('code', '=', str(sh.row_values(rownum)[1]).rstrip('0').rstrip('.'))])
                                if ministry_id:
                                    member_minister_id = self.env['minister.minister'].search([('member_id', '=', partner_id.id)])
                                    if member_minister_id:
                                        if ministry_id.id not in member_minister_id.ministry_ids.ids:
                                            member_minister_id.write({'ministry_ids': [(4, ministry_id.id)]})
                                    else:
                                        self.env['minister.minister'].create({'member_id':partner_id.id, 
                                                                              'ministry_ids':[(6, 0, [ministry_id.id])]})
                                    minister_id = self.env['member.minister.details'].search([('ministry_id', '=', ministry_id.id),
                                                                                              ('member_id', '=', partner_id.id)])
                                    if sh.row_values(rownum)[2] == 2:
                                        status = 'Retired'
                                    if sh.row_values(rownum)[1] == 1:
                                        status = 'Active'
                                    if sh.row_values(rownum)[2] == 8:
                                        status = 'Pending'
                                    if not minister_id:
                                        minister_id = partner_id.ministry_ids.create({'member_id': partner_id.id,
                                                                                      'ministry_id': ministry_id.id,
                                                                                      'ministry_status': status,
                                                                                    })
                                    else:
                                        minister_id.write({'ministry_status': status})
                                    if minister_id:
                                        if sh.row_values(rownum)[4]:
                                            minister_id.write(
                                                {'start_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[4], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                        if sh.row_values(rownum)[7]:
                                            minister_id.write(
                                                {'retired_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[7], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                        if sh.row_values(rownum)[5]:
                                            minister_id.write(
                                                {'renewal_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[5], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
            except Exception as e:
                raise ValidationError(_(e))                     
        if self.file_type == 'death_data':
            print("LDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",self.file_type)
            try:
                counter = 0
                for wizard in self:
                    book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                    print("book final:::::::::::::::::::::::::::::",book)
                    sh = book.sheet_by_index(0)
                    batchCount = 1
                    for rownum in range(sh.nrows):
                        counter += 1
                        if counter > 1:
                            partner_id = self.env['res.partner'].search([('member_ref', '=', sh.row_values(rownum)[0])])
                            if sh.row_values(rownum)[2]:
                                burial_place_id = self.env['burial.places'].search([('code', '=', str(sh.row_values(rownum)[2]).rstrip('0').rstrip('.'))])
                                if burial_place_id:
                                     burial_place = burial_place_id.id
                                else:
                                    burial_place = False
                            else: 
                                burial_place = False
                            if sh.row_values(rownum)[0]:
                                funeral_member_id = self.env['funeral.member.details'].search([('registration_member_id', '=', partner_id.id)])
                                if not funeral_member_id:
                                    if sh.row_values(rownum)[1]:
                                        death_date = datetime.strptime(sh.row_values(rownum)[1], '%m/%d/%Y')
                                    else:
                                        death_date = False
                                    funeral_reg_id = self.env['funeral.registration'].create(
                                        {'member_detail_ids': [(0,0, {'registration_member_id': partner_id.id,
                                         'date_of_death': death_date,
                                         'funeral_date': death_date,
                                         'cemetery': burial_place,
                                         'mass_service': str(sh.row_values(rownum)[3]).rstrip('0').rstrip('.')
                                        })]})
            except Exception as e:
                raise ValidationError(_(e))
        if self.file_type == 'sacrament':
            try:
                counter = 0
                for wizard in self:
                    book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                    sh = book.sheet_by_index(0)
                    batchCount = 1
                    for rownum in range(sh.nrows):
                        print("rownum:::::::::::::::::::::::::::::::::::",rownum)
                        counter += 1
                        if counter > 1:
                            partner_id = self.env['res.partner'].search([('member_ref', '=', sh.row_values(rownum)[0])])
                            if partner_id:
                                baptism_date = False
                                baptism_place = False
                                baptism_officiant = False
                                witness = ''
                                baptism_sacrament_id = self.env.ref('sacrament_management.sacrament_1')
                                if baptism_sacrament_id:
                                    member_sacrament_id = self.env['sacrament.member.details'].search([('member_id', '=', partner_id.id), ('sacrament_id', '=', baptism_sacrament_id.id)])
                                    if sh.row_values(rownum)[1] != 0:
                                        baptism_place_id = self.env['place.parish'].search([('code', '=', str(sh.row_values(rownum)[1]).rstrip('0').rstrip('.'))])
                                        if baptism_place_id:
                                            baptism_place = baptism_place_id.id
                                    if sh.row_values(rownum)[2]:
                                        baptism_date = datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[2], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                                    if sh.row_values(rownum)[3]:
                                        spl_word = '. '
                                        baptism_officiant_name = sh.row_values(rownum)[3].partition(spl_word)[2]
                                        officiant_id = self.env['res.partner'].search([('name', '=', sh.row_values(rownum)[3])])
                                        if officiant_id:
                                            officiant_id.write({'deacon': True, 'priest': True})
                                            baptism_officiant = officiant_id.id
                                        if not officiant_id:
                                            baptism_officiant_id = self.env['res.partner'].create(
                                                {'name': sh.row_values(rownum)[3], 'deacon': True, 'priest': True})
                                            baptism_officiant = baptism_officiant_id.id
                                    if sh.row_values(rownum)[4]:
                                        witness_1 = sh.row_values(rownum)[4]
                                        witness = witness_1
                                    if sh.row_values(rownum)[5]:
                                        if witness_1:
                                            witness = witness_1 + ',' + sh.row_values(rownum)[5]
                                        else:
                                            witness = sh.row_values(rownum)[5]
                                    if not member_sacrament_id:
                                        if baptism_date or baptism_place or baptism_officiant or baptism_witness:
                                            self.env['sacrament.member.details'].create({'member_id': partner_id.id, 
                                                                                         'sacrament_id': baptism_sacrament_id.id,
                                                                                         'scarament_type_id': baptism_sacrament_id.sacrament_type,
                                                                                         'date': baptism_date,
                                                                                         'location': baptism_place,
                                                                                         'officiant_id': baptism_officiant,
                                                                                         'witness': witness})
                                    else:
                                        member_sacrament_id.write({'date': baptism_date,
                                                                   'location': baptism_place,
                                                                   'officiant_id': baptism_officiant,
                                                                   'witness': witness})
                                penance_date = False
                                penance_place = False
                                penance_officiant = False
                                if sh.row_values(rownum)[6] != 0:
                                    penance_place_id = self.env['place.parish'].search([
                                        ('code', '=', str(sh.row_values(rownum)[6]).rstrip('0').rstrip('.'))])
                                    if penance_place_id:
                                        penance_place = penance_place_id.id
                                if sh.row_values(rownum)[7]:
                                    penance_date = datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[7], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                                penance_sacrament_id = self.env.ref('sacrament_management.sacrament_2')
                                if penance_sacrament_id:
                                    member_penance_sacrament_id = self.env['sacrament.member.details'].search([('member_id', '=', partner_id.id), ('sacrament_id', '=', penance_sacrament_id.id)])
                                    if not member_penance_sacrament_id:
                                        if penance_date or penance_place:
                                            self.env['sacrament.member.details'].create({'member_id': partner_id.id, 
                                                                                         'sacrament_id': penance_sacrament_id.id,
                                                                                         'scarament_type_id': penance_sacrament_id.sacrament_type,
                                                                                         'location': penance_place,
                                                                                         'date': penance_date})
                                    else:
                                        member_penance_sacrament_id.write({'location': penance_place,
                                                                           'date': penance_date})
                                eucharist_date = False
                                eucharist_place = False
                                eucharist_officiant = False
                                if sh.row_values(rownum)[8] != 0:
                                    eucharist_place_id = self.env['place.parish'].search([('code', '=', str(sh.row_values(rownum)[8]).rstrip('0').rstrip('.'))])
                                    if eucharist_place_id:
                                        eucharist_place = eucharist_place_id.id
                                if sh.row_values(rownum)[9]:
                                    eucharist_date = datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[9], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                                eucharist_sacrament_id = self.env.ref('sacrament_management.sacrament_3')
                                if eucharist_sacrament_id:
                                    member_eucharist_sacrament_id = self.env['sacrament.member.details'].search([('member_id', '=', partner_id.id), 
                                                                                                       ('sacrament_id', '=', eucharist_sacrament_id.id)])
                                    if not member_eucharist_sacrament_id:
                                        if eucharist_date or eucharist_place:
                                            self.env['sacrament.member.details'].create({'member_id': partner_id.id, 
                                                                                         'sacrament_id': eucharist_sacrament_id.id,
                                                                                         'scarament_type_id': eucharist_sacrament_id.sacrament_type,
                                                                                         'location': eucharist_place,
                                                                                         'date': eucharist_date})
                                    else:
                                        member_eucharist_sacrament_id.write({'location': eucharist_place,
                                                                             'date': eucharist_date})
                                confirmation_date = False
                                confirmation_place = False
                                confirmation_officiant = False
                                witness = ''
                                confirmation_sacrament_id = self.env.ref('sacrament_management.sacrament_4')
                                if confirmation_sacrament_id:
                                    member_confirmation_sacrament_id = self.env['sacrament.member.details'].search([('member_id', '=', partner_id.id), 
                                                                                                       ('sacrament_id', '=', confirmation_sacrament_id.id)])
                                    if sh.row_values(rownum)[10] != 0:
                                            confirmation_place_id = self.env['place.parish'].search(
                                                [('code', '=', str(sh.row_values(rownum)[10]).rstrip('0').rstrip('.'))])
                                            if confirmation_place_id:
                                                confirmation_place = confirmation_place_id.id
                                    if sh.row_values(rownum)[11]:
                                        confirmation_date = datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[11], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                                    if sh.row_values(rownum)[13]:
                                        spl_word = '. '
                                        confirmation_officiant_name = sh.row_values(rownum)[13].partition(spl_word)[2]
                                        confirmation_officiant_id = self.env['res.partner'].search([('name', '=', sh.row_values(rownum)[13])])
                                        if confirmation_officiant_id:
                                            confirmation_officiant_id.write({'deacon': True, 'priest': True})
                                            confirmation_officiant = confirmation_officiant_id.id
                                        if not confirmation_officiant_id:
                                            confirmation_officiant_id = self.env['res.partner'].create(
                                                {'name': sh.row_values(rownum)[13], 'deacon': True, 'priest': True})
                                            confirmation_officiant = confirmation_officiant_id.id
                                    if sh.row_values(rownum)[14]:
                                            witness_1 = sh.row_values(rownum)[14]
                                            witness = witness_1
                                    if sh.row_values(rownum)[15]:
                                        if witness_1:
                                            witness = witness_1 + ',' + sh.row_values(rownum)[15]
                                        else:
                                            witness = sh.row_values(rownum)[15]
                                    if not member_confirmation_sacrament_id:
                                        if confirmation_place or witness or confirmation_date or confirmation_officiant:
                                            self.env['sacrament.member.details'].create({'member_id': partner_id.id, 
                                                                                         'sacrament_id': confirmation_sacrament_id.id,
                                                                                         'scarament_type_id': confirmation_sacrament_id.sacrament_type,
                                                                                         'date': confirmation_date,
                                                                                         'location': confirmation_place,
                                                                                         'officiant_id': confirmation_officiant,
                                                                                         'witness': witness})
                                    else:
                                        member_confirmation_sacrament_id.write({'date': confirmation_date,
                                                                               'location': confirmation_place,
                                                                               'officiant_id': confirmation_officiant,
                                                                               'witness': witness})
                                marriage_date = False
                                marriage_place = False
                                marriage_officiant = False
                                witness = ''
                                if sh.row_values(rownum)[16] != 0:
                                    marriage_place_id = self.env['place.parish'].search([('code', '=', str(sh.row_values(rownum)[16]).rstrip('0').rstrip('.'))])
                                    if marriage_place_id:
                                        marriage_place = marriage_place_id.id
                                if sh.row_values(rownum)[17]:
                                    marriage_date = datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[17], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                                marriage_sacrament_id = self.env.ref('sacrament_management.sacrament_6')
                                if marriage_sacrament_id:
                                    member_marriage_sacrament_id = self.env['sacrament.member.details'].search([('member_id', '=', partner_id.id), 
                                                                                                                ('sacrament_id', '=', marriage_sacrament_id.id)])
                                    if sh.row_values(rownum)[19]:
                                        spl_word = '. '
                                        marriage_officiant_name = sh.row_values(rownum)[19].partition(spl_word)[2]
                                        marriage_officiant_id = self.env['res.partner'].search([('name', '=', sh.row_values(rownum)[19])])
                                        if marriage_officiant_id:
                                            marriage_officiant_id.write({'deacon': True, 'priest': True})
                                            marriage_officiant = marriage_officiant_id.id
                                        if not marriage_officiant_id:
                                            marriage_officiant_id = self.env['res.partner'].create(
                                                {'name': sh.row_values(rownum)[13], 'deacon': True, 'priest': True})
                                            marriage_officiant = marriage_officiant_id.id
                                    if sh.row_values(rownum)[20]:
                                        witness_1 = sh.row_values(rownum)[20]
                                        witness = witness_1
                                    if sh.row_values(rownum)[21]:
                                        if witness_1:
                                            witness = witness_1 + ',' + sh.row_values(rownum)[21]
                                        else:
                                            witness = sh.row_values(rownum)[21]
                                    if not member_marriage_sacrament_id:
                                        if marriage_place or witness or marriage_date or marriage_officiant:
                                            self.env['sacrament.member.details'].create({'member_id': partner_id.id, 
                                                                                         'sacrament_id': marriage_sacrament_id.id,
                                                                                         'scarament_type_id': marriage_sacrament_id.sacrament_type,
                                                                                         'date': marriage_date,
                                                                                         'officiant_id': marriage_officiant,
                                                                                         'location': marriage_place,
                                                                                         'witness': witness})
                                    else:
                                        member_marriage_sacrament_id.write({'date': marriage_date,
                                                                           'officiant_id': marriage_officiant,
                                                                           'location': marriage_place,
                                                                           'witness': witness})
                                ordination_date = False
                                ordination_place = False
                                ordination_officiant = False
                                if sh.row_values(rownum)[22] != 0:
                                    ordination_place_id = self.env['place.parish'].search([('code', '=', str(sh.row_values(rownum)[22]).rstrip('0').rstrip('.'))])
                                    if ordination_place_id:
                                        oridination_place = ordination_place_id.id
                                if sh.row_values(rownum)[23]:
                                    ordination_date = datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[23], book.datemode)), "%Y-%m-%d %H:%M:%S").date()
                                ordination_sacrament_id = self.env.ref('sacrament_management.sacrament_6')
                                if ordination_sacrament_id:
                                    member_sacrament_id = self.env['sacrament.member.details'].search([('member_id', '=', partner_id.id), 
                                                                                                       ('sacrament_id', '=', ordination_sacrament_id.id)])
                                    if not member_sacrament_id:
                                        if sh.row_values(rownum)[24]:
                                            spl_word = '. '
                                            ordination_officiant_name = sh.row_values(rownum)[24].partition(spl_word)[2]
                                            ordination_officiant_id = self.env['res.partner'].search([('name', '=', sh.row_values(rownum)[24])])
                                            if ordination_officiant_id:
                                                ordination_officiant_id.write({'deacon': True, 'priest': True})
                                                ordination_officiant = ordination_officiant_id.id
                                            if not ordination_officiant_id:
                                                ordination_officiant_id = self.env['res.partner'].create(
                                                    {'name': sh.row_values(rownum)[24], 'deacon': True, 'priest': True})
                                                ordination_officiant = ordination_officiant_id.id
                                        if ordination_place or ordination_date or ordination_officiant:
                                            self.env['sacrament.member.details'].create({'member_id': partner_id.id, 
                                                                                         'sacrament_id': ordination_sacrament_id.id,
                                                                                         'scarament_type_id': ordination_sacrament_id.sacrament_type,
                                                                                         'location': ordination_place,
                                                                                         'date': ordination_date,
                                                                                         'officiant_id': ordination_officiant})
            except Exception as e:
                raise ValidationError(_(e))