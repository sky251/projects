# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class ByTeacherWizard(models.TransientModel):
    _name = "by.teacher.wizard"
    _description = "By Teacher Details"

    cathechist_id = fields.Many2one('res.partner', 'Cathechist', copy=False)

    def print_by_teacher_details(self):
        by_teacher_list = []
        data = {
            'form': self.read()[0]
        }
        teacher_data = self.env['class.class'].search(
            [('cathechist', '=', self.cathechist_id.id)])
        if teacher_data:
            for details in teacher_data:
                if details.name:
                    class_name = details.name
                    student_data = self.env['allotment.allotment'].search(
                        [('class_id', '=', class_name)])
                    if student_data:
                        for details in student_data:
                            vals = {
                                'child_name': details.child_id.name,
                                'family': details.child_id.parent_id.name,
                                'family_code': details.child_id.parent_id.ref,
                                'date_of_birth': details.child_id.date_of_birth,
                                'term': details.level_id.term_id.name,
                                'cathechist_id': details.class_id.cathechist.name,
                                'level': details.level_id.name,
                                'session': details.session_id.name,
                                'class': details.class_id.name
                            }
                            if vals:
                                by_teacher_list.append(vals)
                        data['member'] = by_teacher_list
                        return self.env.ref('church_management.action_report_by_teacher_details').with_context(landscape=True).report_action(self, data=data)
                    else:
                        raise UserError(
                            _('No contents to display in the report. Hence, this report cannot be printed.'))
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        by_teacher_list = []
        data = {}
        teacher_data = self.env['class.class'].search(
            [('cathechist', '=', self.cathechist_id.id)])
        if teacher_data:
            for details in teacher_data:
                if details.name:
                    class_name = details.name
                    student_data = self.env['allotment.allotment'].search(
                        [('class_id', '=', class_name)])
                    if student_data:
                        for details in student_data:
                            vals = {
                                'child_name': details.child_id.name,
                                'family': details.child_id.parent_id.name,
                                'family_code': details.child_id.parent_id.ref,
                                'date_of_birth': details.child_id.date_of_birth,
                                'term': details.level_id.term_id.name,
                                'cathechist_id': details.class_id.cathechist.name,
                                'level': details.level_id.name,
                                'session': details.session_id.name,
                                'class': details.class_id.name
                            }
                            if vals:
                                by_teacher_list.append(vals)
                        data['member'] = by_teacher_list
                        return self.env.ref('church_management.action_report_by_teacher_details_xls').with_context(landscape=True).report_action(self, data=data)
                    else:
                        raise UserError(
                            _('No contents to display in the report. Hence, this report cannot be printed.'))
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))