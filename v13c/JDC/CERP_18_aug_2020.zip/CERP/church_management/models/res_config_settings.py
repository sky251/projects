# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models, _


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    fiscal_start_date = fields.Date('Start Date')
    fiscal_end_date = fields.Date('End Date')
    inactive_days = fields.Integer('Inactive Member Days')
    beginning_date = fields.Date('Beginning Date')
    ending_date = fields.Date('Ending Date')

    def set_values(self):
        super(ResConfigSettings, self).set_values()
        self.env['ir.config_parameter'].sudo().set_param(
            'fiscal_start_date', self.fiscal_start_date
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'fiscal_end_date', self.fiscal_end_date
        )
        self.env['ir.config_parameter'].sudo().set_param(
            'inactive_days', int(self.inactive_days)
        )
        # self.env['ir.config_parameter'].sudo().set_param(
        #     'beginning_date', self.beginning_date
        # )
        # self.env['ir.config_parameter'].sudo().set_param(
        #     'ending_date', self.ending_date
        # )

    @api.model
    def get_values(self):
        res = super(ResConfigSettings, self).get_values()
        fiscal_start_date = self.env['ir.config_parameter'].sudo().get_param(
            'fiscal_start_date'
        )
        fiscal_end_date = self.env['ir.config_parameter'].sudo().get_param(
            'fiscal_end_date'
        )
        inactive_days = self.env['ir.config_parameter'].sudo().get_param(
            'inactive_days'
        )
        # beginning_date = self.env['ir.config_parameter'].sudo().get_param(
        #     'beginning_date'
        # )
        # ending_date = self.env['ir.config_parameter'].sudo().get_param(
        #     'ending_date'
        # )
        res.update(fiscal_start_date=fiscal_start_date,fiscal_end_date=fiscal_end_date,inactive_days=int(inactive_days))
        return res