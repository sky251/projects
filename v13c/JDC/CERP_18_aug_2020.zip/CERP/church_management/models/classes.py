# -*- coding: utf-8 -*-
from odoo import fields, models, api


class Classes(models.Model):
    _name = 'class.class'
    _description = "Classes"

    cathechist = fields.Many2one('res.partner', 'Cathechist', copy=False)
    room_no = fields.Many2one('room.room', 'Room', copy=False)
    session_id = fields.Many2one('session.session', 'Sessions', copy=False)
    assistant = fields.Many2one('res.partner','Assistant', copy=False)
    teacher_max_capacity = fields.Integer('Teacher Capacity', copy=False)
    notes = fields.Text('Notes', copy=False)
    max_capacity = fields.Integer('Max Capacity', copy=False)
    name = fields.Char('Name', copy=False)
    is_unavailable = fields.Boolean('Unavailable', copy=False)
    class_count = fields.Integer('Class Count', compute="_get_class_count", copy=False)

    _sql_constraints = [('name_uniq', 'unique (name)', "Name already exists !")]

    @api.onchange('room_no')
    def onchange_room_no(self):
    	if self.room_no:
    		if self.room_no.max_capacity:
    			self.max_capacity = self.room_no.max_capacity
    	else:
    		self.max_capacity = False

    def _get_class_count(self):
        for rec in self:
            class_ids = self.env['allotment.allotment'].search([('class_id', '=', rec.id)])
            if class_ids:
                rec.class_count = len(class_ids.ids)
            else:
                rec.class_count = 0
            if rec.max_capacity != len(class_ids.ids):
                rec.write({'is_unavailable': False})
            if rec.max_capacity == len(class_ids.ids):
                rec.write({'is_unavailable': True})
