# -*- coding: utf-8 -*-
from odoo import fields, models, api
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta
from pytz import timezone
import pytz


class CalendarEvent(models.Model):
    _inherit = 'calendar.event'

    event_type = fields.Selection(
        [('recurring', 'Recurring'), ('single', 'Single')], copy=False)
    responsible_group_id = fields.Many2one(
        'ministry.group', 'Responsible Group', copy=False)
    resposible_member_id = fields.Many2one(
        'res.partner', 'Responsible Member', copy=False)
    officiant_id = fields.Many2one('res.partner', 'Officiant', copy=False)
    coordinator_id = fields.Many2one('res.partner', 'Coordinator', copy=False)
    room_id = fields.Many2one('room.room', 'Room', copy=False)
    media = fields.Selection(
        [('print', 'Print'), ('online', 'Online'), ('both', 'Both')], copy=False)
    end_date = fields.Datetime('End Date')
    assigned_to = fields.Many2many(
        'res.partner', 'partner_calendar_event_rel', copy=False)
    event_for = fields.Selection(
        [('funeral', 'Funeral'), ('sacrament', 'Sacrament'), ('ministry', 'Ministry')])
    mail_send = fields.Boolean('Mail Send', copy=False)

    @api.model_create_multi
    def create(self, vals_list):
        events = []
        res = super(CalendarEvent, self).create(vals_list)
        if vals_list and vals_list[0] and 'event_for' in vals_list[0] and vals_list[0]['event_for'] == 'ministry':
            minister_id = self.env['minister.minister'].search(
                [('member_id', '=', res.resposible_member_id.id)])
            if minister_id:
                if minister_id.calendar_event_ids:
                    events.extend(minister_id.calendar_event_ids.ids)
                events.append(res.id)
                minister_id.write(
                    {'calendar_event_ids': [(6, 0, set(events))]})
        return res

    def reminder_mail_send(self):
        current_uid = self._context.get('uid')
        user = self.env['res.users'].browse(current_uid).name
        user_tz = pytz.timezone(self.env.context.get('tz') or self.env.user.tz)
        current_date_time = pytz.utc.localize(
            datetime.now()).astimezone(user_tz)
        recurrent_event_ids = self.env['calendar.event'].search(
            [('recurrency', '=', True), ('mail_send', '=', False)])
        if recurrent_event_ids:
            for record in recurrent_event_ids:
                if record.start_datetime:
                    date_time = fields.Datetime.from_string(
                        record.start_datetime)
                    record_date_time = pytz.utc.localize(
                        date_time).astimezone(user_tz)
                    rec_time = datetime.strftime(
                        record_date_time, '%A, %d %B %Y %H:%M:%S')
                    record_date = record_date_time.date()
                    todays_date = current_date_time.date()
                    if (record_date == todays_date):
                        one_hour_date_time = record_date_time - \
                            timedelta(hours=1)
                        two_hour_date_time = record_date_time - \
                            timedelta(hours=1, minutes=59, seconds=59)
                        if (current_date_time >= two_hour_date_time) and (current_date_time <= one_hour_date_time):
                            event_list = {}
                            if record.assigned_to:
                                data = []
                                member_data = {}
                                for vals in record.assigned_to:
                                    member_data = {
                                        'name': vals.name,
                                        'email': vals.email
                                    }
                                    data.append(member_data)
                                event_list['event'] = data
                                for member in event_list['event']:
                                    template_rec = self.env.ref(
                                        'ministry_management.email_template_event_reminder')
                                    template_rec.write({
                                        'email_to': member['email'],
                                    })
                                    template_rec.with_context({'assigned_to': member['name'], 'event_name': record.name,
                                                               'date': rec_time, 'admin': user}).send_mail(
                                        self.id, force_send=True)
                                record.mail_send = True
                        else:
                            pass
