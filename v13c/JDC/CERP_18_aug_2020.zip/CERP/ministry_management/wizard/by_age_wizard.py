from odoo import models, fields, api, _
from datetime import datetime, date, time, timedelta
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError, ValidationError, Warning


class ByAgeWizard(models.TransientModel):
    _name = "ministry.by.age.wizard"
    _description = "By Age Group Wizard"

    age_from = fields.Integer(string='Age From', copy=False, default=False)
    age_to = fields.Integer(string='Age To', copy=False, default=False)

    def print_by_ministry_age(self):
        ministry_details = []
        data = {
            'form': self.read()[0]
        }
        minister_detail_ids = self.env['minister.details'].search([
            ('member_id.age', '>=', self.age_from),
            ('member_id.age', '<=', self.age_to)])
        if minister_detail_ids:
            for detail in minister_detail_ids:
                vals = {}
                if detail.member_id:
                    vals.update({'member_id': detail.member_id.name})
                else:
                    vals.update({'member_id': ''})
                if detail.family_id:
                    vals.update({'family_id': detail.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if detail.virtus_certification:
                    vals.update(
                        {'virtus_certification': detail.virtus_certification})
                else:
                    vals.update({'virtus_certification': 'False'})
                if detail.background_check:
                    vals.update({'background_check': detail.background_check})
                else:
                    vals.update({'background_check': 'False'})
                if detail.group_ministry_id:
                    vals.update({'ministry': detail.group_ministry_id.name})
                else:
                    vals.update({'ministry': ''})
                if detail.by_group_id:
                    vals.update(
                        {'schedulled_group_id': detail.by_group_id.name})
                else:
                    vals.update({'schedulled_group_id': ''})
                if vals:
                    ministry_details.append(vals)
            data['ministry'] = ministry_details
            return self.env.ref('ministry_management.action_report_by_ministry_age').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

 
    def get_report_xls(self):
        ministry_details = []
        data = {}
        minister_detail_ids = self.env['minister.details'].search([
            ('member_id.age', '>=', self.age_from),
            ('member_id.age', '<=', self.age_to)])
        if minister_detail_ids:
            for detail in minister_detail_ids:
                vals = {}
                if detail.member_id:
                    vals.update({'member_id': detail.member_id.name})
                else:
                    vals.update({'member_id': ''})
                if detail.family_id:
                    vals.update({'family_id': detail.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if detail.virtus_certification:
                    vals.update(
                        {'virtus_certification': 'True'})
                else:
                    vals.update({'virtus_certification': 'False'})
                if detail.background_check:
                    vals.update({'background_check': 'True'})
                else:
                    vals.update({'background_check': 'False'})
                if detail.group_ministry_id:
                    vals.update({'ministry': detail.group_ministry_id.name})
                else:
                    vals.update({'ministry': ''})
                if detail.by_group_id:
                    vals.update(
                        {'schedulled_group_id': detail.by_group_id.name})
                else:
                    vals.update({'schedulled_group_id': ''})
                if vals:
                    ministry_details.append(vals)
            data['ministry'] = ministry_details
            return self.env.ref('ministry_management.action_report_by_ministry_age_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

