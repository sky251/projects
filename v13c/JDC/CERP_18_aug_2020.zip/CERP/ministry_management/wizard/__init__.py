# Part of . See LICENSE file for full copyright and licensing details.

from . import minister_information_wizard
from . import by_ministry_wizard
from . import by_group_wizard
from . import by_ministry_type_wizard
from . import by_age_wizard
from . import by_event_wizard
from . import active_deactive_wizard
from . import by_age_wizard
from . import by_week_event_type_wizard