from odoo import models
import io

class ByAgeReportXls(models.AbstractModel):
    _name = 'report.sacrament_management.by_age_report_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format({'align': 'center','valign': 'vcenter','bold': True, 'size':16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format({'align': 'center','bold': True, 'size':12})
        worksheet = workbook.add_worksheet('By Age Group')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 15)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 15)
        worksheet.set_column('E:E', 15)
        worksheet.set_column('F:F', 20)
        worksheet.set_column('G:G', 25)
        worksheet.set_column('H:H', 20)
        worksheet.set_column('I:I', 25)
        worksheet.set_column('J:J', 25)
        worksheet.set_column('K:K', 25)
        worksheet.merge_range('A1:K2', "By Age Group Report", heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Age From:', cell_text_format)
        worksheet.write(
            row, column+1, (obj.age_from), f_format)
        worksheet.write(row+1, column, 'Age To:', cell_text_format)
        worksheet.write(row+1, column+1,
                        (obj.age_to), f_format)
        row += 3
        worksheet.write(row, column, 'Family', cell_text_format)
        worksheet.write(row, column+1, 'Family Code', cell_text_format)
        worksheet.write(row, column+2, 'Member', cell_text_format)
        worksheet.write(row, column+3, 'DOB', cell_text_format)
        worksheet.write(row, column+4, 'Age', cell_text_format)
        worksheet.write(row, column+5, 'Date of Sacrament', cell_text_format)
        worksheet.write(row, column+6, 'Sacrament', cell_text_format)
        worksheet.write(row, column+7, 'Sacrament Type', cell_text_format)
        worksheet.write(row, column+8, 'Location', cell_text_format)
        worksheet.write(row, column+9, 'Officiant', cell_text_format)
        worksheet.write(row, column+10, 'Completed', cell_text_format)
        row += 1
        age_data = obj.get_report_xls()
        for record in age_data['data']['sacrament']:
            row += 1
            worksheet.write(row, column, record['family_id'], f_format)
            worksheet.write(row, column+1, record['family_code'], f_format)
            worksheet.write(row, column+2, record['registration_member_id'], f_format)
            worksheet.write(row, column+3, record['date_of_birth'].strftime('%d/%m/%Y'), f_format)
            worksheet.write(row, column+4, record['age'], f_format)
            worksheet.write(row, column+5, record['date'].strftime('%d/%m/%Y'), f_format)
            worksheet.write(row, column+6, record['sacrament_id'], f_format)
            worksheet.write(row, column+7, record['sacrament_type'], f_format)
            worksheet.write(row, column+8, record['location'], f_format)
            worksheet.write(row, column+9, record['officiant'], f_format)
            worksheet.write(row, column+10, record['is_completed'], f_format)
