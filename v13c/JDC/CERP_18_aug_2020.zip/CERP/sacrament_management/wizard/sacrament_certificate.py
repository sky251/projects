# coding=utf-8
import datetime
from odoo import models, fields, api
import calendar
from datetime import date


class SacramentCertificate(models.TransientModel):
    _name = 'sacrament.certificate'
    
    certificate_body = fields.Html('Certificate Body')
    member_id = fields.Many2one('res.partner', 'Member', copy=False)
    digital_signature = fields.Binary(string='Signature')
    template_id = fields.Many2one('mail.template', string='Template', default="get_template")

   
    @api.onchange('template_id')
    def onchange_template(self):
        active_id = self._context.get('active_id')
        ctx = {}
        sacrament_id = self.env['sacrament.details'].browse(self._context.get('active_id'))
        if sacrament_id.registration_member_id.date_of_birth:
            month = sacrament_id.registration_member_id.date_of_birth.month
            month_name = calendar.month_name[month]
            ctx.update({'month_name': month_name})
        if sacrament_id.registration_member_id.parent_id:
            mother = sacrament_id.registration_member_id.parent_id.family_members.filtered(lambda x: x.relationship_type_id.code == 'mother')
            father = sacrament_id.registration_member_id.parent_id.family_members.filtered(lambda x: x.relationship_type_id.code == 'father')
            ctx.update({'mother':mother and mother.name or False,
                        'father': father and father.name or False,
                        })
        if sacrament_id.registration_id.officiant:
            ctx.update({'officiant': sacrament_id.registration_id.officiant.name})
        if sacrament_id.registration_id.date:
            month = sacrament_id.registration_id.date.month
            month_name = calendar.month_name[month]
            ctx.update({'day': sacrament_id.registration_id.date.day, 'month': month_name, 'year': sacrament_id.registration_id.date.year})
        today_date = date.today().strftime('%m/%d/%Y')
        ctx.update({'today_date':today_date})
        if sacrament_id.registration_id.sacrament:
            baptism_sacrament_id = sacrament_id.registration_id.sacrament.search([('name', '=ilike', 'baptism')])
            confirmation_sacrament_id = sacrament_id.registration_id.sacrament.search([('name', '=ilike', 'Confirmation')])
            eucharist_sacrament_id = sacrament_id.registration_id.sacrament.search([('name', '=ilike', 'Eucharist')])
            reconcilation_sacrament_id = sacrament_id.registration_id.sacrament.search([('name', '=ilike', 'Reconciliation')])
            annointing_sacrament_id = sacrament_id.registration_id.sacrament.search([('name', '=ilike', 'Annointing of the sick')])
            matrimony_sacrament_id = sacrament_id.registration_id.sacrament.search([('name', '=ilike', 'Matrimony')])
            holy_order_sacrament_id = sacrament_id.registration_id.sacrament.search([('name', '=ilike', 'Holy Orders')])
            communion_sacrament_id = sacrament_id.registration_id.sacrament.search([('name', '=ilike', 'First communion')])
            diaconate_sacrament_id = sacrament_id.registration_id.sacrament.search([('name', '=ilike', 'diaconate')])
            religious_sacrament_id = sacrament_id.registration_id.sacrament.search([('name', '=ilike', 'Religious profession')])
            if baptism_sacrament_id.name == sacrament_id.registration_id.sacrament.name:
                ctx.update({'baptism_event_date': sacrament_id.registration_id.date.strftime('%m/%d/%Y')})
                if sacrament_id.registration_id.location:
                    ctx.update({'baptism_location': sacrament_id.registration_id.location.name})
            if confirmation_sacrament_id.name == sacrament_id.registration_id.sacrament.name:
                ctx.update({'confirmation_event_date': sacrament_id.registration_id.date.strftime('%m/%d/%Y')})
                if sacrament_id.registration_id.location:
                    ctx.update({'confirmation_location': sacrament_id.registration_id.location.name})
            if eucharist_sacrament_id.name == sacrament_id.registration_id.sacrament.name:
                ctx.update({'eucharist_event_date': sacrament_id.registration_id.date.strftime('%m/%d/%Y')})
                if sacrament_id.registration_id.location:
                    ctx.update({'eucharist_location': sacrament_id.registration_id.location.name})
            if communion_sacrament_id.name == sacrament_id.registration_id.sacrament.name:
                ctx.update({'eucharist_event_date': sacrament_id.registration_id.date.strftime('%m/%d/%Y')})
                if sacrament_id.registration_id.location:
                    ctx.update({'eucharist_location': sacrament_id.registration_id.location.name})
            if reconcilation_sacrament_id.name == sacrament_id.registration_id.sacrament.name:
                ctx.update({'reconcilation_event_date': sacrament_id.registration_id.date.strftime('%m/%d/%Y')})
                if sacrament_id.registration_id.location:
                    ctx.update({'reconcilation_location': sacrament_id.registration_id.location.name})
            if annointing_sacrament_id.name == sacrament_id.registration_id.sacrament.name:
                ctx.update({'annointing_event_date': sacrament_id.registration_id.date.strftime('%m/%d/%Y')})
                if sacrament_id.registration_id.location:
                    ctx.update({'annointing_location': sacrament_id.registration_id.location.name})
            if matrimony_sacrament_id.name == sacrament_id.registration_id.sacrament.name:
                ctx.update({'matrimony_event_date': sacrament_id.registration_id.date.strftime('%m/%d/%Y')})
                if sacrament_id.registration_id.location:
                    ctx.update({'matrimony_location': sacrament_id.registration_id.location.name})
            if holy_order_sacrament_id.name == sacrament_id.registration_id.sacrament.name:
                ctx.update({'holy_order_event_date': sacrament_id.registration_id.date.strftime('%m/%d/%Y')})
                if sacrament_id.registration_id.location:
                    ctx.update({'holy_order_location': sacrament_id.registration_id.location.name})
            if diaconate_sacrament_id.name == sacrament_id.registration_id.sacrament.name:
                ctx.update({'holy_order_event_date': sacrament_id.registration_id.date.strftime('%m/%d/%Y')})
                if sacrament_id.registration_id.location:
                    ctx.update({'holy_order_location': sacrament_id.registration_id.location.name})
            if religious_sacrament_id.name == sacrament_id.registration_id.sacrament.name:
                ctx.update({'religious_event_date': sacrament_id.registration_id.date.strftime('%m/%d/%Y')})
                if sacrament_id.registration_id.location:
                    ctx.update({'religious_location': sacrament_id.registration_id.location.name})
        if sacrament_id.sponsors:
            ctx.update({'sponsor': sacrament_id.sponsors.name})
        if self.template_id:
            body_html = self.env['mail.template'].with_context(ctx)._render_template(self.template_id.body_html, self._context.get('active_model'), active_id,
                                                          post_process=False)
            self.certificate_body = body_html

    def print_certificate(self):
        if self.template_id:
            active_id = self._context.get('active_id')
            sacrament_id = self.env['sacrament.details'].browse(self._context.get('active_id'))
            sacrament_id.write({'certificate_printed': True})
            return self.env.ref('sacrament_management.sacrament_certificate_report').report_action(self)
        else:
            raise ValidationError(_('Please select template first'))