# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import api, fields, models

class ReportRegisteredMember(models.AbstractModel):
    _name = 'report.church_management.report_new_registered_members'

    @api.model
    def _get_report_values(self, docids, data=None):
        members = []
        self.model = self.env.context.get('active_model')
        docs = self.env[self.model].browse(self.env.context.get('active_ids', []))
        if data['members']:
            for member in data['members']:
                member_id = self.env['res.partner'].search([('id', '=', member)])
                members.append(member_id)
        return {
            'doc_ids': docids,
            'doc_model': self.model,
            'docs': docs,
            'members': members
        }

class RegisteredMemberReportXls(models.AbstractModel):
    _name = 'report.church_management.report_new_registered_members_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format(
            {'align': 'center', 'valign': 'vcenter', 'bold': True, 'size': 16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format(
            {'align': 'center', 'bold': True, 'size': 12})
        worksheet = workbook.add_worksheet('Newly Registered Members')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 20)
        worksheet.merge_range('A1:C2', "Newly Registered Members Details", heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'From Date:', cell_text_format)
        worksheet.write(
            row, column+1, (obj.date_from).strftime('%d/%m/%Y'), f_format)
        worksheet.write(row+1, column, 'To Date:', cell_text_format)
        worksheet.write(row+1, column+1,
                        (obj.date_to).strftime('%d/%m/%Y'), f_format)
        row += 3
        worksheet.write(row, column, 'Registration Date', cell_text_format)
        worksheet.write(row, column+1, 'Family Name', cell_text_format)
        worksheet.write(row, column+2, 'Family ID', cell_text_format)
        row += 1
        new_member = obj.get_report_xls()
        for record in new_member['data']['member']:
            row += 1
            if record['create_date']:
                worksheet.write(row, column, record['create_date'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column, '', f_format)
            if record['display_name']:
                worksheet.write(row, column+1, record['display_name'], f_format)
            else:
                worksheet.write(row, column+1, '', f_format)
            if record['ref']:
                worksheet.write(row, column+2, record['ref'], f_format)
            else:
                worksheet.write(row, column+2, '', f_format)
