from odoo import models
import io

class DonationByFamilyReportXls(models.AbstractModel):
    _name = 'report.church_management.report_donation_by_family_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format(
            {'align': 'center', 'valign': 'vcenter', 'bold': True, 'size': 16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format(
            {'align': 'center', 'bold': True, 'size': 12})
        worksheet = workbook.add_worksheet('Donation-By Family')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 20)
        worksheet.merge_range('A1:D2', "%s's Family Donation Report" %(obj.family_id.name), heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Family Code:', cell_text_format)
        worksheet.write(row, column+1, obj.family_code, f_format)
        row += 2
        worksheet.write(row, column, 'Envelope No.', cell_text_format)
        worksheet.write(row, column+1, 'Donation Date', cell_text_format)
        worksheet.write(row, column+2, 'Type', cell_text_format)
        worksheet.write(row, column+3, 'Amount', cell_text_format)
        row += 1
        member_data = obj.get_report_xls()
        for record in member_data['data']['member']:
            row += 1
            if record['envelope_no']:
                worksheet.write(row, column, record['envelope_no'], f_format)
            else:
                worksheet.write(row, column, '', f_format)
            if record['donation_date']:
                worksheet.write(row, column+1, record['donation_date'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+1, '', f_format)
            # if record['type']:
            #     worksheet.write(row, column+2, record['type'], f_format)
            # else:
            #     worksheet.write(row, column+2, '', f_format)
            if record['amount']:
                worksheet.write(row, column+2, record['amount'], f_format)
            else:
                worksheet.write(row, column+2, '', f_format)
    
# class DonationByTypeReportXls(models.AbstractModel):
#     _name = 'report.church_management.report_donation_by_type_xls'
#     _inherit = 'report.report_xlsx.abstract'

#     def generate_xlsx_report(self, workbook, data, obj):
#         heading_format = workbook.add_format(
#             {'align': 'center', 'valign': 'vcenter', 'bold': True, 'size': 16})
#         f_format = workbook.add_format({'align': 'center'})
#         cell_text_format = workbook.add_format(
#             {'align': 'center', 'bold': True, 'size': 12})
#         worksheet = workbook.add_worksheet('Donation-By Type')
#         worksheet.set_column('A:A', 25)
#         worksheet.set_column('B:B', 25)
#         worksheet.set_column('C:C', 20)
#         worksheet.set_column('D:D', 20)
#         worksheet.merge_range('A1:D2', "By Type Donation Report", heading_format)
#         row = 4
#         column = 0
#         worksheet.write(row, column, 'Type:', cell_text_format)
#         worksheet.write(row, column+1, obj.donation_type, f_format)
#         row += 2
#         worksheet.write(row, column, 'Envelope No.', cell_text_format)
#         worksheet.write(row, column+1, 'Family', cell_text_format)
#         worksheet.write(row, column+2, 'Donation Date', cell_text_format)
#         worksheet.write(row, column+3, 'Amount', cell_text_format)
#         row += 1
#         member_data = obj.get_report_xls()
#         for record in member_data['data']['member']:
#             row += 1
#             if record['envelope_no']:
#                 worksheet.write(row, column, record['envelope_no'], f_format)
#             else:
#                 worksheet.write(row, column, '', f_format)
#             if record['family']:
#                 worksheet.write(row, column+1, record['family'], f_format)
#             else:
#                 worksheet.write(row, column+1, '', f_format)
#             if record['donation_date']:
#                 worksheet.write(row, column+2, record['donation_date'].strftime('%d/%m/%Y'), f_format)
#             else:
#                 worksheet.write(row, column+2, '', f_format)
#             if record['amount']:
#                 worksheet.write(row, column+3, record['amount'], f_format)
#             else:
#                 worksheet.write(row, column+3, '', f_format)

class DonationByDurationReportXls(models.AbstractModel):
    _name = 'report.church_management.report_donation_by_duration_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format(
            {'align': 'center', 'valign': 'vcenter', 'bold': True, 'size': 16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format(
            {'align': 'center', 'bold': True, 'size': 12})
        worksheet = workbook.add_worksheet('Donation-By Duration')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 20)
        worksheet.merge_range('A1:D2', "Donation Report - By Duration", heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'From Date:', cell_text_format)
        worksheet.write(
            row, column+1, (obj.date_from).strftime('%d/%m/%Y'), f_format)
        worksheet.write(row+1, column, 'To Date:', cell_text_format)
        worksheet.write(row+1, column+1,
                        (obj.date_to).strftime('%d/%m/%Y'), f_format)
        row += 3
        worksheet.write(row, column, 'Envelope No.', cell_text_format)
        worksheet.write(row, column+1, 'Family', cell_text_format)
        worksheet.write(row, column+2, 'Donation Date', cell_text_format)
        worksheet.write(row, column+3, 'Amount', cell_text_format)
        row += 1
        member_data = obj.get_report_xls()
        for record in member_data['data']['member']:
            row += 1
            if record['envelope_no']:
                worksheet.write(row, column, record['envelope_no'], f_format)
            else:
                worksheet.write(row, column, '', f_format)
            if record['family']:
                worksheet.write(row, column+1, record['family'], f_format)
            else:
                worksheet.write(row, column+1, '', f_format)
            if record['donation_date']:
                worksheet.write(row, column+2, record['donation_date'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+2, '', f_format)
            if record['amount']:
                worksheet.write(row, column+3, record['amount'], f_format)
            else:
                worksheet.write(row, column+3, '', f_format)
