# -*- coding: utf-8 -*-
from odoo import fields, models

class Language(models.Model):
    _name = 'language.language'

    name = fields.Char('Language')
    code = fields.Char('Code')