# -*- coding: utf-8 -*-
from odoo import fields, models

class Skill(models.Model):
    _name = 'skill.skill'

    name = fields.Char('Skill')
    code = fields.Char('Code')