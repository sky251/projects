# -*- coding: utf-8 -*-
from odoo import fields, models,api,_
from datetime import timedelta, datetime
from odoo.exceptions import ValidationError

class EnvelopeBatch(models.Model):
    _name = 'envelope.batch'
    _description = 'Batches'

    name = fields.Char('Name', copy=False)
    date = fields.Date('Batch Date', copy=False, default=datetime.today())
    envelope_detail_ids = fields.One2many('donation.donation', 'batch_id', 'Envelope Details', copy=False)
    state = fields.Selection([('draft', 'Draft'), ('validate', 'Validated'), ('cancel', 'Cancelled')], string='Status', readonly=True, copy=False, index=True, tracking=3, default='draft')
    validate_date = fields.Date('Validate Date', copy=False)
    amount = fields.Float('Amount', copy=False)
    envelope_id = fields.Many2one('envelope.type', string="Envelope", copy=False, default=False)
    envelope_type = fields.Selection([('diocese', 'Diocese'), ('parish', 'Parish')], copy=False, string="Type")

    @api.onchange('envelope_type')
    def onchange_envelope_type(self):
        if self.envelope_type:
            self.envelope_id = False

    @api.constrains('amount')
    def amount_constarains(self):
        if self.amount <= 0.0:
            raise ValidationError(_("Enter Amount."))

    @api.model_create_multi
    def create(self, vals_list):
        """Create sequence for batches"""
        for vals in vals_list:
            vals['name'] = self.env['ir.sequence'].next_by_code('envelope.batch') or ('New')
        res = super(EnvelopeBatch, self).create(vals_list)
        return res

    def action_validate(self):
        self.state = 'validate'
        self.validate_date = datetime.today()

    def action_cancel(self):
        self.state = 'cancel'

    def action_draft(self):
        self.state = 'draft'