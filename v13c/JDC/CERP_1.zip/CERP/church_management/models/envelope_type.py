# coding=utf-8
from odoo import models, fields


class EnvelopeType(models.Model):
    _name = 'envelope.type'
    _description = 'Envelope Type'

    name = fields.Char('Name', copy=False)
    envelope_type = fields.Selection([('diocese', 'Diocese'), ('parish', 'Parish')], copy=False)
    product_id = fields.Many2one('product.product', string='Product', copy=False)