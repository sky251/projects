# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import time

from odoo import api, fields, models, _
from odoo.exceptions import ValidationError


class EnvelopeDetailWizard(models.TransientModel):
    _name = "envelope.detail.wizard"
    _description = "Envelope Details"


    def set_donation_product(self):
        """Set donation product by default"""
        donation_product_id = self.env.ref('church_management.product_product_donation')
        if donation_product_id:
            return donation_product_id

    def set_amount(self):
        """Set default amount"""
        amount = 0.0
        if self._context.get('active_id'):
            batch_id = self.env['envelope.batch'].browse(self._context.get('active_id'))
            if batch_id and not batch_id.amount <= 0.0:
                amount = batch_id.amount
                
        return amount

    product_id = fields.Many2one('product.product', 'Product', related="batch_id.envelope_id.product_id")
    # type = fields.Selection([('cash', 'Cash'),
    #                          ('cheque', 'Cheque')], 'Donation Method')
    amount = fields.Float('Amount', default=set_amount)
    cheque_number = fields. Char('Cheque No.')
    envelope_no = fields.Char('Envelope No.')
    family_id = fields.Many2one('res.partner', 'Family ID')
    batch_id = fields.Many2one('envelope.batch', 'Batch')
    envelope_id = fields.Many2one('envelope.type', string="Envelope Type", copy=False, default=False)
    envelope_type = fields.Selection([('diocese', 'Diocese'), ('parish', 'Parish')], copy=False, string="Recipient")

    @api.onchange('envelope_id')
    def onchange_envelope_id(self):
        if self.envelope_id:
            if not self.envelope_id.envelope_type or not self.envelope_id.product_id:
                raise ValidationError(_('Please fill all details.'))

    @api.onchange('envelope_type')
    def onchange_envelope_type(self):
        if self.envelope_type:
            self.envelope_id = False

    @api.onchange('envelope_no')
    def _onchange_envelope_no(self):
        envelope_no = []
        if self.envelope_no:
            partner_id = self.env['res.partner'].search([('envelope_ref', '=', self.envelope_no), ('is_company', '=', True)])
            if partner_id:
                for detail in self.batch_id.envelope_detail_ids:
                    if detail.envelope_no == self.envelope_no:
                        return {'warning':
                                {
                                    'title': _("Warning"),
                                    'message': 'Envelope is already scanned.Do you still want to continue?'
                                }
                        }
                    envelope_no.append(detail.envelope_no) 
                self.family_id = partner_id.id
            else:
                raise ValidationError(_("Invalid Envelope No."))

    def add_donation(self):
        envelope_no = []
        if self.amount <= 0.0:
            raise ValidationError(_("Enter Amount."))
        if self.envelope_no:
            partner_id = self.env['res.partner'].search([('envelope_ref', '=', self.envelope_no), ('is_company', '=', True)])
            return self.env['donation.donation'].create({
                    'product_id': self.product_id.id or False,
                    'amount': self.amount,
                    # 'type': self.type,
                    'cheque_number': self.cheque_number,
                    'envelope_no': self.envelope_no,
                    'family_id': partner_id.id,
                    'batch_id': self._context.get('active_id')
                })

class ScheulingWizard(models.TransientModel):
    _name = "scheduling.wizard"

    total_alloted_count = fields.Integer()
    not_alloted_count = fields.Integer()
    not_class_only = fields.Integer()
    total_allotments = fields.Integer()
