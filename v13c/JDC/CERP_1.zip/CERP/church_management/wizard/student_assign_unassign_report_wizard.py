# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class StudentReportAssignWizard(models.TransientModel):
    _name = "student.report.assign.wizard"
    _description = "Assign Student Report"

    report_type = fields.Selection([('assign', 'Assigned'),
                                    ('unassign', 'Unassigned')], string="Report Type", default='assign', copy=False)

    def print_student_assign_unassign_detail(self):
        student_details = []
        data = {
            'form': self.read()[0]
        }
        if (self.report_type == 'assign'):
            student_detail_ids = self.env['allotment.allotment'].search(
                [('assigned', '=', True)])
            if student_detail_ids:
                for detail in student_detail_ids:
                    vals = {}
                    vals.update({'child_id': detail.child_id.name})
                    if detail.child_id.parent_id:
                        vals.update(
                            {'family_id': detail.child_id.parent_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.child_id.date_of_birth:
                        vals.update({'dob': detail.child_id.date_of_birth})
                    else:
                        vals.update({'dob': ''})
                    if detail.session_id:
                        vals.update({'session_id': detail.session_id.name})
                    else:
                        vals.update({'session_id': ''})
                    if detail.level_id:
                        vals.update({'level_id': detail.level_id.name})
                    else:
                        vals.update({'level_id': ''})
                    if detail.class_id:
                        vals.update({'class_id': detail.class_id.name})
                    else:
                        vals.update({'class_id': ''})
                    if vals:
                        student_details.append(vals)
                data['student'] = student_details
                return self.env.ref('church_management.action_report_student_assign').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.report_type == 'unassign'):
            student_detail_ids = self.env['allotment.allotment'].search(
                [('assigned', '!=', True)])
            if student_detail_ids:
                for detail in student_detail_ids:
                    vals = {}
                    vals.update({'child_id': detail.child_id.name})
                    if detail.child_id.parent_id:
                        vals.update(
                            {'family_id': detail.child_id.parent_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.child_id.date_of_birth:
                        vals.update({'dob': detail.child_id.date_of_birth})
                    else:
                        vals.update({'dob': ''})
                    if detail.session_id:
                        vals.update({'session_id': detail.session_id.name})
                    else:
                        vals.update({'session_id': ''})
                    if detail.level_id:
                        vals.update({'level_id': detail.level_id.name})
                    else:
                        vals.update({'level_id': ''})
                    if vals:
                        student_details.append(vals)
                data['student'] = student_details
                return self.env.ref('church_management.action_report_student_unassign').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        student_details = []
        data = {}
        if (self.report_type == 'assign'):
            student_detail_ids = self.env['allotment.allotment'].search(
                [('assigned', '=', True)])
            if student_detail_ids:
                for detail in student_detail_ids:
                    vals = {}
                    vals.update({'child_id': detail.child_id.name})
                    if detail.child_id.parent_id:
                        vals.update(
                            {'family_id': detail.child_id.parent_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.child_id.date_of_birth:
                        vals.update({'dob': detail.child_id.date_of_birth})
                    else:
                        vals.update({'dob': ''})
                    if detail.session_id:
                        vals.update({'session_id': detail.session_id.name})
                    else:
                        vals.update({'session_id': ''})
                    if detail.level_id:
                        vals.update({'level_id': detail.level_id.name})
                    else:
                        vals.update({'level_id': ''})
                    if detail.class_id:
                        vals.update({'class_id': detail.class_id.name})
                    else:
                        vals.update({'class_id': ''})
                    if vals:
                        student_details.append(vals)
                data['student'] = student_details
                return self.env.ref('church_management.action_report_student_assign_xls').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.report_type == 'unassign'):
            student_detail_ids = self.env['allotment.allotment'].search(
                [('assigned', '!=', True)])
            if student_detail_ids:
                for detail in student_detail_ids:
                    vals = {}
                    vals.update({'child_id': detail.child_id.name})
                    if detail.child_id.parent_id:
                        vals.update(
                            {'family_id': detail.child_id.parent_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.child_id.date_of_birth:
                        vals.update({'dob': detail.child_id.date_of_birth})
                    else:
                        vals.update({'dob': ''})
                    if detail.session_id:
                        vals.update({'session_id': detail.session_id.name})
                    else:
                        vals.update({'session_id': ''})
                    if detail.level_id:
                        vals.update({'level_id': detail.level_id.name})
                    else:
                        vals.update({'level_id': ''})
                    if vals:
                        student_details.append(vals)
                data['student'] = student_details
                return self.env.ref('church_management.action_report_student_unassign_xls').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
