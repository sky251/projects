# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
import base64
import csv
from datetime import datetime, timedelta
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
import io
from io import StringIO
import logging
_logger = logging.getLogger(__name__)


class ImportCSVFileWizard(models.TransientModel):
    _name = "import.csv.file.wizard"
    _description = "Import CSV File"

    file = fields.Binary('CSV')
    filename = fields.Char('Filename')

    def check_child_data(self, row, family, term):
        child_vals = {}
        child_id_1 = ''
        level_id = ''
        session_id_1 = session_id_2 = ''
        if row:
            domain = [('company_type', '=', 'person'),
                      ('parent_id', '=', family.id), ('member_ref', '=', row[2])]
            if row[5]:
                domain += [('date_of_birth', '=', row[5])]
            child_id = self.env['res.partner'].search(domain)
            if child_id:
                child_id_1 = child_id
            else:
                child_name = row[3] + ' ' + row[4]
                child_id = self.env['res.partner'].create(
                    {'name': child_name, 'parent_id': family.id, 'type': 'private', 'company_type': 'person', 'phone': row[24], 'email': row[26], 'mobile': row[25], 'communication_mode': row[33], 'special_considerations': row[34], 'allergies': row[35]})
                child_id_1 = child_id
                if row[5]:
                    child_id_1.write({'date_of_birth': row[5]})
                if row[6]:
                    child_id_1.write({'gender': row[6]})
                if row[18]:
                    child_id_1.write({'house_no': row[18]})
                if row[19]:
                    child_id_1.write({'street': row[19]})
                if row[20]:
                    child_id_1.write({'street2': row[20]})
                if row[21]:
                    child_id_1.write({'city': row[21]})
                if row[23]:
                    child_id_1.write({'zip': row[23]})
            if child_id_1:
                level_id = self.env['level.level'].search(
                    [('name', '=', row[7])])
                if level_id:
                    level_id = level_id
                else:
                    level_id = self.env['level.level'].create(
                        {'name': row[7], 'term_id': term.id, 'description': row[7]})
                    level_id = level_id
                if row[8]:
                    session_id_1 = self.env['session.session'].search(
                        [('name', '=', row[8])])
                    if session_id_1:
                        session_id_1 = session_id_1
                    print()
                    # else:
                    #     session_id_1 = ''
                if row[9]:
                    session_id_2 = self.env['session.session'].search(
                        [('name', '=', row[9])])
                    if session_id_2:
                        session_id_2 = session_id_2
                    # else:
                    #     session_id_2 = ''
            if child_id_1 and level_id:
                child_vals = {
                    'registration_partner_id': child_id_1.id,
                    'level_id': level_id.id
                }
                if session_id_1:
                    child_vals.update({'session_choice_1': session_id_1.id})
                if session_id_2:
                    child_vals.update({'session_choice_2': session_id_2.id})
        return child_vals

    def import_members_data(self):
        """ Import Members Data"""
        if self.filename.endswith('.csv'):
            header_data = ''
            row_number = ''
            session_message = ''
            response_data = ''
            for wizard in self:
                csv_data = base64.b64decode(self.file)
                data_file = io.StringIO(csv_data.decode("utf-8"))
                data_file.seek(0)
                data = base64.b64decode(self.file).decode('UTF8')
                file_input = StringIO(data)
                file_input.seek(0)
                reader = csv.reader(file_input, delimiter=',',
                                    lineterminator='\r\n')
                counter = 1
                for row in reader:
                    if counter == 1:
                        header_data = row
                        counter += 1
                    else:
                        term_id = ''
                        family_id = ''
                        action = self.env.ref(
                            'church_management.response_act_window').read()[0]
                        term_id = self.env['term.term'].search(
                            [('start_date', '<=', row[36]), ('end_date', '>=', row[36])])
                        if term_id:
                            term_id = term_id
                            family_id = self.env['res.partner'].search(
                                [('company_type', '=', 'company'), ('ref', '=', row[0])], limit=1)
                            member_exist = self.env['member.registration'].search(
                                [('partner_id', '=', family_id.id), ('family_ref', '=', row[0]), ('status', '!=', 'validate')], order='id desc', limit=1)
                            if family_id:
                                family_id = family_id
                            else:
                                family_id = self.env['res.partner'].create(
                                    {'name': row[1], 'company_type': 'company'})
                                family_id = family_id
                                if row[1]:
                                    family_id.write({'ref': row[0], 'envelope_ref': row[0]})
                                if row[18]:
                                    family_id.write({'house_no': row[18]})
                                if row[19]:
                                    family_id.write({'street': row[19]})
                                if row[20]:
                                    family_id.write({'street2': row[20]})
                                if row[21]:
                                    family_id.write({'city': row[21]})
                                if row[23]:
                                    family_id.write({'zip': row[23]})
                            if member_exist:
                                child_vals = self.check_child_data(
                                    row, family_id, term_id)
                                if child_vals.get('session_choice_1') and child_vals['session_choice_1'] == '':
                                    if session_message == '':
                                        session_message = str(counter)
                                    else:
                                        session_message = session_message + \
                                            ',' + str(counter)
                                if member_exist.member_detail_ids.filtered(lambda x: x.registration_partner_id.id != child_vals['registration_partner_id']):
                                    member_exist.write(
                                        {'member_detail_ids': [(0, 0, child_vals)]})
                                if row[42] == 'paid':
                                    member_exist.action_validate()
                                    if member_exist.status == 'validate':
                                        account_move_id = self.env['account.move'].search([('partner_id', '=', member_exist.partner_id.id), ('invoice_origin', '=', member_exist.name)],limit=1)
                                        account_move_id.action_post()
                                        member_exist.write({'partial_paid': True})
                            if not member_exist:
                                child_vals = self.check_child_data(
                                    row, family_id, term_id)
                                if child_vals:
                                    if child_vals.get('session_choice_1') and child_vals['session_choice_1'] == '':
                                        if session_message == '':
                                            session_message = str(counter)
                                        else:
                                            session_message = session_message + \
                                                ',' + str(counter)
                                    member_registration_id = self.env['member.registration'].create(
                                        {'partner_id': family_id.id,
                                         'family_ref': family_id.ref,
                                         'new_registration': row[29],
                                         'registration_date': row[36],
                                         'term_id': term_id.id,
                                         'communication_mode': row[33],
                                         # 'is_sacramental_fee': row[39],
                                         # 'partial_paid': row[43],
                                         'preferred_phone': row[27],
                                         'other_phone': row[28],
                                         'member_detail_ids': [(0, 0, child_vals)]})
                                    if row[33] == 'text':
                                        member_registration_id.write({'phone': row[24]})
                                    if row[33] == 'email':
                                        member_registration_id.write({'email': row[26]})
                                    if row[42] == 'paid':
                                        member_registration_id.action_validate()
                                        if member_registration_id.status == 'validate':
                                            account_move_id = self.env['account.move'].search([('partner_id', '=', member_registration_id.partner_id.id), ('invoice_origin', '=', member_registration_id.name)],limit=1)
                                            account_move_id.action_post()
                                            member_registration_id.write({'partial_paid': True})
                        else:
                            if row_number == '':
                                row_number = str(counter)
                            else:
                                row_number = row_number + ',' + str(counter)
                        counter += 1
                if row_number:
                    response_data += "There is no valid Term defined for row number: %s. \n" % (
                        row_number)
                if session_message:
                    response_data += "There is no valid session for row number: %s. \n" % (
                        session_message)
                if counter >= len(row_number):
                    response_data += "Rest all the datas are successfully imported."
            action['context'] = {
                'default_validation_text': response_data}
            return action
        else:
            raise ValidationError(_('Invalid file!'))
