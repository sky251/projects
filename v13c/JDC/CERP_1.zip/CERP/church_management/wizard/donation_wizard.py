# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class DonationWizard(models.TransientModel):
    _name = "donation.wizard"
    _description = "Donations Details"

    report_type = fields.Selection([('by-family', 'By Family Report'), ('by-duration','By Duration Report')], string="Report Type", copy=False)
    family_id = fields.Many2one(
        'res.partner', string='Family Name', copy=False)
    family_code = fields.Char(string='Family Code',
                              related="family_id.ref", copy=False)
    donation_type = fields.Selection([('cash', 'Cash'),
                                      ('cheque', 'Cheque')], 'Type')
    date_from = fields.Date('From Date')
    date_to = fields.Date('To Date')

    def print_donation_details(self):
        donation_list = []
        data = {
            'form': self.read()[0]
        }
        if (self.report_type == 'by-family'):
            member_id = self.env['donation.donation'].search(
                [('family_id', '=', self.family_id.id)])
            if member_id:
                for details in member_id:
                    vals = {
                        'envelope_no': details.envelope_no,
                        'donation_date': details.donation_date,
                        # 'type': details.type,
                        'amount': details.amount,
                        'family': details.family_id.name,
                    }
                    if vals:
                        donation_list.append(vals)
                data['member'] = donation_list
                return self.env.ref('church_management.action_report_donation_by_family').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        # elif(self.report_type == 'by-type'):
        #     member_id = self.env['donation.donation'].search(
        #         [('type', '=', self.donation_type)])
        #     if member_id:
        #         for details in member_id:
        #             vals1 = {
        #                 'envelope_no': details.envelope_no,
        #                 'family': details.family_id.name,
        #                 'donation_date': details.donation_date,
        #                 'amount': details.amount,
        #             }
        #             if vals1:
        #                 donation_list.append(vals1)
        #         data['member'] = donation_list
        #         return self.env.ref('church_management.action_report_donation_by_type').with_context(landscape=True).report_action(self, data=data)
        #     else:
        #         raise UserError(
        #             _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.report_type == 'by-duration'):
            member_id = self.env['donation.donation'].search(
                [('donation_date', '>=', self.date_from), ('donation_date', '<=', self.date_to)])
            if member_id:
                for details in member_id:
                    vals1 = {
                        'envelope_no': details.envelope_no,
                        'family': details.family_id.name,
                        'donation_date': details.donation_date,
                        'amount': details.amount,
                    }
                    if vals1:
                        donation_list.append(vals1)
                data['member'] = donation_list
                return self.env.ref('church_management.action_report_donation_by_duration').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        donation_list = []
        data = {}
        if (self.report_type == 'by-family'):
            member_id = self.env['donation.donation'].search(
                [('family_id', '=', self.family_id.id)])
            if member_id:
                for details in member_id:
                    vals = {
                        'envelope_no': details.envelope_no,
                        'donation_date': details.donation_date,
                        # 'type': details.type,
                        'amount': details.amount,
                        'family': details.family_id.name,
                    }
                    if vals:
                        donation_list.append(vals)
                data['member'] = donation_list
                return self.env.ref('church_management.action_report_donation_by_family_xls').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        # elif(self.report_type == 'by-type'):
        #     member_id = self.env['donation.donation'].search(
        #         [('type', '=', self.donation_type)])
        #     if member_id:
        #         for details in member_id:
        #             vals1 = {
        #                 'envelope_no': details.envelope_no,
        #                 'family': details.family_id.name,
        #                 'donation_date': details.donation_date,
        #                 'amount': details.amount,
        #             }
        #             if vals1:
        #                 donation_list.append(vals1)
        #         data['member'] = donation_list
        #         return self.env.ref('church_management.action_report_donation_by_type_xls').with_context(landscape=True).report_action(self, data=data)
        #     else:
        #         raise UserError(
        #             _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.report_type == 'by-duration'):
            member_id = self.env['donation.donation'].search(
                [('donation_date', '>=', self.date_from), ('donation_date', '<=', self.date_to)])
            if member_id:
                for details in member_id:
                    vals1 = {
                        'envelope_no': details.envelope_no,
                        'family': details.family_id.name,
                        'donation_date': details.donation_date,
                        'amount': details.amount,
                    }
                    if vals1:
                        donation_list.append(vals1)
                data['member'] = donation_list
                return self.env.ref('church_management.action_report_donation_by_duration_xls').with_context(landscape=True).report_action(self, data=data)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
