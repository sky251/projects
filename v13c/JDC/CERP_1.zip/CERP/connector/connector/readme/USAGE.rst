This module does nothing on its own.  It is a ground for developing
advanced connector modules. For further information, please go on:
http://odoo-connector.com
