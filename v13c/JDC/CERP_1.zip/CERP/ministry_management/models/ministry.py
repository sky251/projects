# -*- coding: utf-8 -*-
from odoo import fields, models


class MinistryType(models.Model):
    _name = 'ministry.type'
    _description = "Ministry Type"

    name = fields.Char('Ministry Type', copy=False, default=False)
    code = fields.Char('Code', default=False, copy=False)
    ministry_ids = fields.One2many('ministry.ministry', 'ministry_type_id', 'Ministries', copy=False, default=False)


class Ministry(models.Model):
    _name = 'ministry.ministry'
    _description = "Ministries"

    name = fields.Char('Ministry', copy=False)
    ministry_type_id = fields.Many2one('ministry.type', 'Ministry Type', copy=False)
    ministry_certificate = fields.Binary('Ministry Certification', copy=False)
    background_check = fields.Boolean('Background Checks', copy=False)
    monthly = fields.Boolean('Frequency-Monthly', copy=False)
    virtus_frequency = fields.Boolean('Virtus Certification', copy=False)
    code = fields.Char('Code', copy=False, default=False)
    active = fields.Boolean('Active', copy=False, default=False)