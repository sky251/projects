# -*- coding: utf-8 -*-
from . import ministry
from . import ministry_group
from . import ministry_allotment
from . import res_partner
from . import minister
from . import calendar_event