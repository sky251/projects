# -*- coding: utf-8 -*-
from odoo import fields, models, _, api
from odoo.exceptions import ValidationError,UserError
import datetime


class MinisterDetails(models.Model):
    _name = 'minister.details'

    member_id = fields.Many2one('res.partner', 'Member', copy=False)
    family_id = fields.Many2one('res.partner', 'Family', related="member_id.parent_id", copy=False, default=False)
    virtus_certification = fields.Boolean('Virtus Certification', copy=False)
    background_check = fields.Boolean('Background Checks', copy=False)
    by_group_id = fields.Many2one('schedulling.by.group', 'By Group', ondelete="cascade")
    by_ministry_id = fields.Many2one('schedulling.by.ministry', 'Ministry', ondelete="cascade")
    group_ministry_id = fields.Many2one('ministry.ministry', copy=False, string="Ministry")
    event_id = fields.Many2one('calendar.event', related="by_group_id.event_id" ,copy=False, string='Event', store=True)
    group_id = fields.Many2one('ministry.group', copy=False, string="Ministry Group", related="by_group_id.allotment_group_id")
    schedulled_group_ids = fields.Many2many('schedulling.by.group', 'minister_details_schedulled_by_group_rel', string='Schedulled Group')
    ministry_id = fields.Many2one('ministry.ministry', copy=False, string="Ministry", related="by_ministry_id.allotment_ministry_id")
    event_ids = fields.Many2many('calendar.event', 'calendar_event_minister_detail_rel', copy=False, string='Events' ,compute="_get_events")
    assigned = fields.Boolean('Assign')
    group_ministry_ids = fields.Many2many('ministry.ministry', 'ministry_group_ministry_minister_details_rel', copy=False, related="by_group_id.ministry_ids")
    is_schedulled = fields.Boolean('Is schedulled?', default=False, copy=False)

    def unlink(self):
        context = self.env.context.copy()
        for rec in self:
            if rec.by_group_id and self.env.context  and self.env.context.get('by_group'):
                ministry_ids = self.search([('member_id', '=', rec.member_id.id),
                                            ('schedulled_group_ids', 'in', rec.by_group_id.id)])
                ministry_group_ids = self.search([('member_id', '=', rec.member_id.id),
                                                  ('group_ministry_id', '=', rec.by_ministry_id.allotment_ministry_id.id)])
                if ministry_ids:
                    if len(ministry_ids.schedulled_group_ids) == 1:
                        minister_ids = self.env['minister.minister'].search([('ministry_ids', 'in', rec.group_ministry_id.id), 
                                                                             ('member_id', '=', rec.member_id.id)])
                        if minister_ids:
                            ministries = [i for i in minister_ids.ministry_ids.ids if i != rec.group_ministry_id.id]
                            minister_ids.write({'ministry_ids': [(6,0,ministries)]})
                    else:
                        groups = [i for i in ministry_ids.schedulled_group_ids.ids if i != rec.by_group_id.id]
                        ministry_ids.write({'schedulled_group_ids': [(6,0,groups)]})
                        minister_ids = self.env['minister.minister'].search([('ministry_ids', 'in', rec.group_ministry_id.id), 
                                                                             ('member_id', '=', rec.member_id.id)])
                        if minister_ids:
                            ministries = [i for i in minister_ids.ministry_ids.ids if i != rec.group_ministry_id.id]
                            for group in minister_ids.schedulled_group_ids:
                                if rec.group_ministry_id.id in group.ministry_ids.ids and group.id != rec.by_group_id.id:
                                    ministries.append(rec.group_ministry_id.id)
                            minister_ids.write({'ministry_ids': [(6,0,ministries)]})
                    if minister_ids.schedulled_group_ids:
                        for group in minister_ids.schedulled_group_ids:
                            group_ministry = [x for x in group.ministry_ids.ids if x in minister_ids.ministry_ids.ids]
                            if rec.by_group_id == group:
                                ministry_ids = self.search([('member_id', '=', rec.member_id.id),
                                                            ('schedulled_group_ids', 'in', rec.by_group_id.id)])
                                group_ministry_ids = self.search([('member_id', '=', rec.member_id.id),
                                                                 ('group_ministry_id', '=', rec.group_ministry_id.id),
                                                                 ('by_group_id', '=', rec.by_group_id.id)])
                                if not ministry_ids and len(group_ministry_ids) == 1 or not ministry_ids and len(group_ministry_ids) == 0:
                                    minister_ids.write({'schedulled_group_ids': [(3, group.id)]})
                if ministry_group_ids:
                    ministry_group_ids.unlink()
                minister_group_ids = self.env['minister.minister'].search([('ministry_ids', 'in', rec.group_ministry_id.id), 
                                                                           ('member_id', '=', rec.member_id.id)])
                if minister_group_ids:
                    ministries = [i for i in minister_group_ids.ministry_ids.ids if i != rec.group_ministry_id.id]
                    ministry = minister_group_ids.ministry_ids.ids
                    minister_group_ids.write({'ministry_ids': [(6,0,ministries)]})
                    if minister_group_ids.schedulled_group_ids:
                        for group in minister_group_ids.schedulled_group_ids:
                            group_ministry = [x for x in group.ministry_ids.ids if x in minister_group_ids.ministry_ids.ids]
                            if group == rec.by_group_id:
                                group_ids = self.search([('member_id', '=', rec.member_id.id), ('group_ministry_id', '=', rec.group_ministry_id.id),
                                                         ('by_group_id', '=', group.id)])
                                group_ministry_ids = self.search([('member_id', '=', rec.member_id.id),
                                                                  ('schedulled_group_ids', 'in', group.id)])
                                if not group_ministry_ids and len(group_ids) == 1 or not group_ministry_ids and len(group_ids) == 0:
                                    minister_group_ids.write({'schedulled_group_ids': [(3, group.id)]})

            if rec.by_ministry_id and self.env.context  and self.env.context.get('by_ministry'):
                ministry_ids = self.search([('member_id', '=', rec.member_id.id),
                                            ('group_ministry_id', '=', rec.by_ministry_id.allotment_ministry_id.id)])
                if ministry_ids:
                    ministry_ids.unlink()
                minister_ids = self.env['minister.minister'].search([('ministry_ids', 'in', rec.by_ministry_id.allotment_ministry_id.id), 
                                                                     ('member_id', '=', rec.member_id.id)])
                if minister_ids:
                    ministries = [i for i in minister_ids.ministry_ids.ids if i != rec.by_ministry_id.allotment_ministry_id.id]
                    ministry = minister_ids.ministry_ids.ids
                    minister_ids.write({'ministry_ids': [(6,0,ministries)]})
                    if minister_ids.schedulled_group_ids:
                        ministry_groups = []
                        for group in minister_ids.schedulled_group_ids:
                            group_ministry = [x for x in group.ministry_ids.ids if x in minister_ids.ministry_ids.ids]
                            if group in rec.schedulled_group_ids:
                                group_ids = self.search([('member_id', '=', rec.member_id.id), ('group_ministry_id', '=', rec.by_ministry_id.allotment_ministry_id.id),
                                                         ('by_group_id', '=', group.id)])
                                ministry_group_ids = self.search([('member_id', '=', rec.member_id.id),
                                                                  ('schedulled_group_ids', 'in', group.id)])
                                if not group_ids and len(ministry_group_ids) == 1 or not group_ids and len(ministry_group_ids) == 0:
                                    minister_ids.write({'schedulled_group_ids': [(3, group.id)]})
            if rec.member_id:
                minister_id = self.env['minister.minister'].search([('member_id', '=', rec.member_id.id)])  
                for ministry in rec.member_id.ministry_ids:
                    if ministry.ministry_id not in minister_id.ministry_ids:
                        ministry.unlink()
                if not minister_id.schedulled_group_ids and not minister_id.ministry_ids:
                    minister_id.unlink()
        return super(MinisterDetails, self).unlink()

    @api.constrains('by_ministry_id')
    def ministry_constrain(self):
        if self.by_ministry_id.allotment_ministry_id:
            by_ministry_id = self.env['schedulling.by.ministry'].search([('allotment_ministry_id', '=', self.by_ministry_id.allotment_ministry_id.id)])
            if len(by_ministry_id) > 1:
                raise ValidationError(_('Ministry is already created.'))

    def _get_events(self):
        events = []
        for rec in self:
            if rec.schedulled_group_ids:
                for group in rec.schedulled_group_ids:
                    events.append(group.event_id.id)
            rec.event_ids = [(6, 0, events)]

    @api.onchange('group_ministry_id')
    def onchange_group_ministry_id(self):
        requirement = []
        domain = []
        if self.member_id and self.group_ministry_id:
            ministry = self.group_ministry_id
            if ministry.background_check:
                requirement.append('background_checks')
            if ministry.virtus_frequency:
                requirement.append('virtus_certification')
            if ministry.monthly:
                requirement.append('monthly')
            if 'monthly' in requirement and 'virtus_certification' not in requirement and 'background_checks' not in requirement:
                domain = [('monthly','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' in requirement and 'background_checks' not in requirement:
                domain = [('virtus_certification','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' not in requirement and 'background_checks' in requirement:
                domain = [('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' in requirement and 'background_checks' not in requirement:
                domain = ['|', ('virtus_certification','=', True), ('monthly','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' in requirement and 'background_checks' in requirement:
                domain = ['|', ('virtus_certification','=', True), ('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' not in requirement and 'background_checks' in requirement:
                domain = ['|', ('monthly','=', True), ('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' in requirement and 'background_checks' in requirement:
                domain = ['|', ('monthly','=', True), '|', ('background_checks','=', True), ('virtus_certification','=', True)]
            if domain:
                domain.append(('is_company', '=', False))
            member_ids = self.env['res.partner'].search(domain)
            if member_ids:
                if self.member_id not in member_ids:
                    raise ValidationError(_('Member is not available for this ministry.'))
            if not member_ids:
                    raise ValidationError(_('Member is not available for this ministry.'))

    @api.onchange('schedulled_group_ids')
    def onchange_schedulled_group(self):
        events = []
        if self.is_schedulled:
            raise ValidationError(_("You can link/unlink group from ministers menu."))
        if self.by_ministry_id.allotment_ministry_id:
            return {'domain': {'schedulled_group_ids': [('ministry_ids', 'in', self.by_ministry_id.allotment_ministry_id.id)]}}
        if self.schedulled_group_ids:
            for group in self.schedulled_group_ids:
                events.append(group.event_id.id)
            self.event_ids = [(6,0, events)]

    @api.onchange('by_ministry_id')
    def onchange_by_ministry(self):
        events = []
        if self.by_ministry_id.allotment_ministry_id:
            return {'domain': {'schedulled_group_ids': [('ministry_ids', 'in', self.by_ministry_id.allotment_ministry_id.id)]}}
        
    @api.onchange('member_id')
    def onchange_member(self):
        requirement = []
        domain = []
        if self.member_id:
            self.virtus_certification = self.member_id.virtus_certification
            self.background_check = self.member_id.background_checks
            self.family_id = self.member_id.parent_id and self.member_id.parent_id.id or False
        if self.by_ministry_id:
            ministry = self.by_ministry_id.allotment_ministry_id
            if ministry.background_check:
                requirement.append('background_checks')
            if ministry.virtus_frequency:
                requirement.append('virtus_certification')
            if ministry.monthly:
                requirement.append('monthly')
            if 'monthly' in requirement and 'virtus_certification' not in requirement and 'background_checks' not in requirement:
                domain = [('monthly','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' in requirement and 'background_checks' not in requirement:
                domain = [('virtus_certification','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' not in requirement and 'background_checks' in requirement:
                domain = [('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' in requirement and 'background_checks' not in requirement:
                domain = ['|', ('virtus_certification','=', True), ('monthly','=', True)]
            if 'monthly' not in requirement and 'virtus_certification' in requirement and 'background_checks' in requirement:
                domain = ['|', ('virtus_certification','=', True), ('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' not in requirement and 'background_checks' in requirement:
                domain = ['|', ('monthly','=', True), ('background_checks','=', True)]
            if 'monthly' in requirement and 'virtus_certification' in requirement and 'background_checks' in requirement:
                domain = ['|', ('monthly','=', True), '|', ('background_checks','=', True), ('virtus_certification','=', True)]
            if domain:
                domain.append(('is_company', '=', False))
                return {'domain': {'member_id': domain}}
        if self.by_group_id.allotment_group_id:
            group_id = self.by_group_id.allotment_group_id
            for ministry in group_id.ministry_ids:
                if ministry.background_check:
                    requirement.append('background_checks')
                if ministry.virtus_frequency:
                    requirement.append('virtus_certification')
                if ministry.monthly:
                    requirement.append('monthly')
                if 'monthly' in requirement and 'virtus_certification' not in requirement and 'background_checks' not in requirement:
                    domain = [('monthly','=', True)]
                if 'monthly' not in requirement and 'virtus_certification' in requirement and 'background_checks' not in requirement:
                    domain = [('virtus_certification','=', True)]
                if 'monthly' not in requirement and 'virtus_certification' not in requirement and 'background_checks' in requirement:
                    domain = [('background_checks','=', True)]
                if 'monthly' in requirement and 'virtus_certification' in requirement and 'background_checks' not in requirement:
                    domain = ['|', ('virtus_certification','=', True), ('monthly','=', True)]
                if 'monthly' not in requirement and 'virtus_certification' in requirement and 'background_checks' in requirement:
                    domain = ['|', ('virtus_certification','=', True), ('background_checks','=', True)]
                if 'monthly' in requirement and 'virtus_certification' not in requirement and 'background_checks' in requirement:
                    domain = ['|', ('monthly','=', True), ('background_checks','=', True)]
                if 'monthly' in requirement and 'virtus_certification' in requirement and 'background_checks' in requirement:
                    domain = ['|', ('monthly','=', True), '|', ('background_checks','=', True), ('virtus_certification','=', True)]
            if domain:
                domain.append(('is_company', '=', False))
                return {'domain': {'member_id': domain}}

    @api.model_create_multi
    def create(self, vals_list):
        ministries = []
        groups = []
        member_ministries = []
        events = []
        group_ministries = []
        group_events = []
        for vals in vals_list:
            if 'member_id' in vals and 'group_ministry_id' in vals:
                member_group_id = self.env['member.minister.details'].search([
                    ('member_id', '=', vals['member_id']), ('ministry_id', '=', vals['group_ministry_id'])])
                if 'assigned' in vals:
                    if vals['assigned']:
                        if not member_group_id:
                            self.env['member.minister.details'].create({'member_id': vals['member_id'],
                                                                        'ministry_id': vals['group_ministry_id'],
                                                                        'ministry_type_id': self.env['ministry.ministry'].browse(vals['group_ministry_id']).ministry_type_id.id})
                else:
                    member_group_id.unlink()
            vals['is_schedulled'] = True
        result = super(MinisterDetails, self).create(vals_list)
        for rec in result:
            if rec.by_group_id:
                member_group_id = self.env['member.minister.details'].search([('member_id', '=', rec.member_id.id),
                                                                              ('ministry_id', '=', rec.group_ministry_id.id)])
                if rec.assigned:
                    if not member_group_id:
                        self.env['member.minister.details'].create({'member_id': rec.member_id.id,
                                                                    'ministry_id': rec.group_ministry_id.id})
                    schedulling_ministry_id = self.env['schedulling.by.ministry'].search([('allotment_ministry_id', '=', rec.group_ministry_id.id)])
                    if schedulling_ministry_id:
                        group_id = self.search([('member_id', '=', rec.member_id.id), ('by_ministry_id', '=', schedulling_ministry_id.id)])
                        if not group_id:
                            self.create({'member_id': rec.member_id.id,
                                         'schedulled_group_ids': [(4, rec.by_group_id.id)],
                                         'by_ministry_id': schedulling_ministry_id.id,
                                         'assigned': True,
                                         'virtus_certification': rec.member_id.virtus_certification,
                                         'background_check': rec.member_id.background_checks,
                                         'is_schedulled': True,
                                         'event_ids': [(6, 0, [rec.by_group_id.event_id.id])]})
                        else:
                            scheduling_groups = []
                            if group_id.schedulled_group_ids:
                                scheduling_groups.extend(group_id.schedulled_group_ids.ids)
                                scheduling_groups.append(rec.by_group_id.id)
                            else:
                                scheduling_groups.append(rec.by_group_id.id)
                            if group_id.event_ids:
                                group_id.write({'schedulled_group_ids':[(6, 0, set(scheduling_groups))]})
                    minister_id = self.env['minister.minister'].search([('member_id', '=', rec.member_id.id)])
                    if not minister_id:
                        member_id = self.env['minister.minister'].create(
                            {'member_id': rec.member_id.id,
                             'family_id': rec.member_id.parent_id and rec.member_id.parent_id.id or False,
                             'ministry_ids': [(6,0, [rec.group_ministry_id.id])],
                             'schedulled_group_ids': [(6,0, [rec.by_group_id.id])],
                             'virtus_certification': rec.member_id.virtus_certification,
                             'background_check': rec.member_id.background_checks,
                             'calendar_event_ids': [(6, 0, [rec.event_id.id])]
                            })
                    else:
                        if rec.group_ministry_id:
                            group_ministries.append(rec.group_ministry_id.id)
                        if minister_id.ministry_ids:
                            group_ministries.extend(minister_id.ministry_ids.ids)
                        if minister_id.calendar_event_ids:
                            group_events.extend(minister_id.calendar_event_ids.ids)
                        if rec.event_id:
                            group_events.append(rec.event_id.id)
                        minister_id.write({'ministry_ids': [(6,0, set(group_ministries))], 'calendar_event_ids':[(6, 0, set(group_events))]})
                else:
                    schedulling_ministry_id = self.env['schedulling.by.ministry'].search([('allotment_ministry_id', '=', rec.group_ministry_id.id)])
                    if schedulling_ministry_id:
                        group_id = self.search([('member_id', '=', rec.member_id.id),
                                                ('schedulled_group_ids', 'in', rec.by_group_id.id),
                                                ('by_ministry_id', '=', schedulling_ministry_id.id)])
                        if group_id:
                            if len(group_id.schedulled_group_ids) == 1:
                                group_id.unlink()
                            else:
                                group_id.write({'schedulled_group_ids': [(3, rec.by_group_id.id)]})
                    minister_id = self.env['minister.minister'].search([('member_id', '=', rec.member_id.id)])
                    if minister_id:
                        groups = minister_id.schedulled_group_ids.ids or []
                        ministries = [i for i in minister_id.ministry_ids.ids if i != rec.group_ministry_id.id]
                        minister_id.write({'ministry_ids': [(6, 0, set(ministries))]})
                        for group in minister_id.schedulled_group_ids:
                            group_ministry = [x for x in group.ministry_ids.ids if x in minister_id.ministry_ids.ids]
                            if not group_ministry:
                                minister_id.write({'schedulled_group_ids': [(3, group.id)]})
                        if not minister_id.schedulled_group_ids and not minister_id.ministry_ids:
                            minister_id.unlink()
                    if member_group_id and rec.group_ministry_id not in minister_id.ministry_ids:
                        member_group_id.unlink()
            if rec.by_ministry_id:
                minister_id = self.env['minister.minister'].search([('member_id', '=', rec.member_id.id)])
                member_group_id = self.env['member.minister.details'].search([('member_id', '=', rec.member_id.id),
                                                                              ('ministry_id', '=', rec.by_ministry_id.allotment_ministry_id.id)])
                if rec.assigned:
                    for group in rec.schedulled_group_ids:
                        group_id = self.env['schedulling.by.group'].search([('id', '=', group.id)])
                        group_schedulled_id = self.search([('group_ministry_id', '=', rec.by_ministry_id.allotment_ministry_id.id),
                                                           ('member_id', '=', rec.member_id.id),
                                                           ('by_group_id', '=', group.id)])
                        if not group_schedulled_id and group_id:
                            self.create({'member_id': rec.member_id.id,
                                         'by_group_id': group.id,
                                         'group_ministry_id': rec.by_ministry_id.allotment_ministry_id.id,
                                         'assigned': True,
                                         'virtus_certification': rec.member_id.virtus_certification,
                                         'background_check': rec.member_id.background_checks,
                                         'is_schedulled': True,
                                         'event_id': group.event_id.id})
                    if not member_group_id:
                        self.env['member.minister.details'].create({'member_id': rec.member_id.id,
                                                                    'ministry_id': rec.by_ministry_id.allotment_ministry_id.id})
                    if not minister_id:
                        member_id = self.env['minister.minister'].create(
                            {'member_id': rec.member_id.id,
                             'family_id': rec.member_id.parent_id and rec.member_id.parent_id.id or False,
                             'ministry_ids': [(6,0, [rec.by_ministry_id.allotment_ministry_id.id])],
                             'schedulled_group_ids': [(6,0, set(rec.schedulled_group_ids.ids))],
                             'virtus_certification': rec.member_id.virtus_certification,
                             'background_check': rec.member_id.background_checks,
                             'calendar_event_ids': [(6, 0, [rec.event_id.id])]
                            })

                    else:
                        minister_groups = []
                        if rec.by_ministry_id:
                            group_ministries.append(rec.by_ministry_id.allotment_ministry_id.id)
                        if minister_id.ministry_ids:
                            group_ministries.extend(minister_id.ministry_ids.ids)
                        if minister_id.calendar_event_ids:
                            group_events.extend(minister_id.calendar_event_ids.ids)
                        if rec.event_id:
                            group_events.append(rec.event_id.id)
                        if minister_id.schedulled_group_ids:
                            minister_groups.extend(minister_id.schedulled_group_ids.ids)
                        if rec.schedulled_group_ids:
                            minister_groups.extend(rec.schedulled_group_ids.ids)
                        minister_id.write({'ministry_ids': [(6,0, set(group_ministries))],
                                           'calendar_event_ids':[(6, 0, set(group_events))],
                                           'schedulled_group_ids': [(6,0, set(minister_groups))]})
                else:
                    if minister_id:
                        groups = minister_id.schedulled_group_ids.ids or []
                        ministries = [i for i in minister_id.ministry_ids.ids if i != rec.by_ministry_id.allotment_ministry_id.id]
                        minister_id.write({'ministry_ids': [(6, 0, set(ministries))]})
                        for group in minister_id.schedulled_group_ids:
                            group_ministry = [x for x in group.ministry_ids.ids if x in minister_id.ministry_ids.ids]
                            if not group_ministry:
                                minister_id.write({'schedulled_group_ids': [(3, group.id)]})
                        if not minister_id.schedulled_group_ids and not minister_id.ministry_ids:
                            minister_id.unlink()
                    if rec.by_ministry_id.allotment_ministry_id not in minister_id.ministry_ids:
                        member_group_id.unlink()
            minister_id = self.env['minister.minister'].search([('member_id', '=', rec.member_id.id)])
            if minister_id:
                if not minister_id.ministry_ids and not minister_id.schedulled_group_ids:
                    minister_id.unlink()
        return result
        # for detail in res:
        #     if detail.assigned:
        #         minister_id = self.env['minister.minister'].search([('member_id', '=', detail.member_id.id)])
        #         member_id = self.env['res.partner'].browse(vals['member_id'])
        #         if not minister_id:
        #             if detail.by_group_id:
        #                 group_id = self.env['schedulling.by.group'].search([('id', '=', detail.by_group_id.id)])
        #                 events.append(group_id.event_id.id)
        #                 if detail.group_ministry_id:
        #                     ministries.append(detail.group_ministry_id.id)
        #                 groups.append(group_id.id)
        #                 member_group_ids = self.search([('by_group_id', '=', detail.by_group_id.id)])
        #                 for group in member_group_ids:
        #                     ministries.append(group.group_ministry_id.id)
        #                 groups.append(group.by_group_id.id)
        #             if detail.by_ministry_id:
        #                 ministry_id = self.env['schedulling.by.ministry'].search([('id', '=', detail.by_ministry_id.id)])
        #                 ministries.append(ministry_id.allotment_ministry_id.id)
        #                 if detail.schedulled_group_ids:
        #                     if len(detail.schedulled_group_ids) == 1:
        #                         groups.append(detail.schedulled_group_ids.id)
        #                     if len(detail.schedulled_group_ids) > 1:
        #                         groups.extend(detail.schedulled_group_ids.ids)
        #             member_id = self.env['minister.minister'].create({'member_id': member_id.id,
        #                                                               'family_id': member_id.parent_id and member_id.parent_id.id or False,
        #                                                               'ministry_ids': [(6,0, ministries)],
        #                                                               'schedulled_group_ids': [(6,0, set(groups))],
        #                                                               'virtus_certification': member_id.virtus_certification,
        #                                                               'background_check': member_id.background_checks,
        #                                                               'calendar_event_ids': [(6,0, set(events))]
        #                                                             })
        #         else:
        #             if detail.by_group_id:
        #                 group_id = self.env['schedulling.by.group'].search([('id', '=', detail.by_group_id.id)])
        #                 events.append(group_id.event_id.id)
        #                 groups.append(group_id.id)
        #                 if detail.group_ministry_id:
        #                     ministries.append(detail.group_ministry_id.id)
        #             if detail.by_ministry_id:
        #                 ministry_id = self.env['schedulling.by.ministry'].search([('id', '=', detail.by_ministry_id.id)])
        #                 ministries.append(ministry_id.allotment_ministry_id.id)
        #                 if detail.schedulled_group_ids:
        #                     if len(detail.schedulled_group_ids) == 1:
        #                         groups.append(detail.schedulled_group_ids.id)
        #                     if len(detail.schedulled_group_ids) > 1:
        #                         groups.extend(detail.schedulled_group_ids.ids)
        #             if minister_id.ministry_ids:
        #                 ministries.extend(minister_id.ministry_ids.ids)
        #             if minister_id.schedulled_group_ids:
        #                 if len(minister_id.schedulled_group_ids) == 1:
        #                     groups.append(minister_id.schedulled_group_ids.id)
        #                 if len(minister_id.schedulled_group_ids) > 1:
        #                     groups.extend(minister_id.schedulled_group_ids.ids)
        #             if minister_id.calendar_event_ids:
        #                 events.extend(minister_id.calendar_event_ids.ids)
        #                 minister_id.write({'ministry_ids': [(6,0, set(ministries))],
        #                                    'schedulled_group_ids':[(6,0, set(groups))], 
        #                                    'calendar_event_ids':[(6, 0, set(events))]})
        #         if detail.group_ministry_id:
        #             schedulling_ministry_id = self.env['schedulling.by.ministry'].search([('allotment_ministry_id', '=', detail.group_ministry_id.id)])
        #             if schedulling_ministry_id:
        #                 group_id = self.search([('member_id', '=', detail.member_id.id),
        #                                         ('schedulled_group_ids', 'in', res.by_group_id.id),
        #                                         ('by_ministry_id', '=', schedulling_ministry_id.id)])
        #                 if detail.assigned:
        #                     if not group_id:
        #                         self.create({'member_id': detail.member_id.id, 
        #                                      'schedulled_group_ids': [(4, detail.by_group_id.id)], 
        #                                      'by_ministry_id': schedulling_ministry_id.id,
        #                                      'virtus_certification': detail.member_id.virtus_certification,
        #                                      'background_check':  detail.member_id.background_checks,
        #                                      'family_id': detail.member_id.parent_id and detail.member_id.parent_id.id,
        #                                      'assigned':True})
        #                 else:
        #                     group_id.unlink()
        #         if detail.schedulled_group_ids:
        #             if detail.assigned:
        #                 for group in detail.schedulled_group_ids:
        #                     minister_detail_id = self.search([('member_id', '=', detail.member_id.id), ('by_group_id', '=', group.id)])
        #                     if not minister_detail_id:
        #                         self.create({'member_id': detail.member_id.id, 
        #                                      'by_group_id': group.id, 
        #                                      'group_ministry_id': detail.ministry_id.id,
        #                                      'assigned':True,
        #                                      'virtus_certification': detail.member_id.virtus_certification,
        #                                      'background_check':  detail.member_id.background_checks,
        #                                      'family_id': detail.member_id.parent_id and detail.member_id.parent_id.id,})
        #             else:
        #                 for group in detail.schedulled_group_ids:
        #                     minister_detail_id = self.search([('member_id', '=', detail.member_id.id), ('by_group_id', '=', group.id)])
        #                     if minister_detail_id:
        #                         minister_detail_id.unlink()

    # @api.onchange('schedulled_group_ids')
    # def onchange_schedulled_group(self):
    #     raise ValidationError(_("You can link/unlink group from ministers menu."))

    def write(self, vals):
        ministries = []
        member_ministries = []
        events = []
        schedulled_groups = []
        group_ministries = []
        group_events = []
        res = super(MinisterDetails, self).write(vals)
        for rec in self:
            if rec.by_group_id:
                member_group_id = self.env['member.minister.details'].search([('member_id', '=', self.member_id.id),
                                                                              ('ministry_id', '=', self.group_ministry_id.id)])
                if self.assigned:
                    if not member_group_id:
                        self.env['member.minister.details'].create({'member_id': rec.member_id.id,
                                                                    'ministry_id': rec.group_ministry_id.id})
                    schedulling_ministry_id = self.env['schedulling.by.ministry'].search([('allotment_ministry_id', '=', rec.group_ministry_id.id)])
                    if schedulling_ministry_id:
                        group_id = self.search([('member_id', '=', rec.member_id.id), ('by_ministry_id', '=', schedulling_ministry_id.id)])
                        if not group_id:
                            self.create({'member_id': rec.member_id.id,
                                         'schedulled_group_ids': [(4, rec.by_group_id.id)],
                                         'by_ministry_id': schedulling_ministry_id.id,
                                         'assigned': True,
                                         'virtus_certification': rec.member_id.virtus_certification,
                                         'background_check': rec.member_id.background_checks,
                                         'is_schedulled': True,
                                         'event_ids': [(6, 0, [rec.by_group_id.event_id.id])]})
                        else:
                            scheduling_groups = []
                            if group_id.schedulled_group_ids:
                                scheduling_groups.extend(group_id.schedulled_group_ids.ids)
                                scheduling_groups.append(rec.by_group_id.id)
                            else:
                                scheduling_groups.append(rec.by_group_id.id)
                            if group_id.event_ids:
                                group_id.write({'schedulled_group_ids':[(6, 0, set(scheduling_groups))]})
                    minister_id = self.env['minister.minister'].search([('member_id', '=', rec.member_id.id)])
                    if not minister_id:
                        member_id = self.env['minister.minister'].create(
                            {'member_id': rec.member_id.id,
                             'family_id': rec.member_id.parent_id and rec.member_id.parent_id.id or False,
                             'ministry_ids': [(6,0, [rec.group_ministry_id.id])],
                             'schedulled_group_ids': [(6,0, [rec.by_group_id.id])],
                             'virtus_certification': rec.member_id.virtus_certification,
                             'background_check': rec.member_id.background_checks,
                             'calendar_event_ids': [(6, 0, [rec.event_id.id])]
                            })
                    else:
                        if rec.group_ministry_id:
                            group_ministries.append(rec.group_ministry_id.id)
                        if minister_id.ministry_ids:
                            group_ministries.extend(minister_id.ministry_ids.ids)
                        if minister_id.calendar_event_ids:
                            group_events.extend(minister_id.calendar_event_ids.ids)
                        if rec.event_id:
                            group_events.append(rec.event_id.id)
                        minister_id.write({'ministry_ids': [(6,0, set(group_ministries))], 'calendar_event_ids':[(6, 0, set(group_events))]})
                else:
                    schedulling_ministry_id = self.env['schedulling.by.ministry'].search([('allotment_ministry_id', '=', rec.group_ministry_id.id)])
                    if schedulling_ministry_id:
                        group_id = self.search([('member_id', '=', rec.member_id.id),
                                                ('schedulled_group_ids', 'in', rec.by_group_id.id),
                                                ('by_ministry_id', '=', schedulling_ministry_id.id)])
                        if group_id:
                            if len(group_id.schedulled_group_ids) == 1:
                                group_id.unlink()
                            else:
                                group_id.write({'schedulled_group_ids': [(3, rec.by_group_id.id)]})
                    minister_id = self.env['minister.minister'].search([('member_id', '=', rec.member_id.id)])
                    if minister_id:
                        groups = minister_id.schedulled_group_ids.ids or []
                        ministries = [i for i in minister_id.ministry_ids.ids if i != rec.group_ministry_id.id]
                        minister_id.write({'ministry_ids': [(6, 0, set(ministries))]})
                        for group in minister_id.schedulled_group_ids:
                            group_ministry = [x for x in group.ministry_ids.ids if x in minister_id.ministry_ids.ids]
                            if not group_ministry:
                                minister_id.write({'schedulled_group_ids': [(3, group.id)]})
                        if not minister_id.schedulled_group_ids and not minister_id.ministry_ids:
                            minister_id.unlink()
                    if member_group_id and rec.group_ministry_id not in minister_id.ministry_ids:
                        member_group_id.unlink()
            if rec.by_ministry_id:
                minister_id = self.env['minister.minister'].search([('member_id', '=', rec.member_id.id)])
                member_group_id = self.env['member.minister.details'].search([('member_id', '=', rec.member_id.id),
                                                                              ('ministry_id', '=', rec.by_ministry_id.allotment_ministry_id.id)])
                if rec.assigned:
                    for group in rec.schedulled_group_ids:
                        group_id = self.env['schedulling.by.group'].search([('id', '=', group.id)])
                        group_schedulled_id = self.search([('group_ministry_id', '=', rec.by_ministry_id.allotment_ministry_id.id),
                                                           ('member_id', '=', rec.member_id.id),
                                                           ('by_group_id', '=', group.id)])
                        if not group_schedulled_id and group_id:
                            self.create({'member_id': rec.member_id.id,
                                         'by_group_id': group.id,
                                         'group_ministry_id': rec.by_ministry_id.allotment_ministry_id.id,
                                         'virtus_certification': rec.member_id.virtus_certification,
                                         'background_check': rec.member_id.background_checks,
                                         'assigned': True,
                                         'is_schedulled': True,
                                         'event_id': group.event_id.id})
                    if not member_group_id:
                        self.env['member.minister.details'].create({'member_id': rec.member_id.id,
                                                                    'ministry_id': rec.by_ministry_id.allotment_ministry_id.id})
                    if not minister_id:
                        member_id = self.env['minister.minister'].create(
                            {'member_id': rec.member_id.id,
                             'family_id': rec.member_id.parent_id and rec.member_id.parent_id.id or False,
                             'ministry_ids': [(6,0, [rec.by_ministry_id.allotment_ministry_id.id])],
                             'schedulled_group_ids': [(6,0, set(rec.schedulled_group_ids.ids))],
                             'virtus_certification': rec.member_id.virtus_certification,
                             'background_check': rec.member_id.background_checks,
                             'calendar_event_ids': [(6, 0, [rec.event_id.id])]
                            })

                    else:
                        minister_groups = []
                        if rec.by_ministry_id:
                            group_ministries.append(rec.by_ministry_id.allotment_ministry_id.id)
                        if minister_id.ministry_ids:
                            group_ministries.extend(minister_id.ministry_ids.ids)
                        if minister_id.calendar_event_ids:
                            group_events.extend(minister_id.calendar_event_ids.ids)
                        if rec.event_id:
                            group_events.append(rec.event_id.id)
                        if minister_id.schedulled_group_ids:
                            minister_groups.extend(minister_id.schedulled_group_ids.ids)
                        if rec.schedulled_group_ids:
                            minister_groups.extend(rec.schedulled_group_ids.ids)
                        minister_id.write({'ministry_ids': [(6,0, set(group_ministries))],
                                           'calendar_event_ids':[(6, 0, set(group_events))],
                                           'schedulled_group_ids': [(6,0, set(minister_groups))]})
                else:
                    if minister_id:
                        groups = minister_id.schedulled_group_ids.ids or []
                        ministries = [i for i in minister_id.ministry_ids.ids if i != rec.by_ministry_id.allotment_ministry_id.id]
                        minister_id.write({'ministry_ids': [(6, 0, set(ministries))]})
                        for group in minister_id.schedulled_group_ids:
                            group_ministry = [x for x in group.ministry_ids.ids if x in minister_id.ministry_ids.ids]
                            if not group_ministry:
                                minister_id.write({'schedulled_group_ids': [(3, group.id)]})
                        if not minister_id.schedulled_group_ids and not minister_id.ministry_ids:
                            minister_id.unlink()
                    if rec.by_ministry_id.allotment_ministry_id not in minister_id.ministry_ids:
                        member_group_id.unlink()
            minister_id = self.env['minister.minister'].search([('member_id', '=', rec.member_id.id)])
            if minister_id:
                if not minister_id.ministry_ids and not minister_id.schedulled_group_ids:
                    minister_id.unlink()

    # def write(self, vals):
    #     ministries = []
    #     member_ministries = []
    #     events = []
    #     schedulled_groups = []
    #     group_ministries = []
    #     group_events = []
    #     res = super(MinisterDetails, self).write(vals)
    #     if self.by_group_id:
    #         member_group_id = self.env['member.minister.details'].search([('member_id', '=', self.member_id.id), 
    #                                                                       ('ministry_id', '=', self.group_ministry_id.id)])
    #         if self.assigned:
    #             if not member_group_id:
    #                 self.env['member.minister.details'].create({'member_id': self.member_id.id,
    #                                                             'ministry_id': self.group_ministry_id.id})
    #             schedulling_ministry_id = self.env['schedulling.by.ministry'].search([('allotment_ministry_id', '=', self.group_ministry_id.id)])
    #             if schedulling_ministry_id:
    #                 group_id = self.search([('member_id', '=', self.member_id.id), ('schedulled_group_ids', 'in', self.by_group_id.id), ('by_ministry_id', '=', schedulling_ministry_id.id)])
    #                 if not group_id:
    #                     self.create({'member_id': self.member_id.id, 
    #                                  'schedulled_group_ids': [(4, self.by_group_id.id)], 
    #                                  'by_ministry_id': schedulling_ministry_id.id,
    #                                  'assigned': True})
    #             minister_id = self.env['minister.minister'].search([('member_id', '=', self.member_id.id)])
    #             if not minister_id:
    #                 member_id = self.env['minister.minister'].create(
    #                     {'member_id': self.member_id.id,
    #                      'family_id': self.member_id.parent_id and self.member_id.parent_id.id or False,
    #                      'ministry_ids': [(6,0, [self.group_ministry_id.id])],
    #                      'schedulled_group_ids': [(6,0, [self.by_group_id.id])],
    #                      'virtus_certification': self.member_id.virtus_certification,
    #                      'background_check': self.member_id.background_checks,
    #                      'calendar_event_ids': [(6, 0, [self.event_id.id])]
    #                     })
    #             else:
    #                 if self.group_ministry_id:
    #                     group_ministries.append(self.group_ministry_id.id)
    #                 if minister_id.ministry_ids:
    #                     group_ministries.extend(minister_id.ministry_ids.ids)
    #                 if minister_id.calendar_event_ids:
    #                     group_events.extend(minister_id.calendar_event_ids.ids)
    #                 if self.event_id:
    #                     group_events.append(self.event_id.id)
    #                 minister_id.write({'ministry_ids': [(6,0, set(group_ministries))], 'calendar_event_ids':[(6, 0, set(group_events))]})
    #         else:
    #             if member_group_id:
    #                 member_group_id.unlink()
    #             schedulling_ministry_id = self.env['schedulling.by.ministry'].search([('allotment_ministry_id', '=', self.group_ministry_id.id)])
    #             if schedulling_ministry_id:
    #                 group_id = self.search([('member_id', '=', self.member_id.id), 
    #                                         ('schedulled_group_ids', 'in', self.by_group_id.id), 
    #                                         ('by_ministry_id', '=', schedulling_ministry_id.id)])
    #                 if group_id:
    #                     if len(group_id.schedulled_group_ids) == 1:
    #                         group_id.unlink()
    #                     else:
    #                         group_id.write({'schedulled_group_ids': [(3, self.by_group_id.id)]})
    #             minister_id = self.env['minister.minister'].search([('member_id', '=', self.member_id.id)])
    #             if minister_id:
    #                 groups = minister_id.schedulled_group_ids.ids or []
    #                 ministries = [i for i in minister_id.ministry_ids.ids if i != self.group_ministry_id.id]
    #                 minister_id.write({'ministry_ids': [(6, 0, set(ministries))]})
    #                 for group in minister_id.schedulled_group_ids:
    #                     group_ministry = [x for x in group.ministry_ids.ids if x in minister_id.ministry_ids.ids]
    #                     if not group_ministry:
    #                         minister_id.write({'schedulled_group_ids': [(3, group.id)]})
    #                 if not minister_id.schedulled_group_ids and not minister_id.ministry_ids:
    #                     minister_id.unlink()
    #     if self.by_ministry_id:"${object.company_id.name | safe}" <${(object.company_id.email or user.email) | safe}>
    #         print("ministry id:;;;;;;;;self;;;;;;;;;;;;;;;;;;;;;;;;;",self.by_ministry_id)

        # if self.group_ministry_id:
        #     print("HGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGGG",self.group_ministry_id)
        #     member_group_id = self.env['member.minister.details'].search([('member_id', '=', self.member_id.id), 
        #                                                                   ('ministry_id', '=', self.group_ministry_id.id)])
        #     if self.assigned:
        #         if not member_group_id:
        #             self.env['member.minister.details'].create({'member_id': self.member_id.id,
        #                                                         'ministry_id': self.group_ministry_id.id})
        #         schedulling_ministry_id = self.env['schedulling.by.ministry'].search([('allotment_ministry_id', '=', self.group_ministry_id.id)])
        #         if schedulling_ministry_id:
        #             group_id = self.search([('member_id', '=', self.member_id.id), ('schedulled_group_ids', 'in', self.by_group_id.id), ('by_ministry_id', '=', schedulling_ministry_id.id)])
        #             if not group_id:
        #                 self.create({'member_id': self.member_id.id, 
        #                              'schedulled_group_ids': [(4, self.by_group_id.id)], 
        #                              'by_ministry_id': schedulling_ministry_id.id,
        #                              'assigned':True})

        #     else:

        #         member_group_id.unlink()
        #         schedulling_ministry_id = self.env['schedulling.by.ministry'].search([('allotment_ministry_id', '=', self.group_ministry_id.id)])
        #         if schedulling_ministry_id:
        #             group_id = self.search([('member_id', '=', self.member_id.id), ('schedulled_group_ids', 'in', self.by_group_id.id), ('by_ministry_id', '=', schedulling_ministry_id.id)])
        #             if group_id:
        #                 group_id.unlink()
        # if self.schedulled_group_ids:
        #     if self.assigned:
        #         for group in self.schedulled_group_ids:
        #             minister_detail_id = self.search([('member_id', '=', self.member_id.id), ('by_group_id', '=', group.id)])
        #             if not minister_detail_id:
        #                 self.create({'member_id': self.member_id.id, 'by_group_id': group.id, 'group_ministry_id': self.ministry_id.id, 'assigned':True})
        #     else:
        #         for group in self.schedulled_group_ids:
        #             minister_detail_id = self.search([('member_id', '=', self.member_id.id), ('by_group_id', '=', group.id)])
        #             if minister_detail_id:
        #                 minister_detail_id.unlink()
        # if self.assigned:
        #     minister_id = self.env['minister.minister'].search([('member_id', '=', self.member_id.id)])
        #     if not minister_id:
        #         if self.by_group_id:
        #             ministries.append(self.group_ministry_id.id)
        #             schedulled_groups.append(self.by_group_id.id)
        #         if self.by_ministry_id:
        #             ministries = self.by_ministry_id and self.by_ministry_id.allotment_ministry_id.id
        #             schedulled_groups.extend(self.schedulled_group_ids.ids)
        #         member_id = self.env['minister.minister'].create({'member_id': self.member_id.id,
        #                                                          'family_id': self.member_id.parent_id and self.member_id.parent_id.id or False,
        #                                                          'ministry_ids': [(6,0, set(ministries))],
        #                                                          'schedulled_group_ids': [(6,0, set(schedulled_groups))],
        #                                                          'virtus_certification': self.member_id.virtus_certification,
        #                                                          'background_check': self.member_id.background_checks,
        #                                                          'calendar_event_ids': [(6, 0, [self.event_id.id])]
        #                                                          })
        #     else:
        #         if self.by_ministry_id:
        #             ministries.append(self.by_ministry_id.allotment_ministry_id.id)
        #         if self.group_ministry_id:
        #             ministries.append(self.group_ministry_id.id)
        #         if minister_id.ministry_ids:
        #             ministries.extend(minister_id.ministry_ids.ids)
        #         if minister_id.calendar_event_ids:
        #             events.extend(minister_id.calendar_event_ids.ids)
        #         if self.event_id:
        #             events.append(self.event_id.id)
        #         minister_id.write({'ministry_ids': [(6,0, set(ministries))], 'calendar_event_ids':[(6, 0, set(events))]})
        return res

    @api.constrains('member_id')
    def constrain_minister_details(self):
        for rec in self:
            if rec.member_id and rec.group_ministry_id.id and rec.by_group_id:
                member_ids = self.search([('member_id', '=', rec.member_id.id), 
                                          ('group_ministry_id', '=', rec.group_ministry_id.id),
                                          ('by_group_id', '=', rec.by_group_id.id)])
                if member_ids and len(member_ids) > 1:
                    raise ValidationError(_('Ministry is exist for this member.'))
            if rec.by_ministry_id:
                member_ids = self.search([('member_id', '=', rec.member_id.id),
                                          ('by_ministry_id', '=', rec.by_ministry_id.id),
                                          ('schedulled_group_ids', 'in', rec.schedulled_group_ids.ids)])
                if member_ids and len(member_ids) > 1:
                    raise ValidationError(_('Member is already exist for this ministry.'))


class SchedulingByGroup(models.Model):
    _name = 'schedulling.by.group'

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            vals['created'] = True
            if 'event_id' in vals and vals['event_id']:
                event_id = self.env['calendar.event'].browse(vals['event_id'])
                if '-' in event_id:
                    event = vals['event_id'].split('-')
                    if len(event) == 2:
                        event_id = self.env['calendar.event'].browse(int(event[0]))
                        if event_id:
                            vals['event_id'] = event_id.id
        res = super(SchedulingByGroup, self).create(vals_list)
        minister_detail_ids = self.env['minister.details'].search([('schedulled_group_ids', 'in', res.id), 
                                                                   ('assigned', '=', True)])
        if minister_detail_ids:
            for detail in minister_detail_ids:
                minister_id = self.env['minister.details'].search([('member_id', '=',detail.member_id.id),
                                                                   ('by_group_id', '=',res.id),
                                                                   ('group_ministry_id', '=', detail.ministry_id.id)])
                if not minister_id:
                    self.env['minister.details'].create({'member_id': detail.member_id.id, 
                                                         'virtus_certification': detail.member_id.virtus_certification,
                                                         'background_check': detail.member_id.background_checks,
                                                         'by_group_id':res.id,
                                                         'assigned': True,
                                                         'group_ministry_id': detail.ministry_id.id})
        return res

    def write(self, vals):
        if 'event_id' in vals and vals['event_id'] and '-' in vals['event_id']:
            event = vals['event_id'].split('-')
            if len(event) == 2:
                event_id = self.env['calendar.event'].browse(int(event[0]))
                if event_id:
                    vals['event_id'] = event_id.id
        res = super(SchedulingByGroup, self).write(vals)
        minister_detail_ids = self.env['minister.details'].search([('schedulled_group_ids', 'in', self.id), 
                                                                   ('assigned', '=', True)])
        if minister_detail_ids:
            for detail in minister_detail_ids:
                minister_id = self.env['minister.details'].search([('member_id', '=', detail.member_id.id),
                                                                   ('by_group_id', '=', self.id),
                                                                   ('group_ministry_id', '=', detail.ministry_id.id)])
                if not minister_id:
                    self.env['minister.details'].create({'member_id': detail.member_id.id, 
                                                         'virtus_certification': detail.member_id.virtus_certification,
                                                         'background_check': detail.member_id.background_checks,
                                                         'by_group_id':self.id,
                                                         'assigned': True,
                                                         'group_ministry_id': detail.ministry_id.id})
        return res

    @api.onchange('allotment_group_id')
    def onchange_group(self):
        if self.allotment_group_id:
            self.event_id = False
        if self.allotment_group_id and not self.created:
            allotment_group_id = self.allotment_group_id
            self.minister_details_ids.unlink()
            self.allotment_group_id = allotment_group_id
        if self.created:
            raise ValidationError(_('You can not change ministry Group.'))

    
    @api.constrains('allotment_group_id')
    def ministry_group_constrain(self):
        if self.allotment_group_id:
            by_group_id = self.search([('allotment_group_id', '=', self.allotment_group_id.id)])
            if len(by_group_id) > 1:
                raise ValidationError(_('Group is already created.'))

    allotment_group_id = fields.Many2one('ministry.group', 'Ministry Group', copy=False)
    minister_details_ids = fields.One2many('minister.details','by_group_id', 'Allotments', copy=False)
    ministry_ids = fields.Many2many('ministry.ministry', 'ministry_group_ministry_rel', related="allotment_group_id.ministry_ids", string='Ministries', copy=False)
    created = fields.Boolean('Created?', copy=False, default=False)
    event_id = fields.Many2one('calendar.event', copy=False, string='Event')
    name = fields.Char('Scheduled Group Name')

class SchedulingByMinistry(models.Model):
    _name = 'schedulling.by.ministry'
    _rec_name = 'allotment_ministry_id'

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            vals['created'] = True
        res = super(SchedulingByMinistry, self).create(vals_list)
        minister_detail_ids = self.env['minister.details'].search([('group_ministry_id', '=', res.allotment_ministry_id.id), 
                                                                   ('assigned', '=', True)])
        if minister_detail_ids:
            for detail in minister_detail_ids:
                if detail.by_group_id:
                    minister_id = self.env['minister.details'].search([('member_id', '=', detail.member_id.id),
                                                                        ('by_ministry_id', '=', res.id),
                                                                        ('schedulled_group_ids', 'in', detail.by_group_id.id)])
                    if not minister_id:
                        self.env['minister.details'].create({'member_id': detail.member_id.id, 
                                                             'virtus_certification': detail.member_id.virtus_certification,
                                                             'background_check': detail.member_id.background_checks,
                                                             'schedulled_group_ids': [(4, detail.by_group_id.id)],
                                                             'assigned': True,
                                                             # 'event_ids': [(4,detail.by_group_id.event_id.id)],
                                                             'by_ministry_id': res.id})
        return res

    def write(self, vals):
        res = super(SchedulingByMinistry, self).write(vals)
        minister_detail_ids = self.env['minister.details'].search([('group_ministry_id', '=', self.allotment_ministry_id.id), 
                                                                   ('assigned', '=', True)])
        if minister_detail_ids:
            for detail in minister_detail_ids:
                if detail.by_group_id:
                    minister_id = self.env['minister.details'].search([('member_id', '=', detail.member_id.id),
                                                                        ('by_ministry_id', '=', self.id),
                                                                        ('schedulled_group_ids', 'in', detail.by_group_id.id)])
                    if not minister_id:
                        self.env['minister.details'].create({'member_id': detail.member_id.id, 
                                                             'virtus_certification': detail.member_id.virtus_certification,
                                                             'background_check': detail.member_id.background_checks,
                                                             'schedulled_group_ids': [(4, detail.by_group_id.id)],
                                                             'assigned': True,
                                                             'by_ministry_id': self.id})
        return res

    @api.onchange('allotment_ministry_id')
    def onchange_ministry(self):
        if self.allotment_ministry_id:
            groups = self.env['ministry.group'].search([('ministry_ids', 'in', self.allotment_ministry_id.id)])
            if not groups:
                raise ValidationError(_('Ministry Group is not assigned.Please assign atleast one ministry group to ministry.'))
        if self.allotment_ministry_id and not self.created:
            allotment_ministry_id = self.allotment_ministry_id
            self.minister_details_ids.unlink()
            self.allotment_ministry_id = allotment_ministry_id
        if self.created:
            raise ValidationError(_('You can not change ministry.'))


    @api.constrains('allotment_ministry_id')
    def ministry_group_constrain(self):
        if self.allotment_ministry_id:
            by_ministry_id = self.search([('allotment_ministry_id', '=', self.allotment_ministry_id.id)])
            if len(by_ministry_id) > 1:
                raise ValidationError(_('Ministry is already created.'))

    allotment_ministry_id = fields.Many2one('ministry.ministry', 'Scheduling Ministry', copy=False, store=True)
    minister_details_ids = fields.One2many('minister.details','by_ministry_id', 'Allotments', copy=False)
    created = fields.Boolean('Created?')
