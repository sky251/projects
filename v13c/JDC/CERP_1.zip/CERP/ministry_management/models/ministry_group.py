# -*- coding: utf-8 -*-
from odoo import fields, models


class MinistryGroup(models.Model):
    _name = 'ministry.group'
    _description = "Ministry Group"

    name = fields.Char('Name', copy=False)
    ministry_ids = fields.Many2many('ministry.ministry', 'ministry_group_ministry_rel', string='Ministries', copy=False)