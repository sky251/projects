from odoo import models, fields, api, _
from datetime import datetime, date, time
import calendar
from odoo.exceptions import UserError

class ByWeekEventTypeWizard(models.TransientModel):
    _name = "by.week.event.type.wizard"
    _description = "By Week Event Type Wizard"

    date_from = fields.Date(string='Date From', copy=False)
    date_to = fields.Date(string='Date To', copy=False)
    event_type = fields.Selection([('funeral', 'Funeral'), ('sacrament', 'Sacrament'), ('ministry', 'Ministry')], string='Event Type', copy=False)

    def print_by_week_event(self):
        final_data = {}
        data = {
            'form': self.read()[0]
        }
        if (self.event_type == 'funeral'):
            by_week_event_data = self.env['calendar.event'].search([('start', '>=', self.date_from), (
                'start', '<=', self.date_to), ('event_for', '=', 'funeral')])
            if by_week_event_data:
                for records in by_week_event_data:
                    if records.start:
                        year_data = datetime.strftime(records.start, "%Y")
                        week_num1 = (records.start.isocalendar()[1])
                        vals = {
                            'year': year_data,
                            'week': week_num1,
                            'event_type': records.event_type,
                            'responsible_group_id': records.responsible_group_id.name,
                            'member_name': records.resposible_member_id.name,
                            'officiant_id': records.officiant_id.name,
                            'start_date': records.start,
                            'stop_date': records.stop,
                            'location': records.location,
                        }
                        if vals:
                            if week_num1 in list(final_data.keys()):
                                final_data[week_num1].append(vals)
                            else:
                                final_data.update({
                                    week_num1: [vals]
                                })
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif (self.event_type == 'sacrament'):
            by_week_event_data = self.env['calendar.event'].search([('start', '>=', self.date_from), (
                'start', '<=', self.date_to), ('event_for', '=', 'sacrament')])
            if by_week_event_data:
                for records in by_week_event_data:
                    if records.start:
                        year_data = datetime.strftime(records.start, "%Y")
                        week_num1 = (records.start.isocalendar()[1])
                        vals = {
                            'year': year_data,
                            'week': week_num1,
                            'event_type': records.event_type,
                            'responsible_group_id': records.responsible_group_id.name,
                            'member_name': records.resposible_member_id.name,
                            'officiant_id': records.officiant_id.name,
                            'start_date': records.start,
                            'stop_date': records.stop,
                            'location': records.location,
                        }
                        if vals:
                            if week_num1 in list(final_data.keys()):
                                final_data[week_num1].append(vals)
                            else:
                                final_data.update({
                                    week_num1: [vals]
                                })
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
                    
        else:
            by_week_event_data = self.env['calendar.event'].search([('start', '>=', self.date_from), (
                'start', '<=', self.date_to), ('event_for', '=', 'ministry')])
            if by_week_event_data:
                for records in by_week_event_data:
                    if records.start:
                        year_data = datetime.strftime(records.start, "%Y")
                        week_num1 = (records.start.isocalendar()[1])
                        vals = {
                            'year': year_data,
                            'week': week_num1,
                            'event_type': records.event_type,
                            'responsible_group_id': records.responsible_group_id.name,
                            'member_name': records.resposible_member_id.name,
                            'officiant_id': records.officiant_id.name,
                            'start_date': records.start,
                            'stop_date': records.stop,
                            'location': records.location,
                        }
                        if vals:
                            if week_num1 in list(final_data.keys()):
                                final_data[week_num1].append(vals)
                            else:
                                final_data.update({
                                    week_num1: [vals]
                                })
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        if final_data:
            data['ministry'] = final_data
            return self.env.ref('ministry_management.action_report_by_week_event_type').with_context(landscape=True).report_action(self, data=data)

      
    def get_report_xls(self):
        final_data = {}
        data = {}
        if (self.event_type == 'funeral'):
            by_week_event_data = self.env['calendar.event'].search([('start', '>=', self.date_from), (
                'start', '<=', self.date_to), ('event_for', '=', 'funeral')])
            if by_week_event_data:
                for records in by_week_event_data:
                    if records.start:
                        year_data = datetime.strftime(records.start, "%Y")
                        week_num1 = (records.start.isocalendar()[1])
                        vals = {
                            'year': year_data,
                            'week': week_num1,
                            'event_type': records.event_type,
                            'responsible_group_id': records.responsible_group_id.name,
                            'member_name': records.resposible_member_id.name,
                            'officiant_id': records.officiant_id.name,
                            'start_date': records.start,
                            'stop_date': records.stop,
                            'location': records.location,
                        }
                        if vals:
                            if week_num1 in list(final_data.keys()):
                                final_data[week_num1].append(vals)
                            else:
                                final_data.update({
                                    week_num1: [vals]
                                })
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif (self.event_type == 'sacrament'):
            by_week_event_data = self.env['calendar.event'].search([('start', '>=', self.date_from), (
                'start', '<=', self.date_to), ('event_for', '=', 'sacrament')])
            if by_week_event_data:
                for records in by_week_event_data:
                    if records.start:
                        year_data = datetime.strftime(records.start, "%Y")
                        week_num1 = (records.start.isocalendar()[1])
                        vals = {
                            'year': year_data,
                            'week': week_num1,
                            'event_type': records.event_type,
                            'responsible_group_id': records.responsible_group_id.name,
                            'member_name': records.resposible_member_id.name,
                            'officiant_id': records.officiant_id.name,
                            'start_date': records.start,
                            'stop_date': records.stop,
                            'location': records.location,
                        }
                        if vals:
                            if week_num1 in list(final_data.keys()):
                                final_data[week_num1].append(vals)
                            else:
                                final_data.update({
                                    week_num1: [vals]
                                })
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
                    
        else:
            by_week_event_data = self.env['calendar.event'].search([('start', '>=', self.date_from), (
                'start', '<=', self.date_to), ('event_for', '=', 'ministry')])
            if by_week_event_data:
                for records in by_week_event_data:
                    if records.start:
                        year_data = datetime.strftime(records.start, "%Y")
                        week_num1 = (records.start.isocalendar()[1])
                        vals = {
                            'year': year_data,
                            'week': week_num1,
                            'event_type': records.event_type,
                            'responsible_group_id': records.responsible_group_id.name,
                            'member_name': records.resposible_member_id.name,
                            'officiant_id': records.officiant_id.name,
                            'start_date': records.start,
                            'stop_date': records.stop,
                            'location': records.location,
                        }
                        if vals:
                            if week_num1 in list(final_data.keys()):
                                final_data[week_num1].append(vals)
                            else:
                                final_data.update({
                                    week_num1: [vals]
                                })
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        if final_data:
            data['ministry'] = final_data
            return self.env.ref('ministry_management.action_report_by_week_event_type_xls').with_context(landscape=True).report_action(self, data=data)

