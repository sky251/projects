# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError

class ByMinistryWizard(models.TransientModel):
    _name = "by.ministry.wizard"
    _description = "By Ministry Report"

    ministry_id = fields.Many2one('ministry.ministry', 'Ministry', copy=False)
    ministry_type_id = fields.Char('Ministry Type', related="ministry_id.ministry_type_id.name", copy=False)

    def print_ministry_detail(self):
        ministry_details = []
        data = {
            'form': self.read()[0]
        }
        groups = []
        ministry_ids = self.env['schedulling.by.ministry'].search([('allotment_ministry_id','=', self.ministry_id.id)])
        ministry_detail_ids = self.env['minister.details'].search([('group_ministry_id','=', self.ministry_id.id)])
        if not ministry_ids and not ministry_detail_ids:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))
        for detail in ministry_ids:
            for records in detail.minister_details_ids:
                vals = {}
                vals.update({'ministry_id': detail.allotment_ministry_id.name})
                if records.member_id:
                    vals.update({'member_id': records.member_id.name})
                else:
                    vals.update({'member_id': ''})
                if records.family_id:
                    vals.update({'family_id': records.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if records.virtus_certification:
                    vals.update({'virtus_certification': records.virtus_certification})
                else:
                    vals.update({'virtus_certification': 'False'})
                if records.background_check:
                    vals.update({'background_check': records.background_check})
                else:
                    vals.update({'background_check': 'False'})
                if records.schedulled_group_ids:
                    for group in records.schedulled_group_ids:
                        group_name = '%s' %(group.name)
                        groups.append(group_name)
                    vals.update({'schedulled_group_ids': '%s' % ', '.join(map(str, set(groups)))})
                else:
                    vals.update({'schedulled_group_ids': ''})
                if records.event_ids:
                    events = []
                    for event in records.event_ids:
                        event_name = '%s' %(event.name)
                        events.append(event_name)
                    vals.update({'event_ids': '%s' % ', '.join(map(str, events))})
                else:
                    vals.update({'event_ids': ''})
                if vals:
                    ministry_details.append(vals)
        for ministry in ministry_detail_ids:
            if ministry.by_group_id.name not in groups:
                vals1 = {}
                vals1.update({'ministry_id': ministry.group_ministry_id.name})
                if ministry.member_id:
                    vals1.update({'member_id': ministry.member_id.name})
                else:
                    vals1.update({'member_id': ''})
                if ministry.family_id:
                    vals1.update({'family_id': ministry.family_id.name})
                else:
                    vals1.update({'family_id': ''})
                if ministry.virtus_certification:
                    vals1.update({'virtus_certification': ministry.virtus_certification})
                else:
                    vals1.update({'virtus_certification': 'False'})
                if ministry.background_check:
                    vals1.update({'background_check': ministry.background_check})
                else:
                    vals1.update({'background_check': 'False'})
                if ministry.group_id:
                    vals1.update({'schedulled_group_ids': ministry.group_id.name})
                else:
                    vals1.update({'schedulled_group_ids': ''})
                if ministry.event_id:
                    vals1.update({'event_ids': ministry.event_id.name})
                else:
                    vals1.update({'event_ids': ''})
                if vals1:
                    ministry_details.append(vals1)
        data['ministry'] = ministry_details
        return self.env.ref('ministry_management.action_report_by_ministry').with_context(landscape=True).report_action(self, data=data)
 
    def get_report_xls(self):
        ministry_details = []
        data = {}
        groups = []
        ministry_ids = self.env['schedulling.by.ministry'].search([('allotment_ministry_id','=', self.ministry_id.id)])
        ministry_detail_ids = self.env['minister.details'].search([('group_ministry_id','=', self.ministry_id.id)])
        if not ministry_ids and not ministry_detail_ids:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))
        for detail in ministry_ids:
            for records in detail.minister_details_ids:
                vals = {}
                vals.update({'ministry_id': detail.allotment_ministry_id.name})
                if records.member_id:
                    vals.update({'member_id': records.member_id.name})
                else:
                    vals.update({'member_id': ''})
                if records.family_id:
                    vals.update({'family_id': records.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if records.virtus_certification:
                    vals.update({'virtus_certification': 'True'})
                else:
                    vals.update({'virtus_certification': 'False'})
                if records.background_check:
                    vals.update({'background_check': 'True'})
                else:
                    vals.update({'background_check': 'False'})
                if records.schedulled_group_ids:
                    for group in records.schedulled_group_ids:
                        group_name = '%s' %(group.name)
                        groups.append(group_name)
                    vals.update({'schedulled_group_ids': '%s' % ', '.join(map(str, set(groups)))})
                else:
                    vals.update({'schedulled_group_ids': ''})
                if records.event_ids:
                    events = []
                    for event in records.event_ids:
                        event_name = '%s' %(event.name)
                        events.append(event_name)
                    vals.update({'event_ids': '%s' % ', '.join(map(str, events))})
                else:
                    vals.update({'event_ids': ''})
                if vals:
                    ministry_details.append(vals)
        for ministry in ministry_detail_ids:
            if ministry.by_group_id.name not in groups:
                vals1 = {}
                vals1.update({'ministry_id': ministry.group_ministry_id.name})
                if ministry.member_id:
                    vals1.update({'member_id': ministry.member_id.name})
                else:
                    vals1.update({'member_id': ''})
                if ministry.family_id:
                    vals1.update({'family_id': ministry.family_id.name})
                else:
                    vals1.update({'family_id': ''})
                if ministry.virtus_certification:
                    vals1.update({'virtus_certification': 'True'})
                else:
                    vals1.update({'virtus_certification': 'False'})
                if ministry.background_check:
                    vals1.update({'background_check': 'True'})
                else:
                    vals1.update({'background_check': 'False'})
                if ministry.group_id:
                    vals1.update({'schedulled_group_ids': ministry.group_id.name})
                else:
                    vals1.update({'schedulled_group_ids': ''})
                if ministry.event_id:
                    vals1.update({'event_ids': ministry.event_id.name})
                else:
                    vals1.update({'event_ids': ''})
                if vals1:
                    ministry_details.append(vals1)
        data['ministry'] = ministry_details
        return self.env.ref('ministry_management.action_report_by_ministry_xls').with_context(landscape=True).report_action(self, data=data)
