# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class ActiveDeactiveWizard(models.TransientModel):
    _name = "active.deactive.wizard"
    _description = "Active Inactive Details"

    report_type = fields.Selection([('Active', 'Active Report'),
                                    ('Inactive', 'Inactive Report')], string="Report Type", copy=False)

    def print_active_deactive_details(self):
        ministry_details = []
        data = {
            'form': self.read()[0]
        }
        if (self.report_type == 'Active'):
            ministry_detail_ids = self.env['minister.details'].search(
                [('assigned', '=', True), ('by_group_id', '!=', False)])
            if ministry_detail_ids:
                for detail in ministry_detail_ids:
                    vals = {}
                    if detail.member_id:
                        vals.update({'member_id': detail.member_id.name})
                    else:
                        vals.update({'member_id': ''})
                    if detail.family_id:
                        vals.update({'family_id': detail.family_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.virtus_certification:
                        vals.update(
                            {'virtus_certification': detail.virtus_certification})
                    else:
                        vals.update({'virtus_certification': 'False'})
                    if detail.background_check:
                        vals.update(
                            {'background_check': detail.background_check})
                    else:
                        vals.update({'background_check': 'False'})
                    if detail.group_ministry_id:
                        vals.update(
                            {'ministry': detail.group_ministry_id.name})
                    else:
                        vals.update({'ministry': ''})
                    if detail.by_group_id:
                        vals.update(
                            {'schedulled_group_id': detail.by_group_id.name})
                    else:
                        vals.update({'schedulled_group_id': ''})
                    if vals:
                        ministry_details.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        elif(self.report_type == 'Inactive'):
            ministry_detail_ids = self.env['minister.details'].search(
                [('assigned', '=', False), ('by_group_id', '!=', False)])
            if ministry_detail_ids:
                for detail in ministry_detail_ids:
                    vals1 = {}
                    if detail.member_id:
                        vals1.update({'member_id': detail.member_id.name})
                    else:
                        vals1.update({'member_id': ''})
                    if detail.family_id:
                        vals1.update({'family_id': detail.family_id.name})
                    else:
                        vals1.update({'family_id': ''})
                    if detail.virtus_certification:
                        vals1.update(
                            {'virtus_certification': detail.virtus_certification})
                    else:
                        vals1.update({'virtus_certification': 'False'})
                    if detail.background_check:
                        vals1.update(
                            {'background_check': detail.background_check})
                    else:
                        vals1.update({'background_check': 'False'})
                    if detail.by_ministry_id:
                        vals1.update(
                            {'ministry': detail.by_ministry_id.allotment_ministry_id.name})
                    else:
                        vals1.update({'ministry': ''})
                    if detail.by_group_id:
                        vals1.update(
                            {'schedulled_group_id': detail.by_group_id.name})
                    else:
                        vals1.update({'schedulled_group_id': ''})
                    if vals1:
                        ministry_details.append(vals1)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        if ministry_details:
            data['ministry'] = ministry_details
            return self.env.ref('ministry_management.action_report_active_deactive_minister').with_context(landscape=True).report_action(self, data=data)

    def get_report_xls(self):
        ministry_details = []
        data = {}
        if (self.report_type == 'Active'):
            ministry_detail_ids = self.env['minister.details'].search(
                [('assigned', '=', True), ('by_group_id', '!=', False)])
            if ministry_detail_ids:
                for detail in ministry_detail_ids:
                    vals = {}
                    if detail.member_id:
                        vals.update({'member_id': detail.member_id.name})
                    else:
                        vals.update({'member_id': ''})
                    if detail.family_id:
                        vals.update({'family_id': detail.family_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if detail.virtus_certification:
                        vals.update({'virtus_certification': 'True'})
                    else:
                        vals.update({'virtus_certification': 'False'})
                    if detail.background_check:
                        vals.update({'background_check': 'True'})
                    else:
                        vals.update({'background_check': 'False'})
                    if detail.group_ministry_id:
                        vals.update(
                            {'ministry': detail.group_ministry_id.name})
                    else:
                        vals.update({'ministry': ''})
                    if detail.by_group_id:
                        vals.update(
                            {'schedulled_group_id': detail.by_group_id.name})
                    else:
                        vals.update({'schedulled_group_id': ''})
                    if vals:
                        ministry_details.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        elif(self.report_type == 'Inactive'):
            ministry_detail_ids = self.env['minister.details'].search(
                [('assigned', '=', False), ('by_group_id', '!=', False)])
            if ministry_detail_ids:
                for detail in ministry_detail_ids:
                    vals1 = {}
                    if detail.member_id:
                        vals1.update({'member_id': detail.member_id.name})
                    else:
                        vals1.update({'member_id': ''})
                    if detail.family_id:
                        vals1.update({'family_id': detail.family_id.name})
                    else:
                        vals1.update({'family_id': ''})
                    if detail.virtus_certification:
                        vals1.update({'virtus_certification': 'True'})
                    else:
                        vals1.update({'virtus_certification': 'False'})
                    if detail.background_check:
                        vals1.update({'background_check': 'True'})
                    else:
                        vals1.update({'background_check': 'False'})
                    if detail.by_ministry_id:
                        vals1.update(
                            {'ministry': detail.by_ministry_id.allotment_ministry_id.name})
                    else:
                        vals1.update({'ministry': ''})
                    if detail.by_group_id:
                        vals1.update(
                            {'schedulled_group_id': detail.by_group_id.name})
                    else:
                        vals1.update({'schedulled_group_id': ''})
                    if vals1:
                        ministry_details.append(vals1)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        if ministry_details:
            data['ministry'] = ministry_details
            return self.env.ref('ministry_management.action_report_active_deactive_minister_xls').with_context(landscape=True).report_action(self, data=data)

