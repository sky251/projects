# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError

class ByGroupWizard(models.TransientModel):
    _name = "by.group.wizard"
    _description = "By Group Report"

    ministry_group_id = fields.Many2one('schedulling.by.group', 'Group', copy=False)
    allotment_group_id = fields.Char(related="ministry_group_id.allotment_group_id.name",string='Ministry Group', copy=False)
    ministry_id = fields.Char(related="ministry_group_id.ministry_ids.name", string='Ministries', copy=False)
    event_id = fields.Char(related="ministry_group_id.event_id.name", copy=False, string='Event')

    def print_group_detail(self):
        ministry_details = []
        data = {
            'form': self.read()[0]
        }
        ministry_detail_ids = self.env['schedulling.by.group'].search([('name','=', self.ministry_group_id.name)])
        if ministry_detail_ids:
            for detail in ministry_detail_ids:
                for records in detail.minister_details_ids:
                    vals = {}
                    vals.update({'ministry_group_id': detail.name})
                    if records.member_id:
                        vals.update({'member_id': records.member_id.name})
                    else:
                        vals.update({'member_id': ''})
                    if records.family_id:
                        vals.update({'family_id': records.family_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if records.virtus_certification:
                        vals.update({'virtus_certification': records.virtus_certification})
                    else:
                        vals.update({'virtus_certification': 'False'})
                    if records.background_check:
                        vals.update({'background_check': records.background_check})
                    else:
                        vals.update({'background_check': 'False'})
                    if records.group_ministry_id:
                        vals.update({'group_ministry_id': records.group_ministry_id.name})
                    else:
                        vals.update({'group_ministry_id': ''})
                    if records.event_id:
                        vals.update({'event_id': records.event_id.name})
                    else:
                        vals.update({'event_id': ''})
                    if vals:
                        ministry_details.append(vals)
            data['ministry'] = ministry_details
            return self.env.ref('ministry_management.action_report_by_group').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))


    def get_report_xls(self):
        ministry_details = []
        data = {}
        ministry_detail_ids = self.env['schedulling.by.group'].search([('name','=', self.ministry_group_id.name)])
        if ministry_detail_ids:
            for detail in ministry_detail_ids:
                for records in detail.minister_details_ids:
                    vals = {}
                    if records.member_id:
                        vals.update({'member_id': records.member_id.name})
                    else:
                        vals.update({'member_id': ''})
                    if records.family_id:
                        vals.update({'family_id': records.family_id.name})
                    else:
                        vals.update({'family_id': ''})
                    if records.virtus_certification:
                        vals.update({'virtus_certification': 'True'})
                    else:
                        vals.update({'virtus_certification': 'False'})
                    if records.background_check:
                        vals.update({'background_check': 'True'})
                    else:
                        vals.update({'background_check': 'False'})
                    if records.group_ministry_id:
                        vals.update({'group_ministry_id': records.group_ministry_id.name})
                    else:
                        vals.update({'group_ministry_id': ''})
                    if records.event_id:
                        vals.update({'event_id': records.event_id.name})
                    else:
                        vals.update({'event_id': ''})
                    if vals:
                        ministry_details.append(vals)
            data['ministry'] = ministry_details
            return self.env.ref(
                'ministry_management.action_report_by_group_xls').with_context(
                landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

