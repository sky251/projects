from odoo import models
import io

class ByGroupReportXls(models.AbstractModel):
    _name = 'report.ministry_management.report_by_group_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format({'align': 'center','valign': 'vcenter','bold': True, 'size':16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format({'align': 'center','bold': True, 'size':12})
        worksheet = workbook.add_worksheet('By Group')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 35)
        worksheet.set_column('D:D', 25)
        worksheet.set_column('E:E', 25)
        worksheet.set_column('F:F', 25)
        worksheet.merge_range('A1:F2', "%s's Group Report" %(obj.ministry_group_id.name), heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Ministry Group:', cell_text_format)
        worksheet.write(row, column+1, obj.allotment_group_id, f_format)
        worksheet.write(row+1, column, 'Ministries:', cell_text_format)
        worksheet.write(row+1, column+1, obj.ministry_id, f_format)
        worksheet.write(row+2, column, 'Event:', cell_text_format)
        worksheet.write(row+2, column+1, obj.event_id, f_format)
        row += 4
        worksheet.write(row, column, 'Member', cell_text_format)
        worksheet.write(row, column+1, 'Family', cell_text_format)
        worksheet.write(row, column+2, 'Virtus Certificate Frequency', cell_text_format)
        worksheet.write(row, column+3, 'Background Checks', cell_text_format)
        worksheet.write(row, column+4, 'Ministry', cell_text_format)
        worksheet.write(row, column+5, 'Events', cell_text_format)
        row += 1
        ministry_data = obj.get_report_xls()
        for record in ministry_data['data']['ministry']:
            row += 1
            worksheet.write(row, column, record['member_id'], f_format)
            worksheet.write(row, column+1, record['family_id'], f_format)
            worksheet.write(row, column+2, record['virtus_certification'], f_format)
            worksheet.write(row, column+3, record['background_check'], f_format) 
            worksheet.write(row, column+4, record['group_ministry_id'], f_format)        
            worksheet.write(row, column+5, record['event_id'], f_format)


