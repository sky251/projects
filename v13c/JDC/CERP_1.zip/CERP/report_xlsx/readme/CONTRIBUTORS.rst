* Adrien Peiffer <adrien.peiffer@acsone.eu>
* Sébastien Alix <sebastien.alix@osiell.com>
* Stéphane Bidoul <stephane.bidoul@acsone.eu>
* Enric Tobella <etobella@creublanca.es>
* Graeme Gellatly <gdgellatly@gmail.com>
* Cristian Salamea <cs@prisehub.com>
* Rod Schouteden <rod.schouteden@dynapps.be>
