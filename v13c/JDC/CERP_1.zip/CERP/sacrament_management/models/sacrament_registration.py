# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
import datetime
from datetime import datetime, date, timedelta
from dateutil.relativedelta import relativedelta
from odoo.exceptions import ValidationError
import psycopg2
from pytz import timezone
import pytz
from odoo.tools.misc import DEFAULT_SERVER_DATETIME_FORMAT

# TIME_SELECTION = [('01:00', '01:00'),
#                     ('02:00', '02:00'),
#                     ('03:00', '03:00'),
#                     ('04:00', '04:00'),
#                     ('05:00', '05:00'),
#                     ('06:00', '06:00'),
#                     ('07:00', '07:00'),
#                     ('08:00', '08:00'),
#                     ('09:00', '09:00'),
#                     ('10:00', '10:00'),
#                     ('11:00', '11:00'),
#                     ('12:00', '12:00'),
#                     ('13:00', '13:00'),
#                     ('14:00', '14:00'),
#                     ('15:00', '15:00'),
#                     ('16:00', '16:00'),
#                     ('17:00', '17:00'),
#                     ('18:00', '18:00'),
#                     ('19:00', '19:00'),
#                     ('20:00', '20:00')]


class SacramentRegistration(models.Model):
    _name = 'sacrament.registration'
    _description = "Sacrament Registration"

    name = fields.Char('Name', copy=False)
    event_type = fields.Selection([('group', 'Group'),
                                   ('family', 'Family')], 'Event Type', copy=False)
    start_date = fields.Datetime('Start Date', copy=False, default=datetime.now())
    end_date = fields.Datetime('End Date', copy=False)
    # start_time = fields.Selection(TIME_SELECTION, 'Start Time', copy=False)
    # end_time = fields.Selection(TIME_SELECTION, 'End Time', copy=False)
    duration = fields.Float('Duration', copy=False)
    date = fields.Date('Date', default=datetime.today(), copy=False)
    sacrament = fields.Many2one('sacrament.sacrament', 'Sacrament', copy=False)
    location = fields.Many2one('place.parish', string='Locations', copy=False)
    officiant = fields.Many2one('res.partner', 'Officiant', copy=False)
    is_create = fields.Boolean('Is Create?')
    completed = fields.Boolean(
        'Completed', related="family_detail_ids.is_completed", copy=False)
    family_detail_ids = fields.One2many(
        'sacrament.details', 'registration_id', string='Family', copy=False)
    class_id = fields.Many2one('class.class', string="Class", copy=False, default=False)

    @api.onchange('start_date', 'end_date')
    def _get_duration(self):
        """ Get the duration value between the 2 given time string. """
        for record in self:
            if record.start_date and record.end_date:
                record.duration = False
                diff = fields.Datetime.from_string(record.end_date) - fields.Datetime.from_string(record.start_date)
                if diff:
                    duration = float(diff.days) * 24 + (float(diff.seconds) / 3600)
                    time = round(duration, 2)
                    record.duration = str(float(time))

    @api.constrains('family_detail_ids', 'event_type')
    def family_details_constarains(self):
        if len(self.family_detail_ids) == 0:
            raise ValidationError(_('Please add family details.'))

    @api.model
    def create(self, vals):
        print("vals", vals)
        if (vals['end_date'] <= vals['start_date']):
            raise ValidationError(
                _('Please enter end time greater than start time'))
        vals['name'] = self.env['ir.sequence'].next_by_code(
            'sacrament.registration') or 'New'
        rec = super(SacramentRegistration, self).create(vals)
        if rec.class_id:
            alloted_class_ids = self.env['allotment.allotment'].search([('class_id', '=', rec.class_id.id)])
            for alloted_class in alloted_class_ids:
                sacrament_detail_id = self.env['sacrament.details'].search([('registration_member_id', '=', alloted_class.child_id.id),
                                                                            ('family_id', '=', alloted_class.child_id.parent_id.id)])
                if sacrament_detail_id and sacrament_detail_id.registration_id.sacrament != rec.sacrament:
                    self.env['sacrament.details'].create({'registration_member_id': alloted_class.child_id.id,
                                                          'family_id': alloted_class.child_id.parent_id.id,
                                                          'family_code': alloted_class.child_id.parent_id.ref,
                                                          'date_of_birth': alloted_class.child_id.date_of_birth,
                                                          'registration_id': rec.id
                                                          })
                if not sacrament_detail_id:
                    self.env['sacrament.details'].create({'registration_member_id': alloted_class.child_id.id,
                                                          'family_id': alloted_class.child_id.parent_id.id,
                                                          'family_code': alloted_class.child_id.parent_id.ref,
                                                          'date_of_birth': alloted_class.child_id.date_of_birth,
                                                          'registration_id': rec.id
                                                          })
        rec.is_create = True
        return rec

    def write(self, vals):
        for rec in self:
            for family_line in rec.family_detail_ids:
                # if 'date' in vals:
                #     date = vals['date']
                # else:
                #     date = rec.date
                if 'start_date' in vals:
                    start = fields.Datetime.from_string(vals['start_date'])
                    if (start < rec.start_date):
                        raise ValidationError(
                            _('Member cannot register for two Sacrament Events with same time.'))
                    start_date = vals['start_date']
                else:
                    start_date = rec.start_date
                if 'end_date' in vals:
                    end_date = vals['end_date']
                else:
                    end_date = rec.end_date
                if 'location' in vals:
                    location = vals['location']
                else:
                    location = rec.location and rec.location.name
                if 'duration' in vals:
                    duration = vals['duration']
                else:
                    duration = rec.duration
                if 'officiant' in vals:
                    officiant = vals['officiant']
                else:
                    officiant = rec.officiant and rec.officiant.id
                if 'sacrament' in vals:
                    sacrament = vals['sacrament']
                else:
                    sacrament = rec.sacrament and rec.sacrament.id

                event_rec = self.env['calendar.event'].search(
                    [('sacrament_family_id', '=', family_line.id)])
                if event_rec:
                    event_rec.write({
                        'start': start_date,
                        'stop': end_date,
                        'end_date': end_date,
                        'duration': duration,
                        'officiant_id': officiant,
                        'sacrament_id': sacrament,
                        'location': location
                    })
        if rec.class_id:
            alloted_class_ids = self.env['allotment.allotment'].search([('class_id', '=', rec.class_id.id)])
            for alloted_class in alloted_class_ids:
                sacrament_detail_id = self.env['sacrament.details'].search([('registration_member_id', '=', alloted_class.child_id.id),
                                                                            ('family_id', '=', alloted_class.child_id.parent_id.id)])
                if sacrament_detail_id and sacrament_detail_id.registration_id.sacrament != rec.sacrament:
                    self.env['sacrament.details'].create({'registration_member_id': alloted_class.child_id.id,
                                                          'family_id': alloted_class.child_id.parent_id.id,
                                                          'family_code': alloted_class.child_id.parent_id.ref,
                                                          'date_of_birth': alloted_class.child_id.date_of_birth,
                                                          'registration_id': rec.id
                                                        })
                if not sacrament_detail_id:
                    self.env['sacrament.details'].create({'registration_member_id': alloted_class.child_id.id,
                                                          'family_id': alloted_class.child_id.parent_id.id,
                                                          'family_code': alloted_class.child_id.parent_id.ref,
                                                          'date_of_birth': alloted_class.child_id.date_of_birth,
                                                          'registration_id': rec.id
                                                        })
        res = super(SacramentRegistration, self).write(vals)
        return res


class SacramentDetails(models.Model):
    _name = 'sacrament.details'
    _description = 'Sacrament Details'

    registration_id = fields.Many2one(
        'sacrament.registration', 'Sacrament Registration', ondelete="cascade", copy=False)
    family_id = fields.Many2one(
        'res.partner', string='Family Name', copy=False)
    family_code = fields.Char(string='Family Code', copy=False, related="family_id.ref")
    registration_member_id = fields.Many2one(
        'res.partner', 'Member', copy=False)
    date_of_birth = fields.Date(
        'Date of Birth', related="registration_member_id.date_of_birth", copy=False)
    age = fields.Char(
        string="Age", related="registration_member_id.age", store=True)
    date = fields.Date('Date of Sacrament ',
                       related="registration_id.date", copy=False, store=True)
    sacrament_id = fields.Many2one(
        'sacrament.sacrament', 'Sacrament', related="registration_id.sacrament", copy=False, store=True)
    sacrament_type = fields.Selection(
        'Sacrament Type', related="sacrament_id.sacrament_type", copy=False, store=True)
    sponsors = fields.Many2one('res.partner', 'Sponsors', copy=False)
    witness = fields.Many2one('res.partner', 'Witness', copy=False)
    is_completed = fields.Boolean('Completed', copy=False)
    certificate_printed = fields.Boolean('Certificate Printed', copy=False)

    def get_certificate(self):
        return {
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'name': _('Sacrament Certificate'),
            'res_model': 'sacrament.certificate',
            'target': 'new',
        }
  
    @api.onchange('family_id')
    def _onchange_family_id(self):
        domain = []
        if self.family_id:
            self.registration_member_id = False
            if self.family_id.ref:
                self.family_code = self.family_id.ref
            domain.append(('parent_id', '=', self.family_id.id))
            member_ids = self.env['res.partner'].search(domain)
            if member_ids:
                return {'domain': {'registration_member_id': domain}}
            else:
                self.registration_member_id = False
        else:
            self.family_code = False
            self.registration_member_id = False
            domain.append(('is_company', '=', False))
            return {'domain': {'registration_member_id': domain}}
  

    @api.model
    def action_create_sacrament_record(self):
        check_date_rec = self.env['calendar.event'].search(
            [('end_date', '<=', datetime.now()), ('is_sacramented', '=', False)])
        if check_date_rec:
            scarament_list = []
            for rec in check_date_rec:
                scarament_list.append([0, 0, {
                    'member_id': rec.resposible_member_id.id,
                    'sacrament_family_id': rec.sacrament_family_id.id,
                    'sacrament_id': rec.sacrament_family_id.sacrament_id.id,
                    'scarament_type_id': rec.sacrament_family_id.sacrament_type,
                    # 'date': rec.sacrament_family_id.date,
                    'location': rec.sacrament_family_id.registration_id.location.id,
                    'officiant_id': rec.sacrament_family_id.registration_id.officiant.id,
                }])
                rec.is_sacramented = True
                rec.resposible_member_id.write(
                    {'sacrament_ids': scarament_list})
                rec.sacrament_family_id.is_completed = True

    @api.model
    def create(self, vals):
        if 'registration_id' in vals:
            registration_id = vals['registration_id']

        sacrament_exist = self.env['sacrament.registration'].browse(
            registration_id).sacrament
        same_time = self.env['sacrament.registration'].browse(
            registration_id).start_date
        if sacrament_exist.is_repeatable == False:
            sacrament_exist_rec = self.env['calendar.event'].search(
                ['&', ('resposible_member_id', '=', vals['registration_member_id']), ('sacrament_id', '=', sacrament_exist.id)])

            if sacrament_exist_rec:
                raise ValidationError(
                    _('Member cannot be registered again for %s sacrament event' % (sacrament_exist.name)))
            else:
                same_time_rec = self.env['calendar.event'].search(
                    ['&', ('resposible_member_id', '=', vals['registration_member_id']), ('end_date', '>=', same_time)])

                if same_time_rec:
                    raise ValidationError(
                        _('Member cannot register for two Sacrament Events with same time.'))
        elif sacrament_exist.is_repeatable == True:
            same_time_rec = self.env['calendar.event'].search(
                ['&', ('resposible_member_id', '=', vals['registration_member_id']), ('end_date', '>=', same_time)])

            if same_time_rec:
                raise ValidationError(
                    _('Member cannot register for two Sacrament Events with same time.'))
        # else:
        rec = super(SacramentDetails, self).create(vals)
        event_reg_list = []
        event_vals = {
            'sacrament_family_id': rec.id,
            'name': rec.registration_id.name,
            'start': rec.registration_id.start_date,
            'stop': rec.registration_id.end_date,
            'end_date': rec.registration_id.end_date,
            'duration': rec.registration_id.duration,
            'officiant_id': rec.registration_id.officiant.id,
            'sacrament_id': rec.registration_id.sacrament.id,
            'location': rec.registration_id.location.name,
            'resposible_member_id': rec.registration_member_id.id,
            'event_type': 'single',
            'event_for': 'sacrament'
        }
        event_reg_list.append(event_vals)
        if event_reg_list:
            self.env['calendar.event'].create(event_reg_list)
        return rec

    def write(self, vals):
        for rec in self:
            if 'registration_member_id' in vals:
                registration_member_id = vals['registration_member_id']
            else:
                registration_member_id = rec.registration_member_id and rec.registration_member_id.id
            event_rec = self.env['calendar.event'].search(
                [('sacrament_family_id', '=', self.id)])
            if event_rec:
                event_rec.write({
                    'resposible_member_id': registration_member_id,
                })
        res = super(SacramentDetails, self).write(vals)
        return res
