from odoo import models, fields, api, _
from datetime import datetime, date, time, timedelta
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError, ValidationError, Warning


class ByAgeWizard(models.TransientModel):
    _name = "by.age.wizard"
    _description = "By Age Group Wizard"

    age_from = fields.Integer(string='Age From', copy=False)
    age_to = fields.Integer(string='Age To', copy=False)

    def print_by_age(self):
        age_list = []
        data = {
            'form': self.read()[0]
        }
        age_data = self.env['sacrament.details'].search([('registration_member_id.age', '>=', self.age_from), (
            'registration_member_id.age', '<=', self.age_to)])
        if age_data:
            for records in age_data:
                vals = {}
                if records.family_id:
                    vals.update({'family_id': records.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if records.family_code:
                    vals.update({'family_code': records.family_code})
                else:
                    vals.update({'family_code': ''})
                if records.registration_member_id:
                    vals.update(
                        {'registration_member_id': records.registration_member_id.name})
                else:
                    vals.update({'registration_member_id': ''})
                if records.date_of_birth:
                    vals.update(
                        {'date_of_birth': records.date_of_birth})
                else:
                    vals.update({'date_of_birth': ''})
                if records.age:
                    vals.update(
                        {'age': records.age})
                else:
                    vals.update({'age': ''})
                if records.date:
                    vals.update(
                        {'date': records.date})
                else:
                    vals.update({'date': ''})
                if records.sacrament_id:
                    vals.update(
                        {'sacrament_id': records.sacrament_id.name})
                else:
                    vals.update({'sacrament_id': ''})
                if records.sacrament_type:
                    vals.update(
                        {'sacrament_type': records.sacrament_type})
                else:
                    vals.update({'sacrament_type': ''})
                if records.registration_id.location:
                    vals.update(
                        {'location': records.registration_id.location.name})
                else:
                    vals.update({'location': ''})
                if records.registration_id.officiant:
                    vals.update(
                        {'officiant': records.registration_id.officiant.name})
                else:
                    vals.update({'officiant': ''})
                if records.is_completed:
                    vals.update(
                        {'is_completed': records.is_completed})
                else:
                    vals.update({'is_completed': 'False'})
                if vals:
                    age_list.append(vals)
            data['sacrament'] = age_list
            return self.env.ref('sacrament_management.action_by_age_report').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        age_list = []
        data = {}
        age_data = self.env['sacrament.details'].search([('registration_member_id.age', '>=', self.age_from), (
            'registration_member_id.age', '<=', self.age_to)])
        if age_data:
            for records in age_data:
                vals = {}
                if records.family_id:
                    vals.update({'family_id': records.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if records.family_code:
                    vals.update({'family_code': records.family_code})
                else:
                    vals.update({'family_code': ''})
                if records.registration_member_id:
                    vals.update(
                        {'registration_member_id': records.registration_member_id.name})
                else:
                    vals.update({'registration_member_id': ''})
                if records.date_of_birth:
                    vals.update(
                        {'date_of_birth': records.date_of_birth})
                else:
                    vals.update({'date_of_birth': ''})
                if records.age:
                    vals.update(
                        {'age': records.age})
                else:
                    vals.update({'age': ''})
                if records.date:
                    vals.update(
                        {'date': records.date})
                else:
                    vals.update({'date': ''})
                if records.sacrament_id:
                    vals.update(
                        {'sacrament_id': records.sacrament_id.name})
                else:
                    vals.update({'sacrament_id': ''})
                if records.sacrament_type:
                    vals.update(
                        {'sacrament_type': records.sacrament_type})
                else:
                    vals.update({'schedulled_group_id': ''})
                if records.registration_id.location:
                    vals.update(
                        {'location': records.registration_id.location.name})
                else:
                    vals.update({'location': ''})
                if records.registration_id.officiant:
                    vals.update(
                        {'officiant': records.registration_id.officiant.name})
                else:
                    vals.update({'officiant': ''})
                if records.is_completed:
                    vals.update({'is_completed': 'True'})
                else:
                    vals.update({'is_completed': 'False'})
                if vals:
                    age_list.append(vals)
            data['sacrament'] = age_list
            return self.env.ref('sacrament_management.action_by_age_report_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))
