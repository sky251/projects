from odoo import models, fields, api, _
from datetime import datetime, date, time, timedelta
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError, ValidationError, Warning


class ByNotReceivedSacramentWizard(models.TransientModel):
    _name = "by.not.received.sacrament.wizard"
    _description = "By Not Received Sacrament Wizard"

    date_from = fields.Date('From Date')
    date_to = fields.Date('To Date')
    sacrament_id = fields.Many2one('sacrament.sacrament', default=False, copy=False)

    def print_by_not_received_sacrament(self):
        not_received_sacrament_list = []
        members = []
        data = {
            'form': self.read()[0]
        }
        # not_received_sacrament = self.env['sacrament.details'].search([('is_completed', '=', False)])
        member_ids = self.env['res.partner'].search([('date_of_birth', '>=', self.date_from),
            ('date_of_birth', '<=', self.date_to),
            ('active', '=', True),
            ('inactive', '=', False),
            ('is_company', '=', False)])
        if member_ids:
            for member in member_ids:
                not_received_sacrament = self.env['sacrament.member.details'].search([('sacrament_id', '=', self.sacrament_id.id), ('member_id', '=', member.id)], limit=5)
                if not not_received_sacrament:
                    members.append(member)
        # if not_received_sacrament:
            # for records in not_received_sacrament:
            for records in members:
                vals = {}
                if records.parent_id:
                    vals.update({'family_id': records.parent_id.name})
                else:
                    vals.update({'family_id': ''})
                if records.parent_id:
                    vals.update({'family_code': records.parent_id.ref})
                else:
                    vals.update({'family_code': ''})
                # if records:
                vals.update(
                    {'registration_member_id': records.name})
                # else:
                #     vals.update({'registration_member_id': ''})
                if records.date_of_birth:
                    vals.update(
                        {'date_of_birth': records.date_of_birth})
                else:
                    vals.update({'date_of_birth': ''})
                if vals:
                    not_received_sacrament_list.append(vals)
            data['sacrament'] = not_received_sacrament_list
            data['sacrament_type'] = self.sacrament_id.name
            return self.env.ref('sacrament_management.action_by_not_received_sacrament_report').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        not_received_sacrament_list = []
        data = {}
        members = []
        member_ids = self.env['res.partner'].search([('date_of_birth', '>=', self.date_from),
            ('date_of_birth', '<=', self.date_to),
            ('active', '=', True),
            ('inactive', '=', False),
            ('is_company', '=', False)])
        if member_ids:
            for member in member_ids:
                not_received_sacrament = self.env['sacrament.member.details'].search([('sacrament_id', '=', self.sacrament_id.id), ('member_id', '=', member.id)], limit=5)
                if not not_received_sacrament:
                    members.append(member)
            for records in members:
                vals = {}
                vals.update(
                    {'registration_member_id': records.name})
                if records.parent_id:
                    vals.update({'family_id': records.parent_id.name})
                else:
                    vals.update({'family_id': ''})
                if records.parent_id:
                    vals.update({'family_code': records.parent_id.ref})
                else:
                    vals.update({'family_code': ''})
                if records.date_of_birth:
                    vals.update(
                        {'date_of_birth': records.date_of_birth})
                else:
                    vals.update({'date_of_birth': ''})
                if vals:
                    not_received_sacrament_list.append(vals)
            data['sacrament'] = not_received_sacrament_list
            data['sacrament_type'] = self.sacrament_id.name
            return self.env.ref('sacrament_management.action_by_not_received_sacrament_report_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))
