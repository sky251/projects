from odoo import models, fields, api, _
from datetime import datetime, date, time, timedelta
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError, ValidationError, Warning


class MissingSacramentMembersWizard(models.TransientModel):
    _name = "missing.sacrament.members.wizard"
    _description = "Missing Sacrament Wizard"

    sacrament_id = fields.Many2one('sacrament.sacrament', default=False, copy=False)

    def print_missing_sacrament(self):
        members_list = []
        data = {}
        members_ids = self.env['res.partner'].search([('sacrament_ids.sacrament_id', '!=', self.sacrament_id.id),
                                                      ('company_type',
                                                       '=', 'person'),
                                                      ('active', '=', True),
                                                      ('parent_id', '!=', False)])
        if members_ids:
            for records in members_ids:
                member_registration_id = self.env['member.registration'].search(
                    [('partner_id', '=', records.parent_id.id)])
                for member in member_registration_id.member_detail_ids:
                    if member.registration_partner_id.id == records.id:
                        vals = {
                            'member_name': records.name,
                            'member_code': records.member_ref,
                            'family': records.parent_id.name,
                            'date_of_birth': records.date_of_birth,
                        }
                        if vals:
                            members_list.append(vals)
        data['members'] = members_list
        return self.env.ref('church_management.action_report_missing_sacrament_members').with_context(landscape=True).report_action(self, data=data)
