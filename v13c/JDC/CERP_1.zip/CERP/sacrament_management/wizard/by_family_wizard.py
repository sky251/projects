from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError, Warning

class ByFamilyWizard(models.TransientModel):
    _name = "by.family.wizard"
    _description = "By Family Wizard"

    family_id = fields.Many2one(
        'res.partner', string='Family Name', copy=False)
    family_code = fields.Char(string='Family Code', related="family_id.ref", copy=False)

    def get_by_family(self):
        family_list = []
        data = {
            'form': self.read()[0]
        }
        family_data = self.env['sacrament.details'].search([('family_id', '=', self.family_id.id)])
        if family_data:
            for records in family_data:
                vals = {}
                vals.update({'family_id': records.family_id.name})
                if records.registration_member_id:
                    vals.update(
                        {'registration_member_id': records.registration_member_id.name})
                else:
                    vals.update({'registration_member_id': ''})
                if records.date_of_birth:
                    vals.update(
                        {'date_of_birth': records.date_of_birth})
                else:
                    vals.update({'date_of_birth': ''})
                if records.date:
                    vals.update(
                        {'date': records.date})
                else:
                    vals.update({'date': ''})
                if records.sacrament_id:
                    vals.update(
                        {'sacrament_id': records.sacrament_id.name})
                else:
                    vals.update({'sacrament_id': ''})
                if records.sacrament_type:
                    vals.update(
                        {'sacrament_type': records.sacrament_type})
                else:
                    vals.update({'sacrament_type': ''})
                if records.registration_id.location:
                    vals.update(
                        {'location': records.registration_id.location.name})
                else:
                    vals.update({'location': ''})
                if records.registration_id.officiant:
                    vals.update(
                        {'officiant': records.registration_id.officiant.name})
                else:
                    vals.update({'officiant': ''})
                if records.is_completed:
                    vals.update(
                        {'is_completed': records.is_completed})
                else:
                    vals.update({'is_completed': 'False'})
                if vals:
                    family_list.append(vals)
            data['sacrament'] = family_list
            return self.env.ref('sacrament_management.by_family_report').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        family_list = []
        data = {}
        family_data = self.env['sacrament.details'].search([('family_id', '=', self.family_id.id)])
        if family_data:
            for records in family_data:
                vals = {}
                vals.update({'family_id': records.family_id.name})
                if records.registration_member_id:
                    vals.update(
                        {'registration_member_id': records.registration_member_id.name})
                else:
                    vals.update({'registration_member_id': ''})
                if records.date_of_birth:
                    vals.update(
                        {'date_of_birth': records.date_of_birth})
                else:
                    vals.update({'date_of_birth': ''})
                if records.date:
                    vals.update(
                        {'date': records.date})
                else:
                    vals.update({'date': ''})
                if records.sacrament_id:
                    vals.update(
                        {'sacrament_id': records.sacrament_id.name})
                else:
                    vals.update({'sacrament_id': ''})
                if records.sacrament_type:
                    vals.update(
                        {'sacrament_type': records.sacrament_type})
                else:
                    vals.update({'sacrament_type': ''})
                if records.registration_id.location:
                    vals.update(
                        {'location': records.registration_id.location.name})
                else:
                    vals.update({'location': ''})
                if records.registration_id.officiant:
                    vals.update(
                        {'officiant': records.registration_id.officiant.name})
                else:
                    vals.update({'officiant': ''})
                if records.is_completed:
                    vals.update(
                        {'is_completed': 'True'})
                else:
                    vals.update({'is_completed': 'False'})
                if vals:
                    family_list.append(vals)
            data['sacrament'] = family_list
            return self.env.ref('sacrament_management.by_family_report_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

