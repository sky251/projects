from odoo import models
import io

class ByOfficiantReportXls(models.AbstractModel):
    _name = 'report.sacrament_management.xls_by_officiant_report'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format({'align': 'center','valign': 'vcenter','bold': True, 'size':16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format({'align': 'center','bold': True, 'size':12})
        worksheet = workbook.add_worksheet('By Officiant')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 15)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 15)
        worksheet.set_column('E:E', 20)
        worksheet.set_column('F:F', 20)
        worksheet.set_column('G:G', 25)
        worksheet.set_column('H:H', 20)
        worksheet.set_column('I:I', 25)
        worksheet.merge_range('A1:I2', "By Officiant Report", heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Officiant:', cell_text_format)
        worksheet.write(row, column+1, obj.officiant_id.name, f_format)
        row += 2
        worksheet.write(row, column, 'Family', cell_text_format)
        worksheet.write(row, column+1, 'Family Code', cell_text_format)
        worksheet.write(row, column+2, 'Member', cell_text_format)
        worksheet.write(row, column+3, 'DOB', cell_text_format)
        worksheet.write(row, column+4, 'Date of Sacrament', cell_text_format)
        worksheet.write(row, column+5, 'Sacrament', cell_text_format)
        worksheet.write(row, column+6, 'Sacrament Type', cell_text_format)
        worksheet.write(row, column+7, 'Location', cell_text_format)
        worksheet.write(row, column+8, 'Completed', cell_text_format)
        row += 1
        sacrament_data = obj.get_report_xls()
        for record in sacrament_data['data']['sacrament']:
            row += 1
            worksheet.write(row, column, record['family_id'], f_format)
            worksheet.write(row, column+1, record['family_code'], f_format)
            worksheet.write(row, column+2, record['registration_member_id'], f_format)
            worksheet.write(row, column+3, record['date_of_birth'].strftime('%d/%m/%Y'), f_format)
            worksheet.write(row, column+4, record['date'].strftime('%d/%m/%Y'), f_format)
            worksheet.write(row, column+5, record['sacrament_id'], f_format)
            worksheet.write(row, column+6, record['sacrament_type'], f_format)
            worksheet.write(row, column+7, record['location'], f_format)
            # worksheet.write(row, column+8, record['officiant'], f_format)
            worksheet.write(row, column+8, record['is_completed'], f_format)

        row += 1
        for rec in obj.get_by_officiant():
            vals = {'key': rec}
            if vals:
                row += 1
                worksheet.write(row, column, vals['key']['family_id'], f_format)
                worksheet.write(row, column+1, vals['key']['family_code'], f_format)
                worksheet.write(row, column+2, vals['key']['registration_member_id'], f_format)
                worksheet.write(row, column+3, vals['key']['date_of_birth'].strftime('%d/%m/%Y'), f_format)
                worksheet.write(row, column+4, vals['key']['date'].strftime('%d/%m/%Y'), f_format)
                worksheet.write(row, column+5, vals['key']['sacrament_id'], f_format)
                worksheet.write(row, column+6, vals['key']['sacrament_type'], f_format)
                worksheet.write(row, column+7, vals['key']['location'], f_format)