from odoo import models
import io

class ByFamilyReportXls(models.AbstractModel):
    _name = 'report.sacrament_management.xls_by_family_report'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format({'align': 'center','valign': 'vcenter','bold': True, 'size':16})
        f_format = workbook.add_format({'align': 'center'})
        # sub_heading_format = workbook.add_format({'align': 'left','valign': 'vcenter','bold': True, 'size':14})
        # bold = workbook.add_format({'align': 'center','bold': True})
        cell_text_format = workbook.add_format({'align': 'center','bold': True, 'size':12})
        worksheet = workbook.add_worksheet('By Family')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 15)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 15)
        worksheet.set_column('E:E', 20)
        worksheet.set_column('F:F', 20)
        worksheet.set_column('G:G', 25)
        worksheet.set_column('H:H', 25)
        family = obj.family_id.name
        worksheet.merge_range('A1:H2', "%s's Family Report" %(family), heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Family Code:', cell_text_format)
        worksheet.write(row, column+1, obj.family_code, f_format)
        row += 2
        worksheet.write(row, column, 'Member', cell_text_format)
        worksheet.write(row, column+1, 'DOB', cell_text_format)
        worksheet.write(row, column+2, 'Date of Sacrament', cell_text_format)
        worksheet.write(row, column+3, 'Sacrament', cell_text_format)
        worksheet.write(row, column+4, 'Sacrament Type', cell_text_format)
        worksheet.write(row, column+5, 'Location', cell_text_format)
        worksheet.write(row, column+6, 'Officiant', cell_text_format)
        worksheet.write(row, column+7, 'Completed', cell_text_format)
        row += 1
        sacrament_data = obj.get_report_xls()
        for record in sacrament_data['data']['sacrament']:
            row += 1
            worksheet.write(row, column, record['registration_member_id'], f_format)
            worksheet.write(row, column+1, record['date_of_birth'].strftime('%d/%m/%Y'), f_format)
            worksheet.write(row, column+2, record['date'].strftime('%d/%m/%Y'), f_format)
            worksheet.write(row, column+3, record['sacrament_id'], f_format)
            worksheet.write(row, column+4, record['sacrament_type'], f_format)
            worksheet.write(row, column+5, record['location'], f_format)
            worksheet.write(row, column+6, record['officiant'], f_format)
            worksheet.write(row, column+7, record['is_completed'], f_format)
