# -*- coding: utf-8 -*-

from . import res_partner
from . import funeral_registration
from . import funeral_by_family
from . import burial_places
