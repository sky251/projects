from odoo import fields, models, api, _
from odoo.exceptions import UserError

class ByAgeWizard(models.TransientModel):
    _name = "funeral.by.age.wizard"
    _description = "By Age Group Wizard"

    age_from = fields.Integer(string='Age From', copy=False)
    age_to = fields.Integer(string='Age To', copy=False)

    def print_by_age(self):
        age_list = []
        data = {
            'model': 'funeral.by.age.wizard',
            'form': self.read()[0]
        }
        age_data_ids = self.env['funeral.by.family'].search([('registration_member_id.age', '>=', self.age_from), (
            'registration_member_id.age', '<=', self.age_to)])
        if age_data_ids:
            for records in age_data_ids:
                vals = {
                    'family_id': records.family_id.name,
                    'family_code': records.family_code,
                    'registration_member_id': records.registration_member_id.name,
                    'date_of_birth': records.date_of_birth,
                    'age': records.registration_member_id.age,
                    'date_of_death': records.date_of_death,
                    'next_kin': records.registration_funeral_id.next_kin,
                    'ministries': records.registration_funeral_id.ministries.name,
                    'officiant': records.registration_funeral_id.officiant.name,
                    'funeral_date': records.registration_funeral_id.funeral_date,
                }
                if vals:
                    age_list.append(vals)
            data['age'] = age_list
            return self.env.ref('funeral_management.action_report_by_age').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        age_list = []
        data = {}
        age_data_ids = self.env['funeral.by.family'].search([('registration_member_id.age', '>=', self.age_from), (
            'registration_member_id.age', '<=', self.age_to)])
        if age_data_ids:
            for records in age_data_ids:
                vals = {
                    'family_id': records.family_id.name,
                    'family_code': records.family_code,
                    'registration_member_id': records.registration_member_id.name,
                    'date_of_birth': records.date_of_birth,
                    'age': records.registration_member_id.age,
                    'date_of_death': records.date_of_death,
                    'next_kin': records.registration_funeral_id.next_kin,
                    'ministries': records.registration_funeral_id.ministries.name,
                    'officiant': records.registration_funeral_id.officiant.name,
                    'funeral_date': records.registration_funeral_id.funeral_date,
                }
                if vals:
                    age_list.append(vals)
            data['age'] = age_list
            return self.env.ref('funeral_management.action_report_by_age_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))