from odoo import models, fields, api, _
from odoo.exceptions import UserError


class ByFamilyWizard(models.TransientModel):
    _name = "funeral.by.family.wizard"
    _description = "By Family Wizard"

    family_id = fields.Many2one(
        'res.partner', string='Family Name', copy=False)
    family_code = fields.Char(string='Family Code',
                              related="family_id.ref", copy=False)

    def get_by_family(self):
        family_list = []
        data = {}
        family_data_ids = self.env['funeral.by.family'].search(
            [('family_id', '=', self.family_id.id)])
        if family_data_ids:
            data['family'] = family_data_ids.ids
            return self.env.ref('funeral_management.by_family_report').with_context(landscape=True).report_action(family_list, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        family_list = []
        data = {}
        family_data_ids = self.env['funeral.by.family'].search(
            [('family_id', '=', self.family_id.id)])
        if family_data_ids:
            for records in family_data_ids:
                vals = {
                    'registration_member_id': records.registration_member_id.name,
                    'date_of_birth': records.date_of_birth,
                    'date_of_death': records.date_of_death,
                    'next_kin': records.registration_funeral_id.next_kin,
                    'ministries': records.registration_funeral_id.ministries.name,
                    'officiant': records.registration_funeral_id.officiant.name,
                    'funeral_date': records.registration_funeral_id.funeral_date
                }
                if vals:
                    family_list.append(vals)
            data['family'] = family_list
            return self.env.ref('funeral_management.by_family_report_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))
