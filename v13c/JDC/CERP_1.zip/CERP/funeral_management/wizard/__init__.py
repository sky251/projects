# -*- coding: utf-8 -*-
# Part of . See LICENSE file for full copyright and licensing details.

from . import by_family_wizard
from . import funeral_by_death_year_wizard
from . import funeral_by_birth_year_wizard
from . import by_age_wizard