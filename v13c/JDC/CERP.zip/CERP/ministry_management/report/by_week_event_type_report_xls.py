from odoo import models
import io


class ByWeekEventTypeReportXls(models.AbstractModel):
    _name = 'report.ministry_management.report_by_week_event_type_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format(
            {'align': 'center', 'valign': 'vcenter', 'bold': True, 'size': 16})
        f_format = workbook.add_format({'align': 'center'})
        bold = workbook.add_format({'align': 'center','bold': True, 'size': 12})
        cell_text_format = workbook.add_format(
            {'align': 'center', 'bold': True, 'size': 12})
        worksheet = workbook.add_worksheet('By Week Event')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 25)
        worksheet.set_column('D:D', 25)
        worksheet.set_column('E:E', 25)
        worksheet.set_column('F:F', 25)
        worksheet.set_column('G:G', 25)
        worksheet.merge_range('A1:G2', "By Week Event Report", heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'From Date:', cell_text_format)
        worksheet.write(
            row, column+1, (obj.date_from).strftime('%d/%m/%Y'), f_format)
        worksheet.write(row+1, column, 'To Date:', cell_text_format)
        worksheet.write(row+1, column+1,
                        (obj.date_to).strftime('%d/%m/%Y'), f_format)
        worksheet.write(row+2, column, 'Event Type:', cell_text_format)
        worksheet.write(row+2, column+1, obj.event_type, f_format)
        row += 4
        worksheet.write(row, column, 'Event', cell_text_format)
        worksheet.write(row, column+1, 'Responsible Group', cell_text_format)
        worksheet.write(row, column+2, 'Responsible Member', cell_text_format)
        worksheet.write(row, column+3, 'Officiant', cell_text_format)
        worksheet.write(row, column+4, 'Starting At', cell_text_format)
        worksheet.write(row, column+5, 'Ending At', cell_text_format)
        worksheet.write(row, column+6, 'Location', cell_text_format)
        ministry_data = data['ministry']
        for week_no in list(ministry_data.keys()):
            res = int(week_no)
            year = ministry_data[week_no][0]['year']
            if res:
                row += 2
                worksheet.write(row, column+3, "Week #%d of Year %s" % (res, year), bold)
                row += 1
                for week_data in ministry_data[week_no]:
                    print("\n\n\n week_data", week_data)
                    row += 1
                    if week_data['event_type']:
                        worksheet.write(row, column, week_data['event_type'], f_format)
                    else:
                        worksheet.write(row, column, '', f_format)
                    if week_data['responsible_group_id']:
                        worksheet.write(row, column+1, week_data['responsible_group_id'], f_format)
                    else:
                        worksheet.write(row, column+1, '', f_format)
                    if week_data['member_name']:
                        worksheet.write(row, column+2, week_data['member_name'], f_format)
                    else:
                        worksheet.write(row, column+2, '', f_format)
                    if week_data['officiant_id']:
                        worksheet.write(row, column+3, week_data['officiant_id'], f_format)
                    else:
                        worksheet.write(row, column+3, '', f_format)
                    if week_data['start_date']:
                        worksheet.write(row, column+4, week_data['start_date'], f_format)
                    else:
                        worksheet.write(row, column+4, '', f_format)
                    if week_data['stop_date']:
                        worksheet.write(row, column+5, week_data['stop_date'], f_format)
                    else:
                        worksheet.write(row, column+5, '', f_format)
                    if week_data['location']:
                        worksheet.write(
                            row, column+6, week_data['location'], f_format)
                    else:
                        worksheet.write(row, column+6, '', f_format)
                   