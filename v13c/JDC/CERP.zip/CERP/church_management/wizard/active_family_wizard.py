# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class ActiveFamilyWizard(models.TransientModel):
    _name = "active.family.wizard"
    _description = "Active Family Details"

    date_from = fields.Date('From Date')
    date_to = fields.Date('To Date')

    def print_active_family(self):
        records = []
        data = {}
        family_datas = []
        family_ids = self.env['res.partner'].search([('create_date', '>=', self.date_from),
            ('create_date', '<=', self.date_to),
            ('active', '=', True),
            ('inactive', '=', False),
            ('is_company', '=', True)])
        if family_ids:
            for family in family_ids:
                contact_names = []
                create_date = family.create_date
                name = family.name
                ref = family.ref
                contact_ids = self.env['res.partner'].search([
                    ('create_date', '>=', self.date_from),
                    ('create_date', '<=', self.date_to), 
                    ('active', '=', True),
                    ('inactive', '=', False), 
                    ('parent_id', '=', family.id)])
                for contact in contact_ids:
                    contact_names.append(contact.name)
                contacts = '[%s]' % ', '.join(map(str, contact_names))
                member_names = contacts.strip('[]')
                family_datas.append({'create_date': create_date, 'name':name, 'ref': ref, 'members':member_names})
                data['families'] = family_datas
            return self.env.ref('church_management.action_report_active_family').with_context(landscape=True).report_action(records, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence,this report cannot be printed.'))

    def get_report_xls(self):
        member_list = []
        data = {}
        family_datas = []
        family_ids = self.env['res.partner'].search([('create_date', '>=', self.date_from),
            ('create_date', '<=', self.date_to),
            ('active', '=', True),
            ('inactive', '=', False),
            ('is_company', '=', True)])
        if family_ids:
            for family in family_ids:
                contact_names = []
                create_date = family.create_date
                name = family.name
                ref = family.ref
                contact_ids = self.env['res.partner'].search([
                    ('create_date', '>=', self.date_from),
                    ('create_date', '<=', self.date_to), 
                    ('active', '=', True),
                    ('inactive', '=', False), 
                    ('parent_id', '=', family.id)])
                for contact in contact_ids:
                    contact_names.append(contact.name)
                contacts = '[%s]' % ', '.join(map(str, contact_names))
                member_names = contacts.strip('[]')
                family_datas.append({'create_date': create_date, 'name':name, 'ref': ref, 'members':member_names})
                data['families'] = family_datas
            return self.env.ref('church_management.action_report_active_family_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence,this report cannot be printed.'))