# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _


class ResponseWizard(models.TransientModel):
    _name = "response.wizard"
    _description = "Response Wizard"

    validation_text = fields.Text('')
