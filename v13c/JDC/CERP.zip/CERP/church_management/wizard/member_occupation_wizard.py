# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError

class MemberOccupationWizard(models.TransientModel):
    _name = "member.occupation.wizard"
    _description = "Member Occupation Details"

    occupation_id = fields.Many2one(
        'occupation.occupation', 'Occupation', copy=False)
    occupation_code = fields.Char(string='Occupation Code', related="occupation_id.code", copy=False)


    def print_member_occupation(self):
        occupation_list = []
        data = {
            'form': self.read()[0]
        }
        occupation_data = self.env['res.partner'].search(
            [('occupation', '=', self.occupation_id.id), ('is_company', '=', False)])
        if occupation_data:
            for details in occupation_data:
                vals = {
                    'family': details.parent_id.name,
                    'family_code': details.parent_id.ref,
                    'member_name': details.name,
                    'occupation': details.occupation.name,
                    'date_of_birth': details.date_of_birth,
                    'gender': details.gender,
                }
                if vals:
                    occupation_list.append(vals)
            data['member'] = occupation_list
            return self.env.ref('church_management.action_report_member_occupation').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        occupation_list = []
        data = {}
        occupation_data = self.env['res.partner'].search(
            [('occupation', '=', self.occupation_id.id), ('is_company', '=', False)])
        if occupation_data:
            for details in occupation_data:
                vals = {
                    'family': details.parent_id.name,
                    'family_code': details.parent_id.ref,
                    'member_name': details.name,
                    'date_of_birth': details.date_of_birth,
                    'gender': details.gender,
                }
                if vals:
                    occupation_list.append(vals)
            data['member'] = occupation_list
            return self.env.ref('church_management.action_report_member_occupation_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))
