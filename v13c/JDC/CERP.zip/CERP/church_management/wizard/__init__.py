# -*- coding: utf-8 -*-
# Part of . See LICENSE file for full copyright and licensing details.

from . import envelope_details_wizard
from . import tithe_wizard
from . import new_registered_member
from . import active_member_wizard
from . import compliance_non_compliance_member_wizard
from . import member_occupation_wizard
from . import donation_wizard
from . import student_report_wizard
from . import student_assign_unassign_report_wizard
from . import fees_wizard
from . import by_teacher_wizard
from . import by_age_gender_wizard
from . import by_envelope_label_wizard
from . import import_file_wizard
from . import active_family_wizard
from . import import_csv_file_wizard
from . import response_wizard