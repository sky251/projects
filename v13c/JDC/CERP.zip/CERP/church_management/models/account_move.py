# -*- coding: utf-8 -*-
from odoo import fields, models, api, _


class AccountMove(models.Model):
    _inherit = "account.move"

    def action_post(self):
        result = super(AccountMove, self).action_post()
        if result:
            member_registration_ids = self.env['member.registration'].search(
                [('partner_id', '=', self.partner_id.id), ('name', '=', self.invoice_origin)])
            for registration in member_registration_ids:
                if not registration.partial_paid:
                    registration.write({'partial_paid': True})
        return result
