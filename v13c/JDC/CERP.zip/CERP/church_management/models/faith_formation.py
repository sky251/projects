# -*- coding: utf-8 -*-
from odoo import fields, models,api,_
from odoo.exceptions import ValidationError

class FaithFormation(models.Model):
    _name = 'faith.formation'

    term_id = fields.Many2one('term.term', 'Term')
    level_id = fields.Many2one('level.level', 'Level')
    session_id = fields.Many2one('session.session', 'Session')
    partner_id = fields.Many2one('res.partner', 'Member')
    class_id = fields.Many2one('class.class', 'Class')
    not_complete = fields.Boolean('Not complete')
    member_detail_id = fields.Many2one('member.details','Member details')
    registration_id = fields.Many2one('member.registration', 'Registration', ondelete="cascade")
    cathechist = fields.Many2one('res.partner', related='class_id.cathechist', string='Teacher', copy=False,  store=True, readonly=True)
    day = fields.Selection(related='session_id.day_of_week', string='Day', store=True, readonly=True)
    time = fields.Selection(related='session_id.start_time', string='Time', store=True, readonly=True)

    def write(self, vals):
        for rec in self:
            if vals:
                if 'class_id' in vals and vals['class_id']:
                    allotment_by_class_id = self.env['allotment.by.class'].search([('allotment_class_id', '=', vals['class_id']), ('term_id', '=', rec.term_id.id)])
                    allotment_ids = self.env['allotment.allotment'].search([('class_id', '=', vals['class_id']), ('term_id', '=', rec.term_id.id)])
                    if allotment_ids:
                        if allotment_by_class_id:
                            allotment_by_class_id.write({'allotment_ids':[(6,0, allotment_ids.ids)]})
                        else:
                            allotment_by_class_id = self.env['allotment.by.class'].create({'allotment_class_id': vals['class_id'],
                                                                                           'term_id': rec.term_id and rec.term_id.id,
                                                                                           'allotment_ids': [(6,0, allotment_ids.ids)]})
                if self._context.get('Member'):
                    scheduling_id = self.env['allotment.allotment'].search([('member_detail_id', '=', rec.member_detail_id.id)])
                    if 'class_id' in vals:
                        class_id = vals['class_id']
                    else:
                        class_id = rec.class_id and rec.class_id.id
                    if 'term_id' in vals:
                        term_id = vals['term_id']
                    else:
                        term_id = rec.term_id and rec.term_id.id
                    if 'session_id' in vals:
                        session_id = vals['session_id']
                    else:
                        session_id = rec.session_id and rec.session_id.id
                    if 'level_id' in vals:
                        level_id = vals['level_id']
                    else:
                        level_id = rec.level_id and rec.level_id.id
                    if scheduling_id:
                        scheduling_id.write({
                                              'level_id': level_id,
                                              'session_id': session_id,
                                              'term_id': term_id,
                                              'class_id': class_id
                                            })
        return super(FaithFormation, self).write(vals)