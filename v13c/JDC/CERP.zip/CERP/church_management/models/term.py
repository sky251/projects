# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError
import datetime


class Terms(models.Model):
    _name = 'term.term'
    _description = "Terms"

    name = fields.Char('Term', copy=False)
    start_date = fields.Date('Start Date', default = datetime.date(datetime.date.today().year, 1, 1), copy=False)
    end_date = fields.Date('End Date', default = datetime.date(datetime.date.today().year, 12, 31), copy=False)
    is_current_term = fields.Boolean('Current Term')

    _sql_constraints = [('name_uniq', 'unique (name)', "Name already exists !")]

    @api.constrains('end_date', 'start_date')
    def date_constrains(self):
        same_terms = []
        if self.end_date < self.start_date:
            raise ValidationError(_('End Date Must be greater than Start Date'))
        term_ids = self.search([])
        term_id = term_ids.filtered(lambda x: x.start_date.year == self.start_date.year)
        if len(term_id) > 1:
            raise ValidationError(_('Current year term is already defined'))