# -*- coding: utf-8 -*-
from odoo import fields, models

class Occupation(models.Model):
    _name = 'occupation.occupation'
    # _rec_name = 'code'

    name = fields.Char('Occupation')
    code = fields.Char('Code')