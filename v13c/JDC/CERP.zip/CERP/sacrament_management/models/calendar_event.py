# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
import datetime
from odoo.exceptions import ValidationError
import psycopg2

class CalendarEvent(models.Model):
    _inherit = 'calendar.event'

    sacrament_family_id = fields.Many2one(
        'sacrament.details', 'Registration', ondelete="cascade", copy=False)
    sacrament_id = fields.Many2one(
        'sacrament.sacrament', 'Sacrament', copy=False)
    is_sacramented = fields.Boolean('is sacramented', copy=False)
    states = fields.Selection([('confirm', 'Confirm'), ('cancel', 'Cancel')], 
    	tracking=True, default='confirm', copy=False)
