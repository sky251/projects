# -*- coding: utf-8 -*-

from . import res_partner
from . import sacrament
from . import sacrament_registration
from . import calendar_event