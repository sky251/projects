from odoo import models
import io

class ByNotReceivedSacramentReportXls(models.AbstractModel):
    _name = 'report.sacrament_management.not_received_sacrament_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format({'align': 'center','valign': 'vcenter','bold': True, 'size':16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format({'align': 'center','bold': True, 'size':12})
        sacrament_data = obj.get_report_xls()
        worksheet = workbook.add_worksheet('By Not Received Sacrament')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 25)
        worksheet.set_column('D:D', 25)
        worksheet.merge_range('A1:D2', "Not Received Sacrament Report", heading_format)
        row = 4
        column = 0
        # row += 3
        worksheet.write(row, column, 'Family', cell_text_format)
        worksheet.write(row, column+1, 'Family Code', cell_text_format)
        worksheet.write(row, column+2, 'Member', cell_text_format)
        worksheet.write(row, column+3, 'DOB', cell_text_format)
        row += 1
        for record in sacrament_data['data']['sacrament']:
            row += 1
            worksheet.write(row, column, record['family_id'], f_format)
            worksheet.write(row, column+1, record['family_code'], f_format)
            worksheet.write(row, column+2, record['registration_member_id'], f_format)
            worksheet.write(row, column+3, record['date_of_birth'], f_format)
