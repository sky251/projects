from odoo import models, fields, api,_
import io

class ByAgeReportXls(models.AbstractModel):
    _name = 'report.funeral_management.by_age_group_report_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format({'align': 'center','valign': 'vcenter','bold': True, 'size':16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format({'align': 'center','bold': True, 'size':12})
        worksheet = workbook.add_worksheet('By Age Group')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 15)
        worksheet.set_column('C:C', 25)
        worksheet.set_column('D:D', 25)
        worksheet.set_column('E:E', 15)
        worksheet.set_column('F:F', 20)
        worksheet.set_column('G:G', 25)
        worksheet.set_column('H:H', 25)
        worksheet.set_column('I:I', 25)
        worksheet.set_column('J:J', 25)
        worksheet.merge_range('A1:J2', "By Age Group Report", heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Age From:', cell_text_format)
        worksheet.write(
            row, column+1, (obj.age_from), f_format)
        worksheet.write(row+1, column, 'Age To:', cell_text_format)
        worksheet.write(row+1, column+1,
                        (obj.age_to), f_format)
        row += 3
        worksheet.write(row, column, 'Family', cell_text_format)
        worksheet.write(row, column+1, 'Family Code', cell_text_format)
        worksheet.write(row, column+2, 'Member', cell_text_format)
        worksheet.write(row, column+3, 'Date of Birth', cell_text_format)
        worksheet.write(row, column+4, 'Age', cell_text_format)
        worksheet.write(row, column+5, 'Date of Death', cell_text_format)
        worksheet.write(row, column+6, 'Next of Kin', cell_text_format)
        worksheet.write(row, column+7, 'Ministries', cell_text_format)
        worksheet.write(row, column+8, 'Officiant', cell_text_format)
        worksheet.write(row, column+9, 'Date of Funeral', cell_text_format)
        row += 1
        age_data = obj.get_report_xls()
        for age in age_data['data']['age']:
            row += 1
            if age['family_id']:
                worksheet.write(row, column, age['family_id'], f_format)
            else:
                worksheet.write(row, column, '', f_format)
            if age['family_code']:
                worksheet.write(row, column+1, age['family_code'], f_format)
            else:
                worksheet.write(row, column+1, '', f_format)
            if age['registration_member_id']:
                worksheet.write(row, column+2, age['registration_member_id'], f_format)
            else:
                worksheet.write(row, column+2, '', f_format)
            if age['date_of_birth']:
                worksheet.write(row, column+3, age['date_of_birth'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+3, '', f_format)
            if age['age']:
                worksheet.write(row, column+4, age['age'], f_format)
            else:
                worksheet.write(row, column+4, '', f_format)
            if age['date_of_death']:
                worksheet.write(row, column+5, age['date_of_death'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+5, '', f_format)
            if age['next_kin']:
                worksheet.write(row, column+6, age['next_kin'], f_format)
            else:
                worksheet.write(row, column+6, '', f_format)
            if age['ministries']:
                worksheet.write(row, column+7, age['ministries'], f_format)
            else:
                worksheet.write(row, column+7, '', f_format)
            if age['officiant']:
                worksheet.write(row, column+8, age['officiant'], f_format)
            else:
                worksheet.write(row, column+8, '', f_format)
            if age['funeral_date']:
                worksheet.write(row, column+9, age['funeral_date'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+9, '', f_format)
