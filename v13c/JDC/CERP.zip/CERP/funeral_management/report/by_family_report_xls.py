from odoo import models, fields, api,_
import io

class ReportByFamily(models.AbstractModel):
    _name = 'report.funeral_management.by_family_wizard_report'

    @api.model
    def _get_report_values(self, docids, data=None):
        family_list = []
        self.model = self.env.context.get('active_model')
        docs = self.env[self.model].browse(self.env.context.get('active_ids', []))
        if data['family']:
            for family in data['family']:
                family_id = self.env['funeral.by.family'].search([('id', '=', family)])
                family_list.append(family_id)
        return {
            'doc_ids': docids,
            'doc_model': self.model,
            'docs': docs,
            'family': family_list
        }

class ByFamilyReportXls(models.AbstractModel):
    _name = 'report.funeral_management.xls_by_family_report'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format({'align': 'center','valign': 'vcenter','bold': True, 'size':16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format({'align': 'center','bold': True, 'size':12})
        worksheet = workbook.add_worksheet('By Family')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 20)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 15)
        worksheet.set_column('E:E', 20)
        worksheet.set_column('F:F', 20)
        worksheet.set_column('G:G', 25)
        family = obj.family_id.name
        worksheet.merge_range('A1:G2', "%s's Family Report" %(family), heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Family Code:', cell_text_format)
        worksheet.write(row, column+1, obj.family_code, f_format)
        row += 2
        worksheet.write(row, column, 'Member', cell_text_format)
        worksheet.write(row, column+1, 'Date of Birth', cell_text_format)
        worksheet.write(row, column+2, 'Date of Death', cell_text_format)
        worksheet.write(row, column+3, 'Next of Kin', cell_text_format)
        worksheet.write(row, column+4, 'Ministries', cell_text_format)
        worksheet.write(row, column+5, 'Officiant', cell_text_format)
        worksheet.write(row, column+6, 'Date of Funeral', cell_text_format)
        row += 1
        family_data = obj.get_report_xls()
        for record in family_data['data']['family']:
            row += 1
            if record['registration_member_id']:
                worksheet.write(row, column, record['registration_member_id'], f_format)
            else:
                worksheet.write(row, column, '', f_format)
            if record['date_of_birth']:
                worksheet.write(row, column+1, record['date_of_birth'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+1, '', f_format)
            if record['date_of_death']:
                worksheet.write(row, column+2, record['date_of_death'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+2, '', f_format)
            if record['next_kin']:
                worksheet.write(row, column+3, record['next_kin'], f_format)
            else:
                worksheet.write(row, column+3, '', f_format)
            if record['ministries']:
                worksheet.write(row, column+4, record['ministries'], f_format)
            else:
                worksheet.write(row, column+4, '', f_format)
            if record['officiant']:
                worksheet.write(row, column+5, record['officiant'], f_format)
            else:
                worksheet.write(row, column+5, '', f_format)
            if record['funeral_date']:
                worksheet.write(row, column+6, record['funeral_date'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+6, '', f_format)
