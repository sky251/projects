# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from datetime import datetime
from odoo.exceptions import ValidationError


class FuneralRegistration(models.Model):
    _name = 'funeral.registration'
    _description = "Funeral Registration"

    name = fields.Char('Name', copy=False)
    partner_id = fields.Many2one(
        'res.partner', string='Family Name', copy=False)
    family_code = fields.Char(string='Family Code', copy=False)
    is_create = fields.Boolean('Is Create?')
    member_detail_ids = fields.One2many(
        'funeral.member.details', 'registration_id', string='Family Members', copy=False)

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code(
            'funeral.registration') or 'New'
        res = super(FuneralRegistration, self).create(vals)
        res.is_create = True
        return res

    @api.constrains('member_detail_ids', 'partner_id')
    def member_details_constarains(self):
        if len(self.member_detail_ids) == 0:
            raise ValidationError(_('Please add member details.'))

    @api.onchange('family_code')
    def _onchange_family_code(self):
        if self.family_code:
            partner_id = self.env['res.partner'].search(
                [('envelope_ref', '=', self.family_code), ('is_company', '=', True)])
            if partner_id:
                self.partner_id = partner_id.id
        else:
            self.partner_id = False
            self.member_detail_ids = False

    @api.onchange('partner_id')
    def _onchange_partner_id(self):
        if self.partner_id:
            self.member_detail_ids = False
            if self.partner_id.ref:
                self.family_code = self.partner_id.ref
        else:
            self.family_code = False
            self.member_detail_ids = False


class FuneralMemberDetails(models.Model):
    _name = 'funeral.member.details'
    _description = 'Funeral and Member Details'

    registration_id = fields.Many2one(
        'funeral.registration', 'Funeral Registration', ondelete="cascade", copy=False)
    registration_member_id = fields.Many2one(
        'res.partner', 'Member', copy=False)
    date_of_death = fields.Date(
        'Date of Death', copy=False)
    year = fields.Char('Year', copy=False)
    family_id = fields.Many2one(
        'res.partner', 'Family', related="registration_member_id.parent_id", copy=False)
    next_kin = fields.Selection([('aunt', 'Aunt'),
                                 ('brother', 'Brother'),
                                 ('child', 'Child'),
                                 ('father', 'Father'),
                                 ('grandparent', 'Grandparent'),
                                 ('mother', 'Mother'),
                                 ('mother-in-law', 'Mother-in-law'),
                                 ('significant_other', 'Significant Other'),
                                 ('sister', 'Sister'),
                                 ('uncle', 'Uncle'),
                                 ('friend', 'Friend')], copy=False)
    ministries = fields.Many2one(
        'ministry.ministry', string='Ministries', copy=False)
    officiant = fields.Many2one('res.partner', 'Officiant', copy=False)
    cemetery = fields.Many2one('burial.places', 'Cemetery', copy=False)
    funeral_date = fields.Date('Date of Funeral/Mass', copy=False)
    mass_service = fields.Boolean('Mass Service', copy=False)
    not_registered = fields.Boolean('Not Registered', copy=False)

    @api.onchange('date_of_death')
    def _onchange_dod(self):
        if self.date_of_death:
            dod = self.date_of_death
            dod_year = dod.year
            self.year = str(int(dod_year))
            date_of_death = str((self.date_of_death))
            current_date = str(datetime.now().date())
            if (date_of_death > current_date):
                raise ValidationError(
                    _('Please enter date less than or equals to todays date i.e: %s' % (current_date)))

    @api.onchange('funeral_date')
    def _onchange_funeral_date(self):
        if self.funeral_date:
            date_of_death = str((self.date_of_death))
            funeral_date = str(self.funeral_date)
            if (funeral_date < date_of_death):
                raise ValidationError(
                    _('Please enter date greater than or equals to death date i.e: %s' % (date_of_death)))

    @api.model
    def create(self, vals_list):
        member_exist_rec = self.env['funeral.by.family'].search(
            [('registration_member_id', '=', vals_list['registration_member_id'])])
        if member_exist_rec:
            raise ValidationError(
                _('Member - %s is already registered' % (member_exist_rec.registration_member_id.name)))
        else:
            res = super(FuneralMemberDetails, self).create(vals_list)
            funeral_reg_list = []
            for rec in res:
                vals = {
                    'registration_funeral_id': rec.id,
                    'registration_member_id': rec.registration_member_id.id,
                    'family_id': rec.family_id.id,
                    'date_of_death': rec.date_of_death,
                }
                funeral_reg_list.append(vals)
            self.env['funeral.by.family'].create(funeral_reg_list)
            return res

    def write(self, vals):
        for rec in self:
            if 'registration_member_id' in vals:
                registration_member_id = vals['registration_member_id']
            else:
                registration_member_id = rec.registration_member_id and rec.registration_member_id.id
            if 'family_id' in vals:
                family_id = vals['family_id']
            else:
                family_id = rec.family_id and rec.family_id.id
            if 'date_of_death' in vals:
                date_of_death = vals['date_of_death']
            else:
                date_of_death = rec.date_of_death
        member_rec = self.env['funeral.by.family'].search(
            [('registration_funeral_id', '=', self.id)])
        if member_rec:
            member_rec.write({
                'registration_member_id': registration_member_id,
                'family_id': family_id,
                'date_of_death': date_of_death})
        res = super(FuneralMemberDetails, self).write(vals)
        return res

    @api.onchange('registration_member_id')
    def _onchange_not_registered(self):
        res = {}
        if self.registration_id.partner_id:
            res['domain'] = {'registration_member_id': [
                ('parent_id', '=', self.registration_id.partner_id.id)]}
        else:
            res['domain'] = {'registration_member_id': [
                ('is_company', '=', False)]}
        for obj in self:
            if obj.registration_member_id and obj.registration_member_id.enable_partner:
                obj.not_registered = True
            else:
                obj.not_registered = False
        return res
