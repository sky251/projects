# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
import datetime
from odoo.exceptions import ValidationError


class FuneralByFamily(models.Model):
    _name = 'funeral.by.family'
    _description = "Funeral by Family"

    registration_funeral_id = fields.Many2one(
        'funeral.member.details', 'registration', ondelete="cascade", copy=False)
    registration_member_id = fields.Many2one(
        'res.partner', 'Member', copy=False)
    family_id = fields.Many2one('res.partner', 'Family Name', copy=False)
    family_code = fields.Char('Family Id', related="family_id.ref", copy=False)
    date_of_birth = fields.Date('DOB',related="registration_member_id.date_of_birth", copy=False)
    date_of_death = fields.Date('DOD', copy=False)
    year = fields.Char('Year', related="registration_funeral_id.year", copy=False)