Read the `contributors list`_

.. _contributors list: ./AUTHORS
