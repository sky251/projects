# -*- coding: utf-8 -*-
from odoo import fields, models
import datetime
from odoo.exceptions import ValidationError


class Partner(models.Model):
    _inherit = 'res.partner'

    sacrament_ids = fields.One2many('sacrament.member.details', 'member_id', string="Sacrament",copy=False)
    # sacrament_member_id = fields.Many2one('sacrament.member.details', copy=False, default=False)

class SacramentMemberDetails(models.Model):
	_name = 'sacrament.member.details'
	_description = "Sacrament Member Details"

	member_id = fields.Many2one('res.partner', 'Member', copy=False)
	partner_id = fields.Many2one('res.partner', 'Partner', copy=False)
	sacrament_family_id = fields.Many2one(
        'sacrament.details', 'Registration', ondelete="cascade", copy=False)
	sacrament_id = fields.Many2one('sacrament.sacrament', 'Sacrament', copy=False)
	scarament_type_id = fields.Selection([('initiation', 'Initiation'),
		('healing', 'Healing'),
		('service', 'Service')], 'Sacrament Type')
	sacrament_certificate = fields.Binary('Sacrament Certification')
	date = fields.Date('Date', copy=False)
	location = fields.Many2one('place.parish', string='Location', copy=False)
	officiant_id = fields.Many2one('res.partner', 'Officiant', copy=False)
	# witness_ids = fields.Many2many('res.partner', 'sacrament_member_partner_rel',
	# 							   string='Witness', copy=False, default=False)
	witness = fields.Text('Witness')