# -*- coding: utf-8 -*-
from odoo import fields, models, _, api
from odoo.exceptions import ValidationError,UserError
import datetime


class Allotment(models.Model):
    _name = 'allotment.allotment'

    allotment_family_id = fields.Many2one('member.registration', 'Registration',  copy=False)
    class_id = fields.Many2one('class.class', 'Class', copy=False)
    session_id = fields.Many2one('session.session', 'Session', copy=False)
    level_id = fields.Many2one('level.level', 'Levels', copy=False)
    child_id = fields.Many2one('res.partner', 'Child Name', copy=False)
    date_of_birth = fields.Date('DOB', copy=False)
    term_id = fields.Many2one('term.term', 'Term', copy=False)
    remarks = fields.Text('Remarks', copy=False)
    family_id = fields.Many2one('res.partner', 'Family', copy=False)
    allotment_by_family_id = fields.Many2one('allotment.by.family', 'Allotment by Family', copy=False)
    allotment_by_level_id = fields.Many2one('allotment.by.level', 'Allotment By Level', copy=False)
    allotment_by_class_id = fields.Many2one('allotment.by.class', 'Allotment By Class', copy=False)
    member_detail_id = fields.Many2one('member.details','Member details', ondelete="cascade",copy=False)
    registration_id = fields.Many2one('member.registration', 'Registration', ondelete="cascade" , copy=False)
    assigned = fields.Boolean('Assigned', default=False, copy=False)

    def write(self, vals):
        for rec in self:
            if vals and self._context.get('Scheduling'):
                faith_formation_id = self.env['faith.formation'].search([('member_detail_id', '=', rec.member_detail_id.id)])
                if 'class_id' in vals:
                    class_id = vals['class_id']
                else:
                    class_id = rec.class_id and rec.class_id.id
                if 'term_id' in vals:
                    term_id = vals['term_id']
                else:
                    term_id = rec.term_id and rec.term_id.id
                if 'session_id' in vals:
                    session_id = vals['session_id']
                else:
                    session_id = rec.session_id and rec.session_id.id
                if 'level_id' in vals:
                    level_id = vals['level_id']
                else:
                    level_id = rec.level_id and rec.level_id.id
                if faith_formation_id:
                    faith_formation_id.write({ 
                                          'level_id': level_id,
                                          'session_id': session_id,
                                          'term_id': term_id,
                                          'class_id': class_id
                                        })
                if 'class_id' in vals and vals['class_id']:
                    allotment_by_class_id = self.env['allotment.by.class'].search([('allotment_class_id', '=', vals['class_id']), ('term_id', '=', rec.term_id.id)])
                    allotment_ids = self.env['allotment.allotment'].search([('class_id', '=', vals['class_id']), ('term_id', '=', rec.term_id.id)])
                    if allotment_ids:
                        if allotment_by_class_id:
                            allotment_by_class_id.write({'allotment_ids':[(6,0, allotment_ids.ids)]})
                        else:
                            allotment_by_class_id = self.env['allotment.by.class'].create({'allotment_class_id': vals['class_id'],
                                                                                           'term_id': rec.term_id and rec.term_id.id,
                                                                                           'allotment_ids': [(6,0, allotment_ids.ids)]})
                    class_id = self.env['class.class'].browse(vals['class_id'])
                    class_id._get_class_count()
                    vals['assigned'] = True
                elif not 'class_id' in vals and rec.class_id:
                    rec.class_id._get_class_count()
                    vals['assigned'] = True
                else:
                    vals['assigned'] = False
        return super(Allotment, self).write(vals)

    @api.constrains('session_id')
    def session_class_constrain(self):
        for rec in self:
            if rec.session_id:
                assigned_class_ids = self.env['class.class'].search([('session_id', '=', rec.session_id.id)])
                if assigned_class_ids:
                    class_ids = self.env['class.class'].search([('is_unavailable', '=', False),('session_id', '=', rec.session_id.id)])
                    if class_ids:
                        rec.session_id.write({'is_unavailable': False})
                    else:
                        raise ValidationError(_('This session is already full.You need to assign another one.'))
                else:
                    raise ValidationError(_('You need to create class for session first.'))
            if rec.class_id and rec.class_id.is_unavailable:
                raise ValidationError(_('This class is already full.You need to assign another one.'))


class AllotmentByFamily(models.Model):
    _name = 'allotment.by.family'
    _rec_name = 'allotment_family_id'

    @api.constrains('allotment_family_id')
    def allotment_family_constrains(self):
        allotment_family_id = self.search([('allotment_family_id', '=', self.allotment_family_id.id), ('term_id', '=', self.term_id.id)])
        if len(allotment_family_id) > 1:
            raise ValidationError(_('This family is already created for allotment.'))

    def _get_current_term(self):
        today = datetime.datetime.today()
        term_ids = self.env['term.term'].search([])
        term_id = term_ids.filtered(lambda x: x.start_date.year == datetime.datetime.today().year)
        if term_id:
            return term_id.id
        else:
            return False
        # for term in term_ids:
        #     if term.start_date.year == today.year:
        #         return term.id
        #     else:
        #         return False
        # if not term_ids:
        #     return False

    allotment_family_id = fields.Many2one('res.partner', 'Family', copy=False)
    allotment_ids = fields.One2many('allotment.allotment','allotment_by_family_id', 'Allotments', copy=False)
    term_id = fields.Many2one('term.term', 'Term', default=_get_current_term, copy=False)

class AllotmentBylevel(models.Model):
    _name = 'allotment.by.level'
    _rec_name = 'allotment_level_id'

    @api.constrains('allotment_level_id')
    def allotment_level_constrains(self):
        allotment_level_id = self.search([('allotment_level_id', '=', self.allotment_level_id.id), ('term_id', '=', self.term_id.id)])
        if len(allotment_level_id) > 1:
            raise ValidationError(_('This level is already created for allotment.'))

    def _get_current_term(self):
        today = datetime.datetime.today()
        term_ids = self.env['term.term'].search([])
        term_id = term_ids.filtered(lambda x: x.start_date.year == datetime.datetime.today().year)
        if term_id:
            return term_id.id
        else:
            return False
        # today = datetime.datetime.today()
        # term_ids = self.env['term.term'].search([])
        # for term in term_ids:
        #     if term.start_date.year == today.year:
        #         return term_id.id
        #     else:
        #         return False
        # if not term_ids:
        #     return False

    allotment_level_id = fields.Many2one('level.level', 'Level', copy=False)
    allotment_ids = fields.One2many('allotment.allotment','allotment_by_level_id', 'Allotments', compute="get_allotments", copy=False)
    term_id = fields.Many2one('term.term', 'Term', default=_get_current_term, copy=False)

    def get_allotments(self):
        class_allotments = []
        for rec in self:
            if rec.allotment_level_id:
                allotment_by_level_id = self.env['allotment.by.level'].search([('allotment_level_id', '=', rec.allotment_level_id.id), ('term_id', '=', rec.term_id.id)])
                allotment_ids = self.env['allotment.allotment'].search([('level_id', '=', rec.allotment_level_id.id), ('term_id', '=', rec.term_id.id)])
                sorted_by_name = allotment_ids.sorted(key=lambda allotment: allotment.child_id.name)
                session_allotments = sorted_by_name.filtered(lambda allotment: allotment.session_id)
                sorted_allotments = session_allotments.sorted(key=lambda allotment: allotment.registration_id.registration_date)
                sorted_by_not_session_name = sorted_by_name.filtered(lambda allotment: not allotment.session_id)
                not_session_allotments_by_date = sorted_by_not_session_name.sorted(key=lambda allotment: allotment.registration_id.registration_date)
                class_allotments = sorted_allotments.filtered(lambda allotment: allotment.class_id)
                not_class_allotments = sorted_allotments.filtered(lambda allotment: not allotment.class_id)
                allotments = class_allotments + not_class_allotments + not_session_allotments_by_date
                if allotment_by_level_id:
                    rec.allotment_ids = [(6,0, allotments.ids)]
                else:
                    allotment_by_level_id = self.env['allotment.by.level'].create({'allotment_level_id': rec.allotment_level_id.id,
                                                                                   'allotment_ids':[(6,0, allotments.ids)]})
                if class_allotments:
                    for c in class_allotments:
                        c.write({'assigned': True})
                not_only_class_allotments = allotment_ids.filtered(lambda allotment: not allotment.class_id)
                if not_only_class_allotments:
                    for c in not_only_class_allotments:
                        c.write({'assigned': False})

    def auto_schedule(self):
        session_allotment_ids = self.mapped('allotment_ids').filtered(lambda allotment: allotment.session_id)
        final_allotments = 0
        Allotments = len(self.allotment_ids)
        for allotment in session_allotment_ids:
            final_allotments += 1
            allotment_ids = session_allotment_ids.search([('session_id', '=',allotment.session_id.id)])
            class_ids = self.env['class.class'].search([('session_id', '=', allotment.session_id.id), ('is_unavailable', '=', False)])
            if class_ids:
                for c in class_ids:
                    if not allotment.class_id and not c.is_unavailable:
                        count = 0
                        max_capacity = c.max_capacity
                        for allot in allotment_ids:
                            if not allot.class_id and c.max_capacity != count:
                                count = c.class_count + 1
                                allot.write({'class_id': c.id,'assigned': True})
                                c.write({'class_count': count})
                            if c.class_count == c.max_capacity:
                                c.write({'is_unavailable': True})
        not_session_allotment_ids = self.mapped('allotment_ids').filtered(lambda allotment: not allotment.session_id)
        for allotment in not_session_allotment_ids:
            final_allotments += 1
            session_ids = self.env['session.session'].search([('level_id', '=', self.allotment_level_id.id)])
            session_count = 0
            if session_ids:
                for session in session_ids:
                    class_ids = self.env['class.class'].search([('session_id', '=', session.id), ('is_unavailable', '=', False)])
                    if not class_ids:
                        session.write({'is_unavailable': True})
                    else:
                        if not allotment.session_id and not session.is_unavailable:
                            session_count += 1
                            allotment.write({'session_id': session.id})
                            class_count = 0
                            for c in class_ids:
                                if not allotment.class_id and not c.is_unavailable and c.max_capacity != c.class_count:
                                    class_count = c.class_count + 1
                                    allotment.write({'class_id': c.id, 'assigned': True})
                                    c.write({'class_count': class_count})
                                if c.class_count == c.max_capacity:
                                    c.write({'is_unavailable': True})

        not_session_class = len(self.mapped('allotment_ids').filtered(lambda allotment: not allotment.session_id and not allotment.class_id)) or 0
        not_class = len(self.mapped('allotment_ids').filtered(lambda allotment: allotment.session_id and not allotment.class_id)) or 0
        total_alloted_session_class = len(self.mapped('allotment_ids').filtered(lambda allotment: allotment.session_id and allotment.class_id)) or 0
        total_Allotments = len(self.mapped('allotment_ids').ids)
        self.env.cr.commit()
        if Allotments == final_allotments:
            return self.allotment_message(not_session_class, not_class, total_alloted_session_class,total_Allotments)

    def allotment_message(self,not_session_class, not_class, total_alloted_session_class, total_Allotments):
        action = self.env.ref('church_management.action_view_scheduling_wizard_view').read()[0]
        action['context'] = {
            'default_total_alloted_count': total_alloted_session_class,
            'default_not_alloted_count': not_session_class,
            'default_not_class_only': not_class,
            'default_total_allotments': total_Allotments
        }
        return action

class AllotmentByClass(models.Model):
    _name = 'allotment.by.class'
    _rec_name = 'allotment_class_id'

    @api.constrains('allotment_class_id')
    def allotment_class_constrains(self):
        allotment_class_id = self.search([('allotment_class_id', '=', self.allotment_level_id.id), ('term_id', '=', self.term_id.id)])
        if len(allotment_class_id) > 1:
            raise ValidationError(_('This class is already created for allotment.'))

    def _get_current_term(self):
        today = datetime.datetime.today()
        term_ids = self.env['term.term'].search([])
        term_id = term_ids.filtered(lambda x: x.start_date.year == datetime.datetime.today().year)
        if term_id:
            return term_id.id
        else:
            return False
        # today = datetime.datetime.today()
        # term_ids = self.env['term.term'].search([])
        # for term in term_ids:
        #     if term.start_date.year == today.year:
        #         return term_id.id
        #     else:
        #         return False
        # if not term_ids:
        #     return False

    allotment_class_id = fields.Many2one('class.class', 'Class', copy=False)
    allotment_ids = fields.One2many('allotment.allotment','allotment_by_class_id', 'Allotments',compute="get_allotments", copy=False)
    term_id = fields.Many2one('term.term', 'Term', default=_get_current_term, copy=False)

    def get_allotments(self):
        class_allotments = []
        for rec in self:
            if rec.allotment_class_id:
                allotment_by_class_id = self.env['allotment.by.class'].search([('allotment_class_id', '=', rec.allotment_class_id.id)])
                allotment_ids = self.env['allotment.allotment'].search([('class_id', '=', rec.allotment_class_id.id), ('term_id', '=', rec.term_id.id)])
                sorted_by_name = allotment_ids.sorted(key=lambda allotment: allotment.child_id.name)
                session_allotments = sorted_by_name.filtered(lambda allotment: allotment.session_id)
                sorted_allotments = session_allotments.sorted(key=lambda allotment: allotment.registration_id.registration_date)
                sorted_by_not_session_name = sorted_by_name.filtered(lambda allotment: not allotment.session_id)
                not_session_allotments_by_date = sorted_by_not_session_name.sorted(key=lambda allotment: allotment.registration_id.registration_date)
                class_allotments = sorted_allotments.filtered(lambda allotment: allotment.class_id)
                not_class_allotments = sorted_allotments.filtered(lambda allotment: not allotment.class_id)
                allotments = class_allotments + not_class_allotments + not_session_allotments_by_date
                if allotment_by_class_id:
                    rec.allotment_ids = [(6,0, allotments.ids)]
                else:
                    allotment_by_class_id = self.env['allotment.by.class'].create({'allotment_class_id': rec.allotment_class_id.id,
                                                                                   'allotment_ids':[(6,0, allotments.ids)]})
                if class_allotments:
                    for c in class_allotments:
                        c.write({'assigned': True})
                not_only_class_allotments = allotment_ids.filtered(lambda allotment: not allotment.class_id)
                if not_only_class_allotments:
                    for c in not_only_class_allotments:
                        c.write({'assigned': False})