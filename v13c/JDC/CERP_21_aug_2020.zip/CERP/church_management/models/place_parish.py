# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError


class PlaceParish(models.Model):
    _name = 'place.parish'
    _description = 'Place Parish Details'

    code = fields.Char('Code', copy=False, default=False)
    name = fields.Char('Place', copy=False, default=False)
    street_1 = fields.Char('Address',copy=False)
    street_2 = fields.Char('Address 2',copy=False)
    mailing_address = fields.Char('Mailing Address', copy=False)
    town = fields.Char('Town', copy=False, default=False)
    state_id = fields.Many2one("res.country.state", string='State', ondelete='restrict', domain="[('country_id', '=?', country_id)]", copy=False)
    zip_code = fields.Char('Zip',change_default=True)
    country_id = fields.Many2one('res.country', string='Country', ondelete='restrict', copy=False)
    phone = fields.Char('Phone', copy=False)
    plus_4 = fields.Integer('Plus 4', copy=False, default=False)
    redirect = fields.Char('Re-Direct', copy=False, default=False)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if  'code' in vals and vals['code']:
                if not vals['code'].isdigit():
                    raise ValidationError(_('Code must be a number.'))
                else:
                    vals['code'] = vals['code']
        return super(PlaceParish, self).create(vals_list)

    def write(self, vals):
        for rec in self:
            if 'code' in vals and vals['code']:
                if not vals['code'].isdigit():
                    raise ValidationError(_('Code must be a number.'))
            else:
                if self.code.isdigit():
                    raise ValidationError(_('Code must be a number.'))
            vals['code'] = vals['code']
        res = super(PlaceParish, self).write(vals)
        return res

    def name_get(self):
        res = []
        for place in self:
            name = '%s, %s' %(place.name, place.town)
            res.append((place.id, name))
        return res