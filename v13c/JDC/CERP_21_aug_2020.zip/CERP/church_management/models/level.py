# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError
import datetime
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT

class Level(models.Model):
    _name = 'level.level'
    _description = "Levels"
    
    def _get_start_dob(self):
        for rec in self:
            beginning_date = rec.term_id and rec.term_id.start_date
            calculated_year = datetime.datetime.today().year - (rec.school_grade + 6)
            if beginning_date:
                rec.start_dob = beginning_date.replace(year=calculated_year)
            else:
                rec.start_dob = False

    name = fields.Char('Name', copy=False)
    description = fields.Text('Description', copy=False)
    start_dob = fields.Date('Start D.O.B', copy=False, compute="_get_start_dob")
    end_dob = fields.Date('End D.O.B', copy=False, compute="_get_end_dob")
    term_id = fields.Many2one('term.term', 'Term', copy=False)
    school_grade = fields.Integer('School Grade', copy=False)

    _sql_constraints = [('name_uniq', 'unique (name)', "Name already exists !")]

    @api.constrains('end_dob', 'start_dob')
    def date_constrains(self):
       for rec in self:
           if rec.end_dob < rec.start_dob:
            raise ValidationError(_('End Date Must be greater than Start Date'))

    @api.model_create_multi
    def create(self, vals_list):
        res = super(Level, self).create(vals_list)
        if res:
            self.env['allotment.by.level'].create({
                            'allotment_level_id': res.id, 'term_id': res.term_id.id})
        return res

    def _get_end_dob(self):
        for rec in self:
            ending_date = rec.term_id and rec.term_id.end_date
            calculated_year = datetime.datetime.today().year - (rec.school_grade + 5)
            if ending_date:
                rec.end_dob  = ending_date.replace(year=calculated_year)
            else:
                rec.end_dob = False
