# -*- coding: utf-8 -*-
from odoo import fields, models

class TitheComparison(models.TransientModel):
    _name = 'tithe.comparison'
    _description = "Tithe Comparison"

    month = fields.Selection([('january', 'January'),
    						  ('february', 'February'),
    						  ('march', 'March'),
    						  ('april', 'April'),
    						  ('may', 'May'),
    						  ('june', 'June'),
    						  ('july', 'July'),
    						  ('august', 'August'),
    						  ('september', 'September'),
    						  ('october', 'October'),
    						  ('november', 'November'),
    						  ('december', 'December')])
    prev_year = fields.Float('Last Year')
    current_year = fields.Float('Current Year')
    difference = fields.Float('Difference', compute="_get_difference")
    difference_percentage = fields.Float('Difference(%)', compute="_get_diff_perrcentage")
    family_id = fields.Many2one('res.partner', 'Family')

    def _get_difference(self):
    	for rec in self:
    		rec.difference = rec.current_year - rec.prev_year

    def _get_diff_perrcentage(self):
    	for rec in self:
    		diff = rec.current_year - rec.prev_year
    		if rec.prev_year != 0.0:
    			rec.difference_percentage = (diff / rec.prev_year) * 100
    		else:
    			rec.difference_percentage = 0