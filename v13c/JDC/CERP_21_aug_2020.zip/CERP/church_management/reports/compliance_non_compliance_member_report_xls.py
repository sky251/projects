from odoo import models
import io

class ComplianceNonComplianceMemberReportXls(models.AbstractModel):
    _name = 'report.church_management.report_comp_noncomp_members_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format(
            {'align': 'center', 'valign': 'vcenter', 'bold': True, 'size': 16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format(
            {'align': 'center', 'bold': True, 'size': 12})
        worksheet = workbook.add_worksheet('Compliance/Non Compliance Member')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 20)
        worksheet.set_column('E:E', 20)
        worksheet.merge_range('A1:E2', "%s Member Report" %(obj.report_type), heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'From Date:', cell_text_format)
        worksheet.write(
            row, column+1, (obj.date_from).strftime('%d/%m/%Y'), f_format)
        worksheet.write(row+1, column, 'To Date:', cell_text_format)
        worksheet.write(row+1, column+1,
                        (obj.date_to).strftime('%d/%m/%Y'), f_format)
        row += 3
        worksheet.write(row, column, 'Family Name', cell_text_format)
        worksheet.write(row, column+1, 'Family ID', cell_text_format)
        worksheet.write(row, column+2, 'Member', cell_text_format)
        worksheet.write(row, column+3, 'Background Checks', cell_text_format)
        worksheet.write(row, column+4, 'Virtus Certification', cell_text_format)
        row += 1
        member_data = obj.get_report_xls()
        for record in member_data['data']['member']:
            row += 1
            if record['family']:
                worksheet.write(row, column, record['family'], f_format)
            else:
                worksheet.write(row, column, '', f_format)
            if record['family_code']:
                worksheet.write(row, column+1, record['family_code'], f_format)
            else:
                worksheet.write(row, column+1, '', f_format)
            if record['member_name']:
                worksheet.write(row, column+2, record['member_name'], f_format)
            else:
                worksheet.write(row, column+2, '', f_format)
            if record['background_checks']:
                worksheet.write(row, column+3, 'True', f_format)
            else:
                worksheet.write(row, column+3, 'False', f_format)
            if record['virtus_certification']:
                worksheet.write(row, column+4, 'True', f_format)
            else:
                worksheet.write(row, column+4, 'False', f_format)
            