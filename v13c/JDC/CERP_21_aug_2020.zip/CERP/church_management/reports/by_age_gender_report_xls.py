from odoo import models
import io

class ByAgeGenderReportXls(models.AbstractModel):
    _name = 'report.church_management.report_by_age_gender_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format(
            {'align': 'center', 'valign': 'vcenter', 'bold': True, 'size': 16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format(
            {'align': 'center', 'bold': True, 'size': 12})
        worksheet = workbook.add_worksheet('By Age and Gender')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 20)
        worksheet.set_column('E:E', 20)
        worksheet.merge_range('A1:E2', "By Age Group and Gender Report", heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Age From:', cell_text_format)
        worksheet.write(
            row, column+1, (obj.age_from), f_format)
        worksheet.write(row+1, column, 'Age To:', cell_text_format)
        worksheet.write(row+1, column+1,
                        (obj.age_to), f_format)
        worksheet.write(row+2, column, 'Gender:', cell_text_format)
        worksheet.write(row+2, column+1,
                        (obj.gender), f_format)
        row += 4
        worksheet.write(row, column, 'Member Name', cell_text_format)
        worksheet.write(row, column+1, 'Member ID', cell_text_format)
        worksheet.write(row, column+2, 'Family', cell_text_format)
        worksheet.write(row, column+3, 'Date of Birth', cell_text_format)
        worksheet.write(row, column+4, 'Age', cell_text_format)
        row += 1
        member_data = obj.get_report_xls()
        for record in member_data['data']['member']:
            row += 1
            if record['member_name']:
                worksheet.write(row, column, record['member_name'], f_format)
            else:
                worksheet.write(row, column, '', f_format)
            if record['member_code']:
                worksheet.write(row, column+1, record['member_code'], f_format)
            else:
                worksheet.write(row, column+1, '', f_format)
            if record['family']:
                worksheet.write(row, column+2, record['family'], f_format)
            else:
                worksheet.write(row, column+2, '', f_format)
            if record['date_of_birth']:
                worksheet.write(row, column+3, record['date_of_birth'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+3, '', f_format)
            if record['age']:
                worksheet.write(row, column+4, record['age'], f_format)
            else:
                worksheet.write(row, column+4, '', f_format)
