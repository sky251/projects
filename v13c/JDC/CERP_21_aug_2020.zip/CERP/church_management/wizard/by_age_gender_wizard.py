from odoo import models, fields, api, _
from datetime import datetime, date, time, timedelta
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError, ValidationError, Warning


class ByAgeGenderWizard(models.TransientModel):
    _name = "by.age.gender.wizard"
    _description = "By Age and Gender Wizard"

    age_from = fields.Integer(string='Age From', copy=False)
    age_to = fields.Integer(string='Age To', copy=False)
    gender = fields.Selection(
        [('male', 'Male'), ('female', 'Female'), ('other', 'Other')], copy=False)

    def print_by_age_gender(self):
        age_gender_list = []
        data = {
            'form': self.read()[0]
        }
        if (self.gender == 'male'):
            age_gender_data = self.env['res.partner'].search([('age', '>=', self.age_from), (
                'age', '<=', self.age_to), ('gender', '=', 'male')])
            if age_gender_data:
                for records in age_gender_data:
                    vals = {
                        'member_name': records.name,
                        'member_code': records.member_ref,
                        'family': records.parent_id.name,
                        'date_of_birth': records.date_of_birth,
                        'age': records.age,
                    }
                    if vals:
                        age_gender_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.gender == 'female'):
            age_gender_data = self.env['res.partner'].search([('age', '>=', self.age_from), (
                'age', '<=', self.age_to), ('gender', '=', 'female')])
            if age_gender_data:
                for records in age_gender_data:
                    vals = {
                        'member_name': records.name,
                        'member_code': records.member_ref,
                        'family': records.parent_id.name,
                        'date_of_birth': records.date_of_birth,
                        'age': records.age,
                    }
                    if vals:
                        age_gender_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        else:
            age_gender_data = self.env['res.partner'].search([('age', '>=', self.age_from), (
                'age', '<=', self.age_to), ('gender', '=', 'other')])
            if age_gender_data:
                for records in age_gender_data:
                    vals = {
                        'member_name': records.name,
                        'member_code': records.member_ref,
                        'family': records.parent_id.name,
                        'date_of_birth': records.date_of_birth,
                        'age': records.age,
                    }
                    if vals:
                        age_gender_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        if age_gender_list:
            data['member'] = age_gender_list
            return self.env.ref('church_management.action_report_by_age_gender').with_context(landscape=True).report_action(self, data=data)

    def get_report_xls(self):
        age_gender_list = []
        data = {}
        if (self.gender == 'male'):
            age_gender_data = self.env['res.partner'].search([('age', '>=', self.age_from), (
                'age', '<=', self.age_to), ('gender', '=', 'male')])
            if age_gender_data:
                for records in age_gender_data:
                    vals = {
                        'member_name': records.name,
                        'member_code': records.member_ref,
                        'family': records.parent_id.name,
                        'date_of_birth': records.date_of_birth,
                        'age': records.age,
                    }
                    if vals:
                        age_gender_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.gender == 'female'):
            age_gender_data = self.env['res.partner'].search([('age', '>=', self.age_from), (
                'age', '<=', self.age_to), ('gender', '=', 'female')])
            if age_gender_data:
                for records in age_gender_data:
                    vals = {
                        'member_name': records.name,
                        'member_code': records.member_ref,
                        'family': records.parent_id.name,
                        'date_of_birth': records.date_of_birth,
                        'age': records.age,
                    }
                    if vals:
                        age_gender_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        else:
            age_gender_data = self.env['res.partner'].search([('age', '>=', self.age_from), (
                'age', '<=', self.age_to), ('gender', '=', 'other')])
            if age_gender_data:
                for records in age_gender_data:
                    vals = {
                        'member_name': records.name,
                        'member_code': records.member_ref,
                        'family': records.parent_id.name,
                        'date_of_birth': records.date_of_birth,
                        'age': records.age,
                    }
                    if vals:
                        age_gender_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        if age_gender_list:
            data['member'] = age_gender_list
            return self.env.ref('church_management.action_report_by_age_gender_xls').with_context(landscape=True).report_action(self, data=data)
