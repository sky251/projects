from odoo import models, fields, api, _
from datetime import datetime, date, time, timedelta
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError


class MinistryByEventWizard(models.TransientModel):
    _name = "ministry.by.event.wizard"
    _description = "By Event Wizard"

    event_id = fields.Many2one('calendar.event', copy=False, default=False)

    def print_by_event(self):
        ministry_details = []
        data = {
            'form': self.read()[0]
        }
        ministry_detail_ids = self.env['minister.details'].search(
            [('event_id', '=', self.event_id.id)])
        # ministry_details_ids = self.env['minister.details'].search([('event_ids', 'in', self.event_id.id)])
        # for detail in ministry_details_ids:
        #     print("detaisl::::::::::::::::::",detail)

        # print("ministry detail ids:FFFFFFFFFFFFFFFFFFFff",ministry_detail_ids)
        if ministry_detail_ids:
            for detail in ministry_detail_ids:
                vals = {}
                if detail.member_id:
                    vals.update({'member_id': detail.member_id.name})
                else:
                    vals.update({'member_id': ''})
                if detail.family_id:
                    vals.update({'family_id': detail.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if detail.virtus_certification:
                    vals.update(
                        {'virtus_certification': detail.virtus_certification})
                else:
                    vals.update({'virtus_certification': 'False'})
                if detail.event_id:
                    vals.update({'event_id': detail.event_id.name})
                else:
                    vals.update({'event_id': ''})
                if detail.background_check:
                    vals.update({'background_check': detail.background_check})
                else:
                    vals.update({'background_check': 'False'})
                if detail.group_ministry_id:
                    vals.update({'ministry': detail.group_ministry_id.name})
                else:
                    vals.update({'ministry': ''})
                if detail.by_group_id:
                    vals.update(
                        {'schedulled_group_id': detail.by_group_id.name})
                else:
                    vals.update({'schedulled_group_id': ''})

                if vals:
                    ministry_details.append(vals)
            data['ministry'] = ministry_details
            return self.env.ref('ministry_management.action_report_by_event').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        ministry_details = []
        data = {}
        ministry_detail_ids = self.env['minister.details'].search(
            [('event_id', '=', self.event_id.id)])
        if ministry_detail_ids:
            for detail in ministry_detail_ids:
                vals = {}
                if detail.member_id:
                    vals.update({'member_id': detail.member_id.name})
                else:
                    vals.update({'member_id': ''})
                if detail.family_id:
                    vals.update({'family_id': detail.family_id.name})
                else:
                    vals.update({'family_id': ''})
                if detail.virtus_certification:
                    vals.update({'virtus_certification': 'True'})
                else:
                    vals.update({'virtus_certification': 'False'})
                if detail.background_check:
                    vals.update({'background_check': 'True'})
                else:
                    vals.update({'background_check': 'False'})
                if detail.group_ministry_id:
                    vals.update({'ministry': detail.group_ministry_id.name})
                else:
                    vals.update({'ministry': ''})
                if detail.by_group_id:
                    vals.update(
                        {'schedulled_group_id': detail.by_group_id.name})
                else:
                    vals.update({'schedulled_group_id': ''})

                if vals:
                    ministry_details.append(vals)
            data['ministry'] = ministry_details
            return self.env.ref('ministry_management.action_report_by_event_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

