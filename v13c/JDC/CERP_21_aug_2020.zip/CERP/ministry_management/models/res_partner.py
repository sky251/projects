# -*- coding: utf-8 -*-
from odoo import fields, models, api
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT,DEFAULT_SERVER_DATE_FORMAT
from datetime import datetime


class Partner(models.Model):
    _inherit = 'res.partner'

    ministry_ids = fields.One2many('member.minister.details', 'member_id', string="Ministry", copy=False)


    def get_ministries(self):
        for rec in self:
            member_ministries = []
            minister_id = self.env['minister.minister'].search([('member_id', '=', rec.id)])
            if minister_id:
                for ministry in minister_id.ministry_ids:
                    ministry_available_id = self.env['member.minister.details'].search([('ministry_id', '=', ministry.id), ('member_id', '=', rec.id)])
                    if not ministry_available_id:
                        member_minister_id = self.env['member.minister.details'].create({'ministry_id': ministry.id, 'ministry_type_id': ministry.ministry_type_id.id, 'member_id': rec.id})
                        member_ministries.append(member_minister_id.id)
                    else:
                        member_ministries.append(ministry_available_id.id)
                rec.ministry_ids = member_ministries
            else:
                rec.ministry_ids = False



class MemberMinisterDetails(models.Model):
    _name = 'member.minister.details'

    ministry_id = fields.Many2one('ministry.ministry', 'Ministry', copy=False)
    ministry_type_id = fields.Many2one('ministry.type', 'Ministry Type', copy=False, related="ministry_id.ministry_type_id")
    member_id = fields.Many2one('res.partner', 'Member', copy=False)
    start_date = fields.Date('Start Date', copy=False, default=False)
    renewal_date = fields.Date('Renewal Date', copy=False, default=False)
    retired_date = fields.Date('Retired Date', copy=False, default=False)
    ministry_status = fields.Char('Ministry Status')

    @api.onchange('ministry_id')
    def onchange_ministry_id(self):
        if self.ministry_id:
            self.ministry_type_id = self.ministry_id.ministry_type_id.id