# -*- coding: utf-8 -*-
from odoo import fields, models

class Religion(models.Model):
    _name = 'religion.religion'
    _rec_name = 'code'

    name = fields.Char('Religion')
    code = fields.Char('Code')