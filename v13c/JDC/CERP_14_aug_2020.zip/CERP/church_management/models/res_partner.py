# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError,UserError
from odoo.tools.misc import DEFAULT_SERVER_DATE_FORMAT
import datetime
from dateutil.relativedelta import relativedelta
from datetime import timedelta, date


class Partner(models.Model):
    _inherit = 'res.partner'

    def _get_family_memebers(self):
        """Get family members """
        for partner in self:
            if partner.parent_id:
                contact_ids = self.search([('parent_id', '=', partner.parent_id.id)])
            else:
                contact_ids = self.search([('parent_id', '=', partner.id)])
            if contact_ids:
                contacts = contact_ids.ids
                if partner.id in contact_ids.ids:
                    contacts.remove(partner.id)
                partner.family_members = contacts
            else:
                partner.family_members = False

    relationship_type = fields.Selection([('aunt', 'Aunt'),
                            ('brother', 'Brother'),
                            ('child', 'Child'),
                            ('father', 'Father'),
                            ('grandparent', 'Grandparent'),
                            ('mother', 'Mother'),
                            ('mother-in-law', 'Mother-in-law'),
                            ('significant_other', 'Significant Other'),
                            ('sister', 'Sister'),
                            ('uncle', 'Uncle'),
                            ('friend', 'Friend')], copy=False)
    relationship_type_code = fields.Char(related='relationship_type_id.code', string="Type")
    relationship_type_id = fields.Many2one('relation.type', copy=False, default=False)
    custodial = fields.Boolean('Custodial', copy=False)
    age = fields.Char(string="Age", compute='_compute_age', store=True)
    custodial_contact_id = fields.Many2one('res.partner', 'Custodial Contact', copy=False)
    primary_contact_id = fields.Many2one('res.partner', 'Primary Contact', copy=False)
    unlisted = fields.Boolean('Unlisted', copy=False)
    iep = fields.Boolean('IEP', copy=False)
    iep_certificate = fields.Binary('IEP Certificate', copy=False)
    church_of_marriage = fields.Many2one('place.parish', 'Church Of Marriage', copy=False)
    town = fields.Char('Town', copy=False)
    date_of_marriage = fields.Date('Date Of Marriage', copy=False)
    gender = fields.Selection([('male','Male'), ('female','Female'), ('other', 'Other')], copy=False)
    religion_id = fields.Many2one('religion.religion', 'Religion', copy=False)
    date_of_birth = fields.Date('Date of Birth', copy=False)
    family_members = fields.Many2many('res.partner', 'partner_partner_rel', string='Family Members', compute="_get_family_memebers", copy=False)
    partner_id = fields.Many2one('res.partner', 'Partner', copy=False)
    virtus_certification = fields.Boolean('Certification', copy=False)
    virtus_certification_date = fields.Date('Certification Date', copy=False)
    virtus_certificate = fields.Binary('Certificate')
    company_type = fields.Selection(string='Company Type',
        selection=[('person', 'Individual'), ('company', 'Family')],
        compute='_compute_company_type', inverse='_write_company_type', copy=False)
    # sacrament_ids = fields.One2many('sacrament.sacrament','partner_id', string="Sacraments", copy=False)
    background_checks = fields.Boolean('Background Checks', copy=False)
    background_check_validity_date = fields.Date('Validity Date', copy=False)
    phone = fields.Char('Telephone', copy=False)
    mobile = fields.Char('Cellphone', copy=False)
    annual_gift = fields.Float('Annual Gift')
    ref = fields.Char('Family ID', copy=False)
    member_ref = fields.Char('Member ID', copy=False)
    envelope_ref = fields.Char('Envelope No.', copy=False)
    is_church = fields.Boolean('Church', copy=False)
    communication_mode = fields.Selection([('text', 'Text'), ('email', 'E-mail'), ('regular', 'Regular')], copy=False, default="regular")
    faith_formation = fields.Boolean('Faith Formation?', copy=False)
    term_id = fields.Many2one('term.term', 'Terms', copy=False)
    level_id = fields.Many2one('level.level', 'Levels', copy=False)
    class_id = fields.Many2one('class.class', 'Class', copy=False)
    session_choice_1 = fields.Many2one('session.session', 'Session Choice 1', copy=False)
    session_choice_2 = fields.Many2one('session.session', 'Session Choice 2', copy=False)
    donation_count = fields.Float(compute='_total_donation', string="Donations", copy=False)
    special_considerations = fields.Text('Special Considerations', copy=False)
    allergies = fields.Text('Allergies', copy=False)
    media_release = fields.Boolean('Media Release', copy=False)
    faith_formation_ids = fields.One2many('faith.formation', 'partner_id', 'Faith Formation', copy=False)
    preferred_phone = fields.Char('Class Phone', copy=False)
    other_phone = fields.Char('Emergency Contact', copy=False)
    inactive = fields.Boolean('Inactive', copy=False)
    status = fields.Selection([('active', 'Active'), ('inactive', 'Inactive'), ('archived', 'Archived')], default='active', compute="get_status", copy=False)
    tithe_percentage = fields.Integer('Tithe(%)', compute="_get_tithe_percentage", copy=False)
    method = fields.Selection([('print', 'Print'), ('online', 'Online')], copy=False)
    monthly = fields.Boolean('Monthly', copy=False)
    skills = fields.Many2one('skill.skill', string="Skills", copy=False)
    language = fields.Many2one('language.language', 'Language', copy=False)
    death_date = fields.Date('Death Date', copy=False, default=datetime.datetime.today())
    death = fields.Boolean('Death', copy=False, default=False)
    deacon = fields.Boolean('Deacon', copy=False, default=False)
    priest =  fields.Boolean('Priest', copy=False, default=False)
    coordinator =  fields.Boolean('Coordinator', copy=False, default=False)
    family =  fields.Boolean('Family', copy=False, default=True)
    occupation = fields.Many2one('occupation.occupation', 'Occupation', copy=False)
    marital_status = fields.Selection([('1', 'Single'),
                                       ('2', 'Married'), 
                                       ('3', 'Widowed'),
                                       ('4', 'Divorced'), 
                                       ('5', 'Separated'),
                                       ('6', 'Common/Living Together'),
                                       ('7', 'Deceased')], copy=False, default=False)
    nickname = fields.Char('Nickname')
    nickname_preferred = fields.Boolean('Nickname Preferred')
    maiden_name = fields.Char('Maiden Name')

    @api.depends('date_of_birth')
    def _compute_age(self):
        """ This method will compute customer age based on date of birth"""
        for record in self:
            if record.date_of_birth:
                years = relativedelta(date.today(), record.date_of_birth).years
                record.age = str(int(years))

    def _get_tithe_percentage(self):
        for rec in self:
            donation_ids = self.env['donation.donation'].search([('family_id', '=' ,self.id)])
            amount = 0.0
            today = datetime.datetime.today()
            for donation in donation_ids:
                for batch in donation.mapped('batch_id'):
                    if batch.state == 'validate' and batch.validate_date and batch.validate_date >= datetime.date(today.year, 1, 1) and batch.validate_date <= datetime.date(today.year, 12, 31):
                        amount += donation.amount
            donation_count = amount
            if not donation_ids:
                donation_count = 0.0
            if donation_count > 0.0 and rec.annual_gift > 0.0:
                rec.tithe_percentage = (donation_count * 100) / rec.annual_gift
            else:
                rec.tithe_percentage = False

    def get_status(self):
        for rec in self:
            status_vals = {}
            if rec.company_type == 'company':
                if rec.active:
                    status_vals['status'] = 'active'
                    status_vals['active'] = True
                    if rec.inactive:
                        status_vals['status'] = 'inactive'
                        status_vals['inactive'] = True
                if not rec.active:
                    status_vals['status'] = 'archived'
                    status_vals['active'] = False
                for child in rec.mapped('family_members'):
                    child.write(status_vals)
                member_ids = self.search([('parent_id', '=', rec.id), ('active', '=', False)])
                for member in member_ids:
                    member.write(status_vals)
                rec.status = 'status' in status_vals and status_vals['status']
            elif rec.company_type == 'person' and rec.parent_id:
                if rec.parent_id.active and not rec.active:
                    status_vals['status'] = 'active'
                    status_vals['active'] = True
                    if rec.parent_id.inactive:
                        status_vals['status'] = 'inactive'
                        status_vals['inactive'] = True
                if not rec.parent_id.active:
                    status_vals['status'] = 'archived'
                    status_vals['active'] = False
                rec.status = 'status' in status_vals and status_vals['status']
            else:
                rec.status = False
    

    def _total_donation(self):
        donation_ids = self.env['donation.donation'].search([('family_id', '=' ,self.id)])
        amount = 0.0
        today = datetime.datetime.today()
        for donation in donation_ids:
            for batch in donation.mapped('batch_id'):
                if batch.state == 'validate' and batch.validate_date and batch.validate_date >= datetime.date(today.year, 1, 1) and batch.validate_date <= datetime.date(today.year, 12, 31):
                    amount += donation.amount
        self.donation_count = amount
        if not donation_ids:
            self.donation_count = 0.0


    def _get_name(self):
        """ Utility method to allow name_get to be overrided without re-browse the partner """
        partner = self
        name = partner.name or ''
        if partner.company_name or partner.parent_id:
            if not name and partner.type in ['invoice', 'delivery', 'other']:
                name = dict(self.fields_get(['type'])['type']['selection'])[partner.type]
            if not partner.is_company:
                name = self._get_contact_name(partner, name)
        if self._context.get('show_address_only'):
            name = partner._display_address(without_company=True)
        if self._context.get('show_address'):
            name = name + "\n" + partner._display_address(without_company=True)
        name = name.replace('\n\n', '\n')
        name = name.replace('\n\n', '\n')
        if self._context.get('address_inline'):
            name = name.replace('\n', ', ')
        if self._context.get('show_email') and partner.email:
            name = "%s <%s>" % (name, partner.email)
        if self._context.get('html_format'):
            name = name.replace('\n', '<br/>')
        if self._context.get('show_vat') and partner.vat:
            name = "%s ‒ %s" % (name, partner.vat)
        if self._context.get('registration'):
            if partner.ref:
                name =  "[%s] ‒ %s" % (partner.ref, name)
            else:
                name = name
        return name

    @api.model_create_multi
    def create(self, vals_list):
        """Create sequence for family"""
        status_vals = {}
        count = 0
        for vals in vals_list:
            if self._context.get('faith_formation_registration') and 'company_type' in vals and vals['company_type'] == 'person':
                raise UserError(_('You can create only family.'))
            if self._context.get('new_registration') and 'company_type' in vals and vals['company_type'] == 'company':
                raise UserError(_('You can not create family.'))
            if 'company_type' in vals and vals['company_type'] == 'company':
                vals['ref'] = '%s000' %(self.env['ir.sequence'].next_by_code('res.partner.family') or ('New'))
            # if 'company_type' in vals and vals['company_type'] == 'person':
            #     if 'parent_id' in vals:
            #         parent_id = self.browse(vals['parent_id'])
            #         if parent_id:
            #             child_ids = self.search([('parent_id', '=', parent_id.id)])
            #             count = 000 + len(child_ids) + 1
            #             vals['member_ref'] = '%s%s' %(parent_id.ref[:-3], str(count).zfill(3))
            #         else:
            #             vals['member_ref'] = str(count).zfill(3)
            #     else:
            #         vals['member_ref'] = count
            if 'envelope_ref' in vals and not vals['envelope_ref']:
                if 'company_type' in vals and vals['company_type'] == 'company':
                    vals['envelope_ref'] = 'ref' in vals and  vals['ref']
            if 'company_type' in vals and vals['company_type'] == 'company':
                inactive = 'inactive' in vals and vals['inactive']
                if inactive:
                    status = 'inactive'
                active = 'active' in vals and vals['active']
                if active:
                    status = 'active'
                    inactive = 'inactive' in vals and vals['inactive']
                    if inactive:
                        status = 'inactive'
                else:
                    status = 'archived'
                if status == 'active':
                    status_vals['active'] = True
                    status_vals['status'] = 'active'
                    vals['status'] = 'active'
                if status == 'archived':
                    status_vals['active'] = False
                    status_vals['status'] = 'archived'
                    vals['status'] = 'archived'
                if status == 'inactive':
                    status_vals['inactive'] = True
                    status_vals['active'] = True
                    status_vals['status'] = 'inactive'
                    vals['status'] = 'inactive'
        return super(Partner, self).create(vals_list)

    @api.onchange('parent_id')
    def _onchange_parent_id(self):
        """Set primary contact on members as same as family's  Primary contact"""
        if self.parent_id and self.parent_id.primary_contact_id:
            self.primary_contact_id = self.parent_id.primary_contact_id.id

    @api.onchange('is_church')
    def _onchange_is_church(self):
        """Add church tag If contact is as a church. """
        category_id = self.env.ref('church_management.res_partner_category_parish')
        if self.is_church:
            self.category_id =  [(4, category_id.id)]
        else:
            self.category_id = [(3, category_id.id)]

    def write(self, vals):
        """Set first member of family as a primary contact,sequence and active/inactive status for members."""
        status_vals = {}
        count = 0
        for rec in self:
            if vals:
                if rec.company_type == 'company' or 'company_type' in vals and vals['company_type'] == 'company':
                    inactive = 'inactive' in vals and vals['inactive']
                    if inactive:
                        status = 'inactive'
                    if not 'inactive' in vals:
                        if rec.inactive:
                            status = 'inactive'
                    active = 'active' in vals and vals['active']
                    if active:
                        status = 'active'
                        inactive = 'inactive' in vals and vals['inactive']
                        if inactive:
                            status = 'inactive'
                        if not 'inactive' in vals:
                            if rec.inactive:
                                status = 'inactive'
                    else:
                        status = 'archived'
                    if not 'active' in vals:
                        if rec.active:
                            status = 'active'
                            inactive = 'inactive' in vals and vals['inactive']
                            if inactive:
                                status = 'inactive'
                            if not 'inactive' in vals:
                                if rec.inactive:
                                    status = 'inactive'
                        else:
                            status = 'archived'
                    if status == 'active':
                        status_vals['active'] = True
                        status_vals['status'] = 'active'
                        vals['status'] = 'active'
                    if status == 'archived':
                        status_vals['active'] = False
                        status_vals['status'] = 'archived'
                        vals['status'] = 'archived'
                    if status == 'inactive':
                        status_vals['inactive'] = True
                        status_vals['active'] = True
                        status_vals['status'] = 'inactive'
                        vals['status'] = 'inactive'
                if self._context.get('faith_formation_registration') and 'company_type' in vals and vals['company_type'] == 'person':
                    raise UserError(_('You can create only family.'))
                if self._context.get('new_registration') and 'company_type' in vals and vals['company_type'] == 'company':
                    raise UserError(_('You can not create family.'))
                reference = 'ref' in vals and vals['ref'] or rec.ref
                company_type = vals and 'company_type' in vals and vals['company_type'] or rec.company_type
                member_ref = 'member_ref' in vals and vals['member_ref'] or rec.member_ref
                envelope_ref = 'envelope_ref' in vals and vals['envelope_ref'] or rec.envelope_ref
                if not reference and company_type == 'company':
                    vals['ref'] = '%s000' %(self.env['ir.sequence'].next_by_code('res.partner.family') or ('New'))
                if not member_ref and company_type == 'person':
                    parent_id = False
                    if 'parent_id' in vals and vals['parent_id']:
                        parent_id = self.browse(vals['parent_id'])
                    if 'parent_id' not in vals and rec.parent_id:
                        parent_id = rec.parent_id
                    # if parent_id:
                    #     child_ids = self.search([('parent_id', '=', parent_id.id)])
                    #     count = 000 + len(child_ids) + 1
                    #     if rec.partner_id.ref:
                    #         vals['member_ref'] = '%s%s' %(rec.parent_id.ref[:-3], str(count).zfill(3))
                    # else:
                    #     vals['member_ref'] = str(count).zfill(3)
                if not envelope_ref:
                    if company_type == 'company':
                        vals['envelope_ref'] = reference or 'ref' in vals and vals['ref']
                if rec.parent_id and not rec.parent_id.primary_contact_id and rec.parent_id.child_ids and not 'primary_contact_id' in vals:
                    vals['primary_contact_id'] = rec.parent_id.child_ids[0].id
                    rec.parent_id.write({'primary_contact_id': rec.parent_id.child_ids[0].id})
        return super(Partner, self).write(vals)

    def get_donation(self):
        self.ensure_one()
        if self.donation_count > 0:
            action = self.env.ref('church_management.action_view_tithe_wizard_view').read()[0]
            return action

    @api.model
    def get_inactive_members(self):
        donations = []
        invoices = []
        no_of_days = inactive_days = self.env['ir.config_parameter'].sudo().get_param('inactive_days')
        if no_of_days:
            today_date = datetime.datetime.today()
            past_date = datetime.datetime.today() - timedelta(days = int(no_of_days))
            partners = self.search([])
            for rec in partners:
                donation_ids = self.env['donation.donation'].search([('family_id', '=', rec.id)])
                for donation in donation_ids:
                    if not donation.create_date <= datetime.datetime.today() and not donation.create_date >= past_date:
                        donations.append(donation)
                invoice_ids = self.env['account.move'].search([('partner_id', '=', rec.id)])
                for invoice in invoice_ids:
                    if not invoice.create_date <= datetime.datetime.today() and not invoice.create_date >= past_date:
                        invoices.append(invoice)
                if len(invoices) >= 1 and len(donations) >= 1:
                    if int(no_of_days) >= 365:
                        rec.write({'archive': True, 'status':'archived'})
                    else:
                        if not rec.active:
                            rec.write({'inactive': True, 'status': 'inactive'})

