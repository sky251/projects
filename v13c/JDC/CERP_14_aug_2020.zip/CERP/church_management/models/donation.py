# -*- coding: utf-8 -*-
from odoo import fields, models, api, _
from odoo.exceptions import ValidationError
import datetime


class Donation(models.Model):
    _name = 'donation.donation'
    _description = 'Donation'
    _rec_name = "envelope_no"

    def set_amount(self):
        """Set default amount"""
        amount = 0.0
        if self._context.get('default_batch_amount'):
            amount = self._context.get('default_batch_amount')
        return amount

    def set_donation_product(self):
        """Set donation product by default"""
        if self.batch_id and self.batch_id.envelope_id:
            return self.batch_id.envelope_id.product_id.id

    @api.constrains('amount')
    def amount_constarains(self):
        if self.amount <= 0.0:
            raise ValidationError(_("Enter Amount."))

    product_id = fields.Many2one('product.product', 'Product', related="batch_id.envelope_id.product_id")
    type = fields.Selection([('cash', 'Cash'),
                             ('cheque', 'Cheque')], 'Donation Method')
    amount = fields.Float('Amount', default=set_amount)
    cheque_number = fields. Char('Cheque No.')
    envelope_no = fields.Char('Envelope No.')
    family_id = fields.Many2one('res.partner', 'Family ID')
    batch_id = fields.Many2one('envelope.batch', 'Batch')
    validate_date = fields.Date(related='batch_id.validate_date', string="Validate Date", readonly=True)
    donation_date = fields.Date('Donation Date', default=datetime.datetime.today())
    envelope_id = fields.Many2one('envelope.type', string="Envelope Type", copy=False, default=False)
    envelope_type = fields.Selection([('diocese', 'Diocese'), ('parish', 'Parish')], copy=False, string="Recipient")
    running_balance = fields.Float('Running Balance', compute="get_running_balance")

    def get_running_balance(self):
        for rec in self:
            today = datetime.datetime.today()
            amount = 0
            donation_ids = ''
            if not self._context.get('tithe_member'):
                if self._context.get('current_year'):
                    donation_ids = self.search([('family_id', '=' ,rec.family_id.id), ('id', '<=', rec.id),
                                                ('donation_date', '>=', datetime.date(today.year, 1, 1)),
                                                ('donation_date', '<=', datetime.date(today.year, 12, 31))])
                else:
                    if rec._origin:
                        donation_ids = self.search([('family_id', '=' ,rec.family_id.id), ('id', '<=',  rec._origin.id)])
                    else:
                        donation_ids = self.search([('family_id', '=' ,rec.family_id.id), ('id', '<=',  rec.id)])
                for donation in donation_ids:
                    if rec.family_id == donation.family_id:
                        amount += donation.amount
                        rec.running_balance = amount
            if self._context.get('tithe_member'):
                if self._context.get('current_year'):
                    donation_ids = self.search([('family_id', '=' ,rec.family_id.id), ('id', '<=', rec.id),
                                                ('donation_date', '>=', datetime.date(today.year, 1, 1)),
                                                ('donation_date', '<=', datetime.date(today.year, 12, 31)),
                                                ('batch_id.state', '=', 'validate')])
                else:
                    donation_ids = self.search([('family_id', '=' ,rec.family_id.id), ('id', '<=', rec.id), ('batch_id.state', '=', 'validate')])
                if not donation_ids:
                    donation_ids = self.search([('family_id', '=' ,rec.family_id.id), ('id', '<=', rec.id), ('batch_id.state', '=', 'validate')])
                for donation in donation_ids:
                    if rec.family_id == donation.family_id:
                        amount += donation.amount
                        rec.running_balance = amount

    @api.onchange('envelope_no')
    def _onchange_envelope_no(self):
        envelope_no = []
        if self.envelope_no:
            partner_id = self.env['res.partner'].search([('envelope_ref', '=', self.envelope_no), ('is_company', '=', True),], limit=1)
            if partner_id:
                self.family_id = partner_id.id
                for detail in self.batch_id.envelope_detail_ids[1:]:
                    if detail.envelope_no == self.envelope_no and detail != self.batch_id.envelope_detail_ids[-1]:
                        return {'warning':
                                {
                                    'title': _("Warning"),
                                    'message': 'Envelope is already scanned.Do you still want to continue?'
                                }
                        }
                    envelope_no.append(detail.envelope_no)
            else:
                raise ValidationError(_("Invalid Envelope No."))
