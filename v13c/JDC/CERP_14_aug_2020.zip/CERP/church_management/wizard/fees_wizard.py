# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class FeesWizard(models.TransientModel):
    _name = "fees.wizard"
    _description = "Fees Details"

    report_type = fields.Selection(
        [('Paid', 'Paid Report'), ('Unpaid', 'Unpaid Report')], string="Report Type", copy=False)

    def print_fees_details(self):
        fees_list = []
        data = {
            'form': self.read()[0]
        }
        if (self.report_type == 'Paid'):
            fees_data = self.env['member.details'].search(
                [('registration_id.paid_in_full', '=', True)])
            if fees_data:
                for details in fees_data:
                    vals = {
                        'family': details.family_id.name,
                        'family_id': details.family_id.ref,
                        'child_name': details.registration_partner_id.name,
                        'term_id': details.term_id.name,
                        'level': details.level_id.name,
                        'session': details.session_choice_1.name,
                        'registration_date': details.registration_id.registration_date
                    }
                    if vals:
                        fees_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif (self.report_type == 'Unpaid'):
            fees_data = self.env['member.details'].search(
                [('registration_id.paid_in_full', '=', False)])
            if fees_data:
                for details in fees_data:
                    vals1 = {
                        'family': details.family_id.name,
                        'family_id': details.family_id.ref,
                        'child_name': details.registration_partner_id.name,
                        'term_id': details.term_id.name,
                        'level': details.level_id.name,
                        'session': details.session_choice_1.name,
                        'registration_date': details.registration_id.registration_date
                    }
                    if vals1:
                        fees_list.append(vals1)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        if fees_list:
            data['member'] = fees_list
            return self.env.ref('church_management.action_report_fees_details').with_context(landscape=True).report_action(self, data=data)

    def get_report_xls(self):
        fees_list = []
        data = {}
        if (self.report_type == 'Paid'):
            fees_data = self.env['member.details'].search(
                [('registration_id.paid_in_full', '=', True)])
            if fees_data:
                for details in fees_data:
                    vals = {
                        'family': details.family_id.name,
                        'family_id': details.family_id.ref,
                        'child_name': details.registration_partner_id.name,
                        'term_id': details.term_id.name,
                        'level': details.level_id.name,
                        'session': details.session_choice_1.name,
                        'registration_date': details.registration_id.registration_date
                    }
                    if vals:
                        fees_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif (self.report_type == 'Unpaid'):
            fees_data = self.env['member.details'].search(
                [('registration_id.paid_in_full', '=', False)])
            if fees_data:
                for details in fees_data:
                    vals1 = {
                        'family': details.family_id.name,
                        'family_id': details.family_id.ref,
                        'child_name': details.registration_partner_id.name,
                        'term_id': details.term_id.name,
                        'level': details.level_id.name,
                        'session': details.session_choice_1.name,
                        'registration_date': details.registration_id.registration_date
                    }
                    if vals1:
                        fees_list.append(vals1)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        if fees_list:
            data['member'] = fees_list
            return self.env.ref('church_management.action_report_fees_details_xls').with_context(landscape=True).report_action(self, data=data)
