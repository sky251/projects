# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class ComplianceNonComplianceMemberWizard(models.TransientModel):
    _name = "compliance.non.compliance.member.wizard"
    _description = "Compliance/Non Compliance Member Details"

    date_from = fields.Date('From Date')
    date_to = fields.Date('To Date')
    report_type = fields.Selection([('Compliance', 'Compliance Report'),
                                    ('Non-Compliance', 'Non Compliance Report')], string="Report Type", copy=False)

    def print_compliance_noncompliance_members(self):
        member_list = []
        data = {
            'form': self.read()[0]
        }
        if (self.report_type == 'Compliance'):
            member_ids = self.env['res.partner'].search([('create_date', '>=', self.date_from), ('create_date', '<=', self.date_to), (
                'background_checks', '=', True), ('virtus_certification', '=', True), ('is_company', '=', False)])
            if member_ids:
                for details in member_ids:
                    vals = {
                        'family': details.parent_id.name,
                        'family_code': details.parent_id.ref,
                        'member_name': details.name,
                    }
                    if details.virtus_certification:
                        vals.update({'virtus_certification': details.virtus_certification})
                    else:
                        vals.update({'virtus_certification': 'False'})
                    if details.background_checks:
                        vals.update({'background_checks': details.background_checks})
                    else:
                        vals.update({'background_checks': 'False'})
                    if vals:
                        member_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))

        elif(self.report_type == 'Non-Compliance'):
            member_ids = self.env['res.partner'].search([('create_date', '>=', self.date_from), ('create_date', '<=', self.date_to), (
                'background_checks', '=', False), ('virtus_certification', '=', False), ('is_company', '=', False)])
            if member_ids:
                for details in member_ids:
                    vals = {
                        'family': details.parent_id.name,
                        'family_code': details.parent_id.ref,
                        'member_name': details.name,
                    }
                    if details.virtus_certification:
                        vals.update({'virtus_certification': details.virtus_certification})
                    else:
                        vals.update({'virtus_certification': 'False'})
                    if details.background_checks:
                        vals.update({'background_checks': details.background_checks})
                    else:
                        vals.update({'background_checks': 'False'})
                    if vals:
                        member_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        if member_list:
            data['member'] = member_list
            return self.env.ref('church_management.action_report_compliance_non_compliance_member').with_context(landscape=True).report_action(self, data=data)

    def get_report_xls(self):
        member_list = []
        data = {}
        if (self.report_type == 'Compliance'):
            member_ids = self.env['res.partner'].search([('create_date', '>=', self.date_from), ('create_date', '<=', self.date_to), (
                'background_checks', '=', True), ('virtus_certification', '=', True), ('is_company', '=', False)])
            if member_ids:
                for details in member_ids:
                    vals = {
                        'family': details.parent_id.name,
                        'family_code': details.parent_id.ref,
                        'member_name': details.name,
                        'background_checks': details.background_checks,
                        'virtus_certification': details.virtus_certification,
                    }
                    if vals:
                        member_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        elif(self.report_type == 'Non-Compliance'):
            member_ids = self.env['res.partner'].search([('create_date', '>=', self.date_from), ('create_date', '<=', self.date_to), (
                'background_checks', '=', False), ('virtus_certification', '=', False), ('is_company', '=', False)])
            if member_ids:
                for details in member_ids:
                    vals = {
                        'family': details.parent_id.name,
                        'family_code': details.parent_id.ref,
                        'member_name': details.name,
                        'background_checks': details.background_checks,
                        'virtus_certification': details.virtus_certification,
                    }
                    if vals:
                        member_list.append(vals)
            else:
                raise UserError(
                    _('No contents to display in the report. Hence, this report cannot be printed.'))
        if member_list:
            data['member'] = member_list
            return self.env.ref('church_management.action_report_compliance_non_compliance_member_xls').with_context(landscape=True).report_action(self, data=data)
