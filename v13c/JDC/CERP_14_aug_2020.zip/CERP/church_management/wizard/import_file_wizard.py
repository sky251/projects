# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models, api, _
from odoo.exceptions import UserError, ValidationError
import xlrd
import base64
import csv
import os
from datetime import datetime
import json
import time
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
# import openpyxl


class ImportFileWizard(models.TransientModel):
    _name = "import.file.wizard"
    _description = "Import File"

    file = fields.Binary('Xlsx')
    filename = fields.Char('Filename')
    file_type = fields.Selection([('member', 'Member'),
                                  ('ministry', 'Ministry'),
                                  ('death_data', 'Funeral'),
                                  ('sacrament', 'Sacrament')], 'File Type')

    def import_file(self, start = False, end=False):
        startTime = time.time()
        timeout = startTime + 60*10
        if self.file_type == 'member':
            try:
                counter = 0
                for wizard in self:
                    book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                    sh = book.sheet_by_index(0)
                    batchCount = 1
                    for rownum in range(sh.nrows):
                        counter += 1
                        if counter > 1:
                            partner_id = self.env['res.partner'].search([('member_ref', '=', sh.row_values(rownum)[0])])
                            family_id = self.env['res.partner'].search([('ref', '=', sh.row_values(rownum)[1])], limit=1)
                            if not partner_id and family_id:
                                if sh.row_values(rownum)[10]:
                                    if sh.row_values(rownum)[10] == '1':
                                        gender = 'male'
                                    else:
                                        gender = 'female'
                                if sh.row_values(rownum)[17]:
                                    relationship_type_id = self.env['relation.type'].search(
                                        [('code', '=', str(sh.row_values(rownum)[17]).rstrip('0').rstrip('.'))])
                                if sh.row_values(rownum)[13]:
                                    father_id = self.env['res.partner'].search(
                                        [('name', '=', sh.row_values(rownum)[13])])
                                if sh.row_values(rownum)[28]:
                                    occupation_id = self.env['occupation.occupation'].search(
                                        [('code', '=', str(sh.row_values(rownum)[28]).rstrip('0').rstrip('.'))])
                                if sh.row_values(rownum)[29]:
                                    religion_id = self.env['religion.religion'].search(
                                        [('code', '=', str(sh.row_values(rownum)[29]).rstrip('0').rstrip('.'))])
                                if sh.row_values(rownum)[39]:
                                    address = sh.row_values(rownum)[39].split(',')
                                    if address:
                                        city = address[0]
                                        addr = address[1].split(' ')
                                        if addr:
                                            state = addr[0]
                                            state_id = self.env['res.country.state'].search([('code', '=', addr[0])])
                                            zip_code = addr[1]
                                partner_id = self.env['res.partner'].create({
                                    'member_ref': sh.row_values(rownum)[0],
                                    'ref': sh.row_values(rownum)[1],
                                    'name': 
                                        sh.row_values(rownum)[2] + sh.row_values(rownum)[3] + sh.row_values(rownum)[4] + sh.row_values(rownum)[5],
                                    'nickname': sh.row_values(rownum)[7],
                                    'nickname_preferred': sh.row_values(rownum)[8],
                                    'maiden_name': sh.row_values(rownum)[9],
                                    'gender': gender,
                                    'relationship_type_id': relationship_type_id and relationship_type_id.id,
                                    'marital_status': str(sh.row_values(rownum)[19]).rstrip('0').rstrip('.'),
                                    'phone': sh.row_values(rownum)[20],
                                    'unlisted': str(sh.row_values(rownum)[22]).rstrip('0').rstrip('.'),
                                    'mobile': sh.row_values(rownum)[23],
                                    'email': sh.row_values(rownum)[24],
                                    'occupation': occupation_id and occupation_id.id,
                                    'religion_id': religion_id and religion_id.id,
                                    'comment': sh.row_values(rownum)[32] + '\n' + sh.row_values(rownum)[33],
                                    'street': sh.row_values(rownum)[37],
                                    'city': city,
                                    'state_id': state_id and state_id.id,
                                    'zip': zip_code
                                })
                                if partner_id:
                                    if sh.row_values(rownum)[12]:
                                        partner_id.write(
                                            {'death_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[12], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                    if sh.row_values(rownum)[11]:
                                        partner_id.write(
                                            {'date_of_birth': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[11], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                    if sh.row_values(rownum)[30]:
                                        partner_id.write(
                                            {'write_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[30], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                # stop
            except Exception as e:
                raise ValidationError(_(e))
        if self.file_type == 'ministry':
            try:
                counter = 0
                for wizard in self:
                    book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                    sh = book.sheet_by_index(0)
                    batchCount = 1
                    for rownum in range(sh.nrows):
                        counter += 1
                        if counter > 1:
                            minister_id = ''
                            partner_id = self.env['res.partner'].search([('member_ref', '=', sh.row_values(rownum)[0])])
                            if partner_id:
                                ministry_id = self.env['ministry.ministry'].search([('code', '=', str(sh.row_values(rownum)[1]).rstrip('0').rstrip('.'))])
                                if ministry_id:
                                    member_minister_id = self.env['minister.minister'].search([('member_id', '=', partner_id.id)])
                                    if member_minister_id:
                                        if ministry_id.id not in member_minister_id.ministry_ids.ids:
                                            member_minister_id.write({'ministry_ids': [(4, ministry_id.id)]})
                                    else:
                                        self.env['minister.minister'].create({'member_id':partner_id.id, 
                                                                              'ministry_ids':[(6, 0, [ministry_id.id])]})
                                    minister_id = self.env['member.minister.details'].search([('ministry_id', '=', ministry_id.id),
                                                                                              ('member_id', '=', partner_id.id)])
                                    if sh.row_values(rownum)[2] == 2:
                                        status = 'Retired'
                                    if sh.row_values(rownum)[1] == 1:
                                        status = 'Active'
                                    if sh.row_values(rownum)[2] == 8:
                                        status = 'Pending'
                                    if not minister_id:
                                        minister_id = partner_id.ministry_ids.create({'member_id': partner_id.id,
                                                                                      'ministry_id': ministry_id.id,
                                                                                      'ministry_status': status,
                                                                                    })
                                    else:
                                        minister_id.write({'ministry_status': status})
                                    if minister_id:
                                        if sh.row_values(rownum)[4]:
                                            minister_id.write(
                                                {'start_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[4], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                        if sh.row_values(rownum)[7]:
                                            minister_id.write(
                                                {'retired_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[7], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
                                        if sh.row_values(rownum)[5]:
                                            minister_id.write(
                                                {'renewal_date': datetime.strptime(str(xlrd.xldate.xldate_as_datetime(sh.row_values(rownum)[5], book.datemode)), "%Y-%m-%d %H:%M:%S").date()})
            except Exception as e:
                raise ValidationError(_(e))                     
        if self.file_type == 'death_data':
            print("LDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",self.file_type)
            try:
                counter = 0
                for wizard in self:
                    book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                    print("book final:::::::::::::::::::::::::::::",book)
                    sh = book.sheet_by_index(0)
                    batchCount = 1
                    for rownum in range(sh.nrows):
                        counter += 1
                        if counter > 1:
                            partner_id = self.env['res.partner'].search([('member_ref', '=', sh.row_values(rownum)[0])])
                            if sh.row_values(rownum)[2]:
                                burial_place_id = self.env['burial.places'].search([('code', '=', str(sh.row_values(rownum)[2]).rstrip('0').rstrip('.'))])
                                if burial_place_id:
                                     burial_place = burial_place_id.id
                                else:
                                    burial_place = False
                            else: 
                                burial_place = False
                            if sh.row_values(rownum)[0]:
                                funeral_member_id = self.env['funeral.member.details'].search([('registration_member_id', '=', partner_id.id)])
                                if not funeral_member_id:
                                    if sh.row_values(rownum)[1]:
                                        death_date = datetime.strptime(sh.row_values(rownum)[1], '%m/%d/%Y')
                                    else:
                                        death_date = False
                                    funeral_reg_id = self.env['funeral.registration'].create(
                                        {'member_detail_ids': [(0,0, {'registration_member_id': partner_id.id,
                                         'date_of_death': death_date,
                                         'funeral_date': death_date,
                                         'cemetery': burial_place,
                                         'mass_service': str(sh.row_values(rownum)[3]).rstrip('0').rstrip('.')
                                        })]})
            except Exception as e:
                raise ValidationError(_(e))
        if self.file_type == 'sacrament':
            print("LDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD",self.file_type)
            try:
                counter = 0
                for wizard in self:
                    book = xlrd.open_workbook(file_contents = base64.b64decode(self.file))
                    print("book final:::::::::::::::::::::::::::::",book)
                    sh = book.sheet_by_index(0)
                    batchCount = 1
                    for rownum in range(sh.nrows):
                        counter += 1
                        if counter > 1:
                            partner_id = self.env['res.partner'].search([('member_ref', '=', sh.row_values(rownum)[0])])
                            if partner_id:
                                print("partner id:::::::::::::::::vvvvvvvvv:::::::::::::::::::::",partner_id)
            except Exception as e:
                raise ValidationError(_(e))