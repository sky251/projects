from odoo import models
import io

class StudentByLevelReportXls(models.AbstractModel):
    _name = 'report.church_management.report_student_by_level_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format(
            {'align': 'center', 'valign': 'vcenter', 'bold': True, 'size': 16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format(
            {'align': 'center', 'bold': True, 'size': 12})
        worksheet = workbook.add_worksheet('Student-By Level')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 20)
        worksheet.set_column('E:E', 20)
        worksheet.merge_range('A1:E2', "By Level Student Report", heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Level:', cell_text_format)
        worksheet.write(row, column+1, obj.level_id.name, f_format)
        row += 2
        worksheet.write(row, column, 'Member', cell_text_format)
        worksheet.write(row, column+1, 'Family', cell_text_format)
        worksheet.write(row, column+2, 'DOB', cell_text_format)
        worksheet.write(row, column+3, 'Session', cell_text_format)
        worksheet.write(row, column+4, 'Class', cell_text_format)
        row += 1
        student_data = obj.get_report_xls()
        for record in student_data['data']['student']:
            row += 1
            if record['child_id']:
                worksheet.write(row, column, record['child_id'], f_format)
            else:
                worksheet.write(row, column, '', f_format)
            if record['family_id']:
                worksheet.write(row, column+1, record['family_id'], f_format)
            else:
                worksheet.write(row, column+1, '', f_format)
            if record['dob']:
                worksheet.write(row, column+2, record['dob'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+2, '', f_format)
            if record['session_id']:
                worksheet.write(row, column+3, record['session_id'], f_format)
            else:
                worksheet.write(row, column+3, '', f_format)
            if record['class_id']:
                worksheet.write(row, column+4, record['class_id'], f_format)
            else:
                worksheet.write(row, column+4, '', f_format)
 

class StudentBySessionReportXls(models.AbstractModel):
    _name = 'report.church_management.report_student_by_session_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format(
            {'align': 'center', 'valign': 'vcenter', 'bold': True, 'size': 16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format(
            {'align': 'center', 'bold': True, 'size': 12})
        worksheet = workbook.add_worksheet('Student-By Session')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 20)
        worksheet.set_column('E:E', 20)
        worksheet.merge_range('A1:E2', "By Session Student Report", heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Session:', cell_text_format)
        worksheet.write(row, column+1, obj.session_id.name, f_format)
        row += 2
        worksheet.write(row, column, 'Member', cell_text_format)
        worksheet.write(row, column+1, 'Family', cell_text_format)
        worksheet.write(row, column+2, 'DOB', cell_text_format)
        worksheet.write(row, column+3, 'Level', cell_text_format)
        worksheet.write(row, column+4, 'Class', cell_text_format)
        row += 1
        student_data = obj.get_report_xls()
        for record in student_data['data']['student']:
            row += 1
            if record['child_id']:
                worksheet.write(row, column, record['child_id'], f_format)
            else:
                worksheet.write(row, column, '', f_format)
            if record['family_id']:
                worksheet.write(row, column+1, record['family_id'], f_format)
            else:
                worksheet.write(row, column+1, '', f_format)
            if record['dob']:
                worksheet.write(row, column+2, record['dob'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+2, '', f_format)
            if record['level_id']:
                worksheet.write(row, column+3, record['level_id'], f_format)
            else:
                worksheet.write(row, column+3, '', f_format)
            if record['class_id']:
                worksheet.write(row, column+4, record['class_id'], f_format)
            else:
                worksheet.write(row, column+4, '', f_format)
 

class StudentByClassReportXls(models.AbstractModel):
    _name = 'report.church_management.report_student_by_class_xls'
    _inherit = 'report.report_xlsx.abstract'

    def generate_xlsx_report(self, workbook, data, obj):
        heading_format = workbook.add_format(
            {'align': 'center', 'valign': 'vcenter', 'bold': True, 'size': 16})
        f_format = workbook.add_format({'align': 'center'})
        cell_text_format = workbook.add_format(
            {'align': 'center', 'bold': True, 'size': 12})
        worksheet = workbook.add_worksheet('Student-By Class')
        worksheet.set_column('A:A', 25)
        worksheet.set_column('B:B', 25)
        worksheet.set_column('C:C', 20)
        worksheet.set_column('D:D', 20)
        worksheet.set_column('E:E', 20)
        worksheet.merge_range('A1:E2', "By Class Student Report", heading_format)
        row = 4
        column = 0
        worksheet.write(row, column, 'Class:', cell_text_format)
        worksheet.write(row, column+1, obj.class_id.name, f_format)
        row += 2
        worksheet.write(row, column, 'Member', cell_text_format)
        worksheet.write(row, column+1, 'Family', cell_text_format)
        worksheet.write(row, column+2, 'DOB', cell_text_format)
        worksheet.write(row, column+3, 'Level', cell_text_format)
        worksheet.write(row, column+4, 'Session', cell_text_format)
        row += 1
        student_data = obj.get_report_xls()
        for record in student_data['data']['student']:
            row += 1
            if record['child_id']:
                worksheet.write(row, column, record['child_id'], f_format)
            else:
                worksheet.write(row, column, '', f_format)
            if record['family_id']:
                worksheet.write(row, column+1, record['family_id'], f_format)
            else:
                worksheet.write(row, column+1, '', f_format)
            if record['dob']:
                worksheet.write(row, column+2, record['dob'].strftime('%d/%m/%Y'), f_format)
            else:
                worksheet.write(row, column+2, '', f_format)
            if record['level_id']:
                worksheet.write(row, column+3, record['level_id'], f_format)
            else:
                worksheet.write(row, column+3, '', f_format)
            if record['session_id']:
                worksheet.write(row, column+4, record['session_id'], f_format)
            else:
                worksheet.write(row, column+4, '', f_format)
            
 