from odoo import models, fields, api, _
from datetime import datetime, date, time, timedelta
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError, ValidationError, Warning


class ByMonthYearWizard(models.TransientModel):
    _name = "by.month.year.wizard"
    _description = "By Month-Year Wizard"

    month = fields.Selection([('1', 'January'), ('2', 'February'), ('3', 'March'),
                              ('4', 'April'), ('5', 'May'),
                              ('6', 'June'), ('7', 'July'),
                              ('8', 'August'), ('9', 'September'),
                              ('10', 'October'), ('11', 'November'),
                              ('12', 'December')], string="Month", copy=False)
    year = fields.Integer(string='Year', copy=False, default=2020)

    def get_by_month_year(self):
        month_year_list = []
        data = {
            'form': self.read()[0]
        }
        month_year_data = self.env['sacrament.details'].search([])
        if month_year_data:
            for records in month_year_data:
                if records.date:
                    date_month = (records.date).month
                    date_year = (records.date).year
                    month = int(self.month)
                    if (date_month == month) and (date_year == self.year):
                        print("\n\n\n month&year", date_month,
                              date_year, self.month, self.year)
                        vals = {}
                        if records.family_id:
                            vals.update({'family_id': records.family_id.name})
                        else:
                            vals.update({'family_id': ''})
                        if records.family_code:
                            vals.update({'family_code': records.family_code})
                        else:
                            vals.update({'family_code': ''})
                        if records.registration_member_id:
                            vals.update(
                                {'registration_member_id': records.registration_member_id.name})
                        else:
                            vals.update({'registration_member_id': ''})
                        if records.date_of_birth:
                            vals.update(
                                {'date_of_birth': records.date_of_birth})
                        else:
                            vals.update({'date_of_birth': ''})
                        if records.date:
                            vals.update(
                                {'date': records.date})
                        else:
                            vals.update({'date': ''})
                        if records.sacrament_id:
                            vals.update(
                                {'sacrament_id': records.sacrament_id.name})
                        else:
                            vals.update({'sacrament_id': ''})
                        if records.sacrament_type:
                            vals.update(
                                {'sacrament_type': records.sacrament_type})
                        else:
                            vals.update({'sacrament_type': ''})
                        if records.registration_id.location:
                            vals.update(
                                {'location': records.registration_id.location.name})
                        else:
                            vals.update({'location': ''})
                        if records.registration_id.officiant:
                            vals.update(
                                {'officiant': records.registration_id.officiant.name})
                        else:
                            vals.update({'officiant': ''})
                        if records.is_completed:
                            vals.update(
                                {'is_completed': records.is_completed})
                        else:
                            vals.update({'is_completed': 'False'})
                        if vals:
                            month_year_list.append(vals)
                    # else:
                    #     raise UserError(
                    #         _('No contents to display in the report. Hence, this report cannot be printed.'))
        if month_year_list:
            data['sacrament'] = month_year_list
            return self.env.ref('sacrament_management.by_month_year_report').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

    def get_report_xls(self):
        month_year_list = []
        data = {}
        month_year_data = self.env['sacrament.details'].search([])
        if month_year_data:
            for records in month_year_data:
                if records.date:
                    date_month = (records.date).month
                    date_year = (records.date).year
                    month = int(self.month)
                    if (date_month == month) and (date_year == self.year):
                        vals = {}
                        if records.family_id:
                            vals.update({'family_id': records.family_id.name})
                        else:
                            vals.update({'family_id': ''})
                        if records.family_code:
                            vals.update({'family_code': records.family_code})
                        else:
                            vals.update({'family_code': ''})
                        if records.registration_member_id:
                            vals.update(
                                {'registration_member_id': records.registration_member_id.name})
                        else:
                            vals.update({'registration_member_id': ''})
                        if records.date_of_birth:
                            vals.update(
                                {'date_of_birth': records.date_of_birth})
                        else:
                            vals.update({'date_of_birth': ''})
                        if records.date:
                            vals.update(
                                {'date': records.date})
                        else:
                            vals.update({'date': ''})
                        if records.sacrament_id:
                            vals.update(
                                {'sacrament_id': records.sacrament_id.name})
                        else:
                            vals.update({'sacrament_id': ''})
                        if records.sacrament_type:
                            vals.update(
                                {'sacrament_type': records.sacrament_type})
                        else:
                            vals.update({'sacrament_type': ''})
                        if records.registration_id.location:
                            vals.update(
                                {'location': records.registration_id.location.name})
                        else:
                            vals.update({'location': ''})
                        if records.registration_id.officiant:
                            vals.update(
                                {'officiant': records.registration_id.officiant.name})
                        else:
                            vals.update({'officiant': ''})
                        if records.is_completed:
                            vals.update(
                                {'is_completed': 'True'})
                        else:
                            vals.update({'is_completed': 'False'})
                        if vals:
                            month_year_list.append(vals)
                    # else:
                    #     raise UserError(
                    #         _('No contents to display in the report. Hence, this report cannot be printed.'))
        if month_year_list:
            data['sacrament'] = month_year_list
            return self.env.ref('sacrament_management.by_month_year_report_xls').with_context(landscape=True).report_action(self, data=data)
        else:
            raise UserError(
                _('No contents to display in the report. Hence, this report cannot be printed.'))

