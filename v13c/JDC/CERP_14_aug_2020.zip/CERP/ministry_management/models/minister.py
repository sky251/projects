# -*- coding: utf-8 -*-
from odoo import fields, models, api


class Minister(models.Model):
    _name = 'minister.minister'
    _rec_name = 'member_id'

    member_id = fields.Many2one('res.partner', 'Member', copy=False)
    family_id = fields.Many2one('res.partner', 'Family', copy=False, default=False)
    ministry_ids = fields.Many2many('ministry.ministry', 'ministry_minister_rel', string='Ministries', copy=False)
    calendar_event_ids = fields.Many2many('calendar.event','minister_calendar_event_rel', string="Events", copy=False, compute="_set_events")
    virtus_certification = fields.Boolean('Virtus Certificate Frequency', copy=False)
    background_check = fields.Boolean('Background Checks', copy=False)
    schedulled_group_ids = fields.Many2many('schedulling.by.group', 'minister_minister_schedulled_by_group_rel', string='Scheduled Group')

    @api.onchange('schedulled_group_ids')
    def onchange_schedulled_group(self):
        events = []
        if self.schedulled_group_ids:
            for group in self.schedulled_group_ids:
                events.append(group.event_id.id)
            self.calendar_event_ids = [(6, 0, events)]
        else:
            self.calendar_event_ids = [(6, 0, events)]


    def get_minister_information(self):
        action = self.env.ref('ministry_management.action_view_minister_info_wizard').read()[0]
        action['context'] = {
            'default_ministry_ids': [(6,0, self.ministry_ids.ids)],
            'default_calendar_event_ids':  [(6,0, self.calendar_event_ids.ids)],
            'default_family_id': self.family_id.id,
            'default_member_id': self.member_id.id,
            'default_group_ids': [(6,0, self.schedulled_group_ids.ids)]
        }
        return action

    def _set_events(self):
        for rec in self:
            events = []
            if rec.schedulled_group_ids:
                for group in rec.schedulled_group_ids:
                    events.append(group.event_id.id)
            rec.calendar_event_ids = [(6,0, events)]

    # def write(self, vals):
    #     for rec in self:
    #         print("call:DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD")
    #         if not rec.ministry_ids and not rec.schedulled_group_ids:
    #             rec.unlink()