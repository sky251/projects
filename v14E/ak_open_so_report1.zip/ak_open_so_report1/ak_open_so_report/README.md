Open Sale Order Report
-----------------------------------

Odoo Version : Odoo 14.0 Community/Enterprise


Installation 
-------------------------------------
Install the Application => Apps -> Open Sale Order Report(ak_open_so_report)


Overview
-------------------------------------
* The functionality of this module is to print a report of SO which are not delivered yet.
* User can get report by partners as well as category of products.
* User can print report for particular customers as well.