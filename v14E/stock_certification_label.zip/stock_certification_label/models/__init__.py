from . import certification
from . import warning
from . import product_template
from . import sale_order_line
from . import purchase_order_line
from . import product_packaging_type
from . import delivery_carrier
from . import res_partner
from . import res_company
from . import stock_picking
from . import stock_move
from . import stock_rule


